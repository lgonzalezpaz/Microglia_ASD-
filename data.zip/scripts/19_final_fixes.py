"""Final corrections: Vancouver punctuation, title artifacts, and the Huttenlocher anchor."""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, re, subprocess

MS = f'{ROOT}/manuscript'

# ---- 1. add Huttenlocher & Dabholkar 1997 to the verified bibliography ----------
import pandas as pd
sub = subprocess.run(
    ['python3', f'{ROOT}/scripts/03_verify_refs.py', '/dev/stdin'],
    input='10.1002/(SICI)1096-9861(19971020)387:2<167::AID-CNE1>3.0.CO;2-Z\n',
    capture_output=True, text=True, timeout=300)
print(sub.stdout.strip()[-200:])
new = pd.read_csv(f'{ROOT}/out/references_verified.csv')
new = new[new.status == 'OK']
assert len(new) == 1, new
# restore the full verified bibliography, which the single-DOI run overwrote,
# and append the newly verified entry to it
import shutil
full = pd.read_csv(f'{ROOT}/out/references_verified_FULL.csv')
pd.concat([full, new], ignore_index=True).to_csv(
    f'{ROOT}/out/references_verified.csv', index=False)
print('restored full bibliography:', len(full) + 1, 'entries')


def clean(s):
    s = re.sub(r'<[^>]+>', '', str(s))
    s = re.sub(r'\s+', ' ', s).strip()
    s = s.replace('et al..', 'et al.').replace(' .', '.')
    s = re.sub(r'(\w)\.\.', r'\1.', s)
    s = s.replace(' ‐', '-').replace('‐ ', '-').replace('‐', '-')
    s = re.sub(r'\s+-\s*Independent', '-Independent', s)
    # Vancouver: Journal. Year;Volume:Pages.
    s = re.sub(r'(\d{4});([^,;:]+), ', r'\1;\2:', s)
    return s


refs = json.load(open(f'{MS}/references_map.json'))
refs = {k: clean(v) for k, v in refs.items()}
refs['huttenlocher1997'] = clean(new.vancouver.values[0])
json.dump(refs, open(f'{MS}/references_map.json', 'w'), indent=1, ensure_ascii=False)
print('huttenlocher1997 ->', refs['huttenlocher1997'])
print('sample  ->', refs['stevens2007'])
print('salter  ->', refs['salter2026'])

# ---- 2. cite it where it belongs -----------------------------------------------
p = f'{MS}/manuscript_source.md'
s = open(p).read()
edits = [
    # the 40% anchor: Huttenlocher & Dabholkar report the magnitude and the regional timing
    ("*S*~0~ = 0.60 anchors the mature state to histology: human cortex loses roughly 40% of "
     "peak synaptic density between early childhood and adulthood{{petanjek2011}}{{finnema2016}}.",
     "*S*~0~ = 0.60 anchors the mature state to histology: human cortex loses roughly 40% of "
     "peak synaptic density between the childhood peak and adulthood{{huttenlocher1997}}"
     "{{petanjek2011}}, a decline now also measurable in vivo with synaptic-density "
     "imaging{{finnema2016}}."),
    # the regional-timing claim in the developmental Methods
    ("Classical histology reports a protracted synaptogenic and pruning window in prefrontal "
     "relative to sensory cortex{{petanjek2011}}.",
     "Classical histology reports a protracted synaptogenic and pruning window in prefrontal "
     "relative to sensory cortex: synaptic density peaks within the first postnatal year in "
     "auditory cortex but only in the mid-preschool years in prefrontal cortex"
     "{{huttenlocher1997}}, and prefrontal spine pruning continues into the third "
     "decade{{petanjek2011}}."),
    # Discussion convergence sentence
    ("This converges with histological evidence that human frontal spine pruning extends into "
     "the third decade{{petanjek2011}} and supplies the molecular counterpart:",
     "This converges with histological evidence that synaptogenesis peaks far later in "
     "prefrontal than in sensory cortex{{huttenlocher1997}} and that human frontal spine "
     "pruning extends into the third decade{{petanjek2011}}, and supplies the molecular "
     "counterpart:"),
]
n = 0
for a, b in edits:
    if a in s:
        s = s.replace(a, b, 1); n += 1
    else:
        print('MISS:', a[:70])
open(p, 'w').write(s)
print(f'{n}/{len(edits)} citation edits applied')

# ---- 3. cite the supplementary tables in the text -----------------------------
s = open(p_ms := f'{MS}/manuscript_source.md').read()
more = [
    ("All code, environment specifications and derived data are released (Data Availability).",
     "Per-parcel values for every layer score, model quantity and case-control effect size are "
     "given in Supplementary Table 5, and the provenance of every data resource in "
     "Supplementary Table 6. All code, environment specifications and derived data are "
     "released (Data Availability)."),
]
k = 0
for a, b in more:
    if a in s:
        s = s.replace(a, b, 1); k += 1
    else:
        print('MISS supp:', a[:60])
open(p_ms, 'w').write(s)
print(f'{k}/{len(more)} supplementary-table citations added')

# ---- 4. drop exploratory scripts from the release ------------------------------
import os
for junk in ['pmc_supp.py', 'pmc_tools.py']:
    q = f'{ROOT}/release/pruning-axis-autism/scripts/{junk}'
    if os.path.exists(q):
        os.remove(q); print('removed from release:', junk)

# ---- 5. correct the probe-availability statement ------------------------------
# Verified against data/ahba/.../Probes.csv: C4B is not on the array; C4A, SRPX2,
# CD200R1, CFI, CR1, CSMD2, C5AR1 and IRF8 ARE present as probes but did not survive
# abagen's intensity-based filtering, i.e. they are not reliably detected above
# background in this microarray platform.
s = open(p_ms).read()
probe = [
 ("Of these, 11/13 O, 12/17 K, 23/25 E and 36/36 S genes were represented in AHBA. "
  "*C4A* and *C4B* were absent from the AHBA probe set, as were *SRPX2*, *CD200R1*, "
  "*CFI*, *CR1* and *CSMD2*; these genes therefore contribute to the conceptual "
  "framework but not to the regional statistics.",
  "Of these, 11/13 O, 12/17 K, 23/25 E and 36/36 S genes survived into the processed "
  "expression matrix. *C4B* is not represented on the array at all; *C4A*, *SRPX2*, "
  "*CD200R1*, *CFI*, *CR1*, *CSMD2*, *C5AR1* and *IRF8* are present as probes but did "
  "not pass intensity-based filtering, meaning they are not reliably detected above "
  "background on this platform. These genes therefore inform the conceptual framework "
  "but contribute nothing to the regional statistics, and their absence is itself a "
  "measurement limitation of bulk microarray rather than evidence of low expression "
  "in vivo."),
 ("we could not test it here because *SRPX2* is absent from the AHBA probe set, a gap "
  "that single-nucleus or spatial transcriptomics could close.",
  "we could not test it here because *SRPX2* does not rise above background in the AHBA "
  "microarray, a gap that single-nucleus or spatial transcriptomics could close."),
 ("*C4A*, *C4B* and *SRPX2* are absent from the probe set, removing precisely the genes "
  "with the strongest prior links to complement-mediated psychiatric risk and to language.",
  "*C4A*, *C4B* and *SRPX2* are missing from the processed expression matrix — *C4B* is "
  "not on the array, and the others fall below the intensity threshold — removing "
  "precisely the genes with the strongest prior links to complement-mediated psychiatric "
  "risk and to language."),
]
j = 0
for a, b in probe:
    if a in s:
        s = s.replace(a, b, 1); j += 1
    else:
        print('MISS probe:', a[:60])
open(p_ms, 'w').write(s)
print(f'{j}/{len(probe)} probe-availability corrections applied')

rp = f'{ROOT}/release/pruning-axis-autism/README.md'
r = open(rp).read()
r = r.replace(
 "- *C4A*, *C4B* and *SRPX2* are **absent from the Allen probe set** — precisely the genes with",
 "- *C4A*, *C4B* and *SRPX2* are **missing from the processed expression matrix** (*C4B* is not\n  on the array; the others fall below the intensity-filtering threshold) — precisely the genes with")
open(rp, 'w').write(r)
print('README corrected')

# ---- 6. split merged placement markers; add a Table 4 marker -------------------
s = open(p_ms).read()
s = s.replace("[Table 2 near here] [Figure 4 near here]",
              "[Table 2 near here]\n\n[Figure 4 near here]")
s = s.replace("[Table 3 near here] [Figure 5 near here]",
              "[Table 3 near here]\n\n[Figure 5 near here]")
if "[Table 4 near here]" not in s:
    s = s.replace("[Figure 3 near here]", "[Table 4 near here]\n\n[Figure 3 near here]", 1)
open(p_ms, 'w').write(s)
print("placement markers normalised")

# ---- 7. anchor inline tables to their position markers, not the prose ----------
q = f'{ROOT}/scripts/16_md_to_ast.py'
t = open(q).read()
t = t.replace("""# insert tables after their anchor paragraphs
for name, _, anchor in INLINE_TABLES:
    tb = load_table(name)
    for k, b in enumerate(blocks):
        if b['type'] == 'p' and anchor in ''.join(r['t'] for r in b['runs']):
            blocks.insert(k + 1, tb)
            break
    else:
        print(f'  WARNING: anchor not found for {name}')""",
"""# place each inline table immediately after its [Table N near here] marker
for name, _, _anchor in INLINE_TABLES:
    tb = load_table(name)
    tnum = name[5]
    marker = f'[Table {tnum} near here]'
    for k, b in enumerate(blocks):
        if b['type'] == 'placement' and marker in ''.join(r['t'] for r in b['runs']):
            blocks.insert(k + 1, tb)
            break
    else:
        print(f'  WARNING: placement marker not found for {name}')""")
open(q, 'w').write(t)
print("AST builder: tables now follow their placement markers")

# ---- 8. precision edits on wording that could be misread -----------------------
s = open(p_ms).read()
word = [
 ("Consistent with a target-encoded lesion, autism genetic risk concentrates on the "
  "synaptic substrate and is absent from microglial effector machinery, whereas "
  "schizophrenia risk implicates complement checkpoints.",
  "Consistent with a target-encoded lesion, autism genetic risk concentrates on the "
  "synaptic substrate and shows no enrichment in microglial effector machinery, whereas "
  "schizophrenia risk implicates complement checkpoints."),
 ("The microglial effector module showed no enrichment on either measure",
  "The microglial effector module showed no detectable enrichment on either measure"),
]
w = 0
for a, b in word:
    if a in s:
        s = s.replace(a, b, 1); w += 1
    else:
        print('MISS wording:', a[:60])
open(p_ms, 'w').write(s)
print(f'{w}/{len(word)} wording precision edits applied')

# ---- 9. disclose that metric C is degenerate ----------------------------------
s = open(p_ms).read()
degen = [
 ("Across the 432-point parameter sweep the sign of each metric's relationship to the "
  "cortical hierarchy was stable (metric A, 100% sign-consistent; metric B, 97%), and the "
  "ranking of parcels under the default parameters agreed closely with alternatives "
  "(Fig. 6).",
  "Metric C proved degenerate and was not carried into inference: because engulfment "
  "probability saturates, the opsonin increase required to exhaust synaptogenic reserve is "
  "unreachable for most parcels, and the metric was defined for only 3 of 34 parcels under "
  "the default parameters and for at least 21 parcels in only 51 of 432 parameter sets. "
  "Across the 432-point parameter sweep the sign of the remaining metrics' relationship to "
  "the cortical hierarchy was stable (metric A, 100% sign-consistent; metric B, 97%), and "
  "the ranking of parcels under the default parameters agreed closely with alternatives "
  "(Fig. 6)."),
 ("Default parameters were *n* = 2, λ = 1.5, *g* = 0.5, κ = 1.25 and probe perturbation "
  "*m* = 2.",
  "Default parameters were *n* = 2, λ = 1.5, *g* = 0.5, κ = 1.25 and probe perturbation "
  "*m* = 2. Metric C is undefined wherever the required opsonin increase exceeds the "
  "saturation ceiling of Φ, and correlations involving it were computed only where at "
  "least 21 parcels were defined."),
]
g_ = 0
for a, b in degen:
    if a in s:
        s = s.replace(a, b, 1); g_ += 1
    else:
        print('MISS degen:', a[:60])
open(p_ms, 'w').write(s)
print(f'{g_}/{len(degen)} metric-C disclosures applied')

# caption for Figure 6
q6 = f'{ROOT}/scripts/16_md_to_ast.py'
t6 = open(q6).read()
t6 = t6.replace(
 "'Parameter sensitivity. Correlation between each vulnerability metric and the '\n  'cortical hierarchy across combinations of Hill cooperativity n and checkpoint potentiation '\n  'lambda, averaged over the gain and perturbation grids.'",
 "'Parameter sensitivity. Correlation between each vulnerability metric and the '\n  'cortical hierarchy across combinations of Hill cooperativity n and checkpoint potentiation '\n  'lambda, averaged over the gain and perturbation grids. Metric C is undefined wherever the '\n  'opsonin increase needed to exhaust synaptogenic reserve exceeds the saturation ceiling of '\n  'the engulfment probability; panel c therefore summarises only parameter sets in which it is '\n  'defined for at least 21 parcels, and it is shown for completeness rather than used for '\n  'inference.'")
open(q6, 'w').write(t6)
print('Figure 6 caption updated')

# ---- 10. report the schizophrenia result completely ---------------------------
# module_K OT-SCZ z = 3.50, P = 0.011 AND module_S OT-SCZ z = 3.04, P = 0.012.
# Reporting only the checkpoint would be a selective reading; the dissociation is that
# the checkpoint layer carries schizophrenia but not autism risk.
s = open(p_ms).read()
scz = [
 ("Schizophrenia showed a different topology: the checkpoint layer was enriched for "
  "schizophrenia genetic association (*z* = 3.50, *P* = 0.011) while showing no autism "
  "enrichment, consistent with complement-regulatory genes such as *CSMD1* carrying "
  "schizophrenia risk{{kraus2006}}.",
  "Schizophrenia showed a different topology. Its genetic risk was enriched both in the "
  "synaptic substrate (*z* = 3.04, *P* = 0.012) and, unlike autism, in the checkpoint layer "
  "(*z* = 3.50, *P* = 0.011), which carried no autism enrichment. The dissociation is "
  "therefore specific: both disorders implicate the synaptic target, but only schizophrenia "
  "implicates the complement checkpoint, consistent with complement-regulatory genes such as "
  "*CSMD1* carrying schizophrenia risk{{kraus2006}}."),
 ("The contrast with schizophrenia is instructive: there, risk touched the complement "
  "checkpoint layer, consistent with structural variation at *C4* and with "
  "complement-regulatory loci{{sekar2016}}{{kraus2006}}.",
  "The contrast with schizophrenia is instructive. Schizophrenia risk loaded on the synaptic "
  "substrate as well, but it additionally reached the complement checkpoint layer, which "
  "autism risk did not, consistent with structural variation at *C4* and with "
  "complement-regulatory loci{{sekar2016}}{{kraus2006}}. The two disorders share a target "
  "and differ in whether the braking layer is also affected."),
 ("Autism genetic risk concentrates on the neuronal synaptic substrate and is absent from "
  "microglial effector machinery, placing the primary lesion on the target rather than the "
  "executioner; schizophrenia, by contrast, implicates the complement checkpoint layer, "
  "showing that disorders converging on one effector pathway may enter it at different "
  "points.",
  "Autism genetic risk concentrates on the neuronal synaptic substrate and shows no "
  "enrichment in microglial effector machinery, placing the primary lesion on the target "
  "rather than the executioner; schizophrenia risk additionally reaches the complement "
  "checkpoint layer, showing that disorders converging on one effector pathway may enter it "
  "at different points."),
]
z = 0
for a, b in scz:
    if a in s:
        s = s.replace(a, b, 1); z += 1
    else:
        print('MISS scz:', a[:70])
open(p_ms, 'w').write(s)
print(f'{z}/{len(scz)} schizophrenia-reporting corrections applied')

# ---- 11. calibrate "steeply" to the actual coefficients ------------------------
# O rho = 0.88, E = 0.83, K = 0.56: "all three rise steeply" overstates the checkpoint.
s = open(p_ms).read()
steep = [
 ("we find that all three regulatory layers rise steeply along the "
  "sensorimotor-to-association hierarchy while the substrate is spatially flat",
  "we find that all three regulatory layers rise along the sensorimotor-to-association "
  "hierarchy while the substrate is spatially flat"),
 ("All three regulatory layers increased steeply along this axis (opsonin",
  "All three regulatory layers increased along this axis, most steeply the opsonin and "
  "effector layers (opsonin"),
]
q_ = 0
for a, b in steep:
    if a in s:
        s = s.replace(a, b, 1); q_ += 1
    else:
        print('MISS steep:', a[:60])
open(p_ms, 'w').write(s)
print(f'{q_}/{len(steep)} calibration edits applied')
