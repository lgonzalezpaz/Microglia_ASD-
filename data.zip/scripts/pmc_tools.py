import json, subprocess, sys, re
TOOL="&tool=for-paper&email=lgonzalezpaz%40gmail.com"
def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=180).stdout
def doi2pmc(doi):
    u=f"https://pmc.ncbi.nlm.nih.gov/tools/idconv/api/v1/articles/?ids={doi}&format=json{TOOL}"
    try:
        j=json.loads(sh(f'curl -sS --max-time 60 "{u}"'))
        r=j["records"][0]
        return r.get("pmcid"), r.get("pmid")
    except Exception as e:
        return None, None
def oa_list(pmcid):
    u=f"https://www.ncbi.nlm.nih.gov/pmc/utils/oa/oa.fcgi?id={pmcid}"
    return sh(f'curl -sS --max-time 60 "{u}"')
if __name__=="__main__":
    for doi in sys.argv[1:]:
        p,pm = doi2pmc(doi)
        print(f"{doi}\t{p}\t{pm}")
