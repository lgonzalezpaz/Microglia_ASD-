"""Partition autism genetic risk across the layers of the pruning axis.

Logic. If aberrant microglial pruning in idiopathic autism were a primary, immune-intrinsic
lesion, inherited risk should concentrate in the microglial EFFECTOR layer. If microglia
instead act on mis-specified targets, risk should concentrate in the neuronal SUBSTRATE and
CHECKPOINT layers while sparing effector machinery. Schizophrenia provides a positive
control for an opsonin-side lesion (C4 structural variation; Sekar et al. 2016).

Risk measures (independent of literature text-mining, which would reward well-studied
microglial genes):
  * SFARI Gene curated autism risk categories (Abrahams et al. 2013)
  * Open Targets Platform `genetic_association` datatype score (Ochoa et al. 2023)

Confound control. Risk genes are systematically longer, more constrained and more highly
brain-expressed. Enrichment is therefore assessed against background gene sets matched on
coding length, loss-of-function constraint (LOEUF) and mean cortical expression, by
stratified resampling (27 strata = 3 x 3 x 3 tertiles).

Outputs: out/genetic_partition.csv, out/genetic_partition_celltype.csv, out/genetic_qc.json
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import gzip, json
import numpy as np, pandas as pd
from scipy import stats

OUT = f'{ROOT}/out'
GS = f'{ROOT}/data/genesets'
N_PERM = 20000
rng = np.random.default_rng(20261025)

# ------------------------------------------------------------------ gene universe
grp = pd.read_csv(f'{OUT}/ahba_dk_group.csv', index_col=0)
info = pd.read_csv(f'{OUT}/dk_info.csv')
ctxL = info[(info.structure == 'cortex') & (info.hemisphere == 'L')].sort_values('id')
grp.index = grp.index.astype(int)
expr = grp.loc[ctxL.id.values].dropna(axis=1, how='any')
mean_expr = expr.mean(axis=0)

con = pd.read_csv(f'{GS}/gnomad_constraint.txt.bgz', sep='\t', compression='gzip',
                  usecols=['gene', 'pLI', 'oe_lof_upper', 'cds_length',
                           'num_coding_exons', 'gene_length', 'transcript_type'])
con = con[con.transcript_type == 'protein_coding']
con['gene'] = con.gene.str.upper()
con = con.sort_values('oe_lof_upper').drop_duplicates('gene')

uni = pd.DataFrame({'gene': mean_expr.index.str.upper(), 'mean_expr': mean_expr.values})
uni = uni.drop_duplicates('gene').merge(con, on='gene', how='inner')
uni = uni.dropna(subset=['oe_lof_upper', 'cds_length', 'mean_expr'])
print(f'gene universe (cortically expressed, protein-coding, constraint available): {len(uni)}')

# ------------------------------------------------------------------ risk measures
sf = pd.read_csv(f'{GS}/sfari_genes.csv')
sf['gene'] = sf['gene-symbol'].str.upper()
sfari_any = set(sf.gene)
sfari_hc = set(sf.loc[sf['gene-score'] <= 2, 'gene'])      # score 1-2: high confidence / strong
sfari_s1 = set(sf.loc[sf['gene-score'] == 1, 'gene'])

ot = {}
for k in ['asd', 'scz']:
    t = pd.read_csv(f'{GS}/opentargets_{k}_genetic.csv')
    t['gene'] = t.symbol.str.upper()
    ot[k] = t.drop_duplicates('gene').set_index('gene')['genetic_association']

uni['sfari_any'] = uni.gene.isin(sfari_any).astype(int)
uni['sfari_hc'] = uni.gene.isin(sfari_hc).astype(int)
uni['sfari_s1'] = uni.gene.isin(sfari_s1).astype(int)
uni['ot_asd'] = uni.gene.map(ot['asd']).fillna(0.0)
uni['ot_scz'] = uni.gene.map(ot['scz']).fillna(0.0)
print(f"risk annotation: SFARI any={uni.sfari_any.sum()}, score1-2={uni.sfari_hc.sum()}, "
      f"score1={uni.sfari_s1.sum()}; OT ASD>0={int((uni.ot_asd>0).sum())}, "
      f"OT SCZ>0={int((uni.ot_scz>0).sum())}")

# ------------------------------------------------------------------ matching strata
def tert(v):
    q = np.quantile(v, [1/3, 2/3])
    return np.digitize(v, q)


uni['stratum'] = (tert(np.log10(uni.cds_length)) * 9
                  + tert(uni.oe_lof_upper) * 3
                  + tert(np.log10(uni.mean_expr - uni.mean_expr.min() + 1e-6)))
uni = uni.set_index('gene')
by_str = {s: g.index.values for s, g in uni.groupby('stratum')}

MEASURES = ['sfari_any', 'sfari_hc', 'sfari_s1', 'ot_asd', 'ot_scz']


def matched_test(genes, label):
    g = [x for x in genes if x in uni.index]
    if len(g) < 5:
        return None
    sub = uni.loc[g]
    comp = sub.stratum.value_counts().to_dict()
    obs = {m: float(sub[m].mean()) for m in MEASURES}
    null = {m: np.empty(N_PERM) for m in MEASURES}
    for b in range(N_PERM):
        pick = []
        for s, k in comp.items():
            pool = by_str.get(s, np.array([]))
            if pool.size == 0:
                continue
            pick.append(rng.choice(pool, size=min(k, pool.size), replace=False))
        if not pick:
            continue
        sel = uni.loc[np.concatenate(pick)]
        for m in MEASURES:
            null[m][b] = sel[m].mean()
    out = dict(gene_set=label, n_genes=len(g))
    for m in MEASURES:
        nn = null[m]
        mu, sd = float(np.nanmean(nn)), float(np.nanstd(nn))
        z = (obs[m] - mu) / sd if sd > 0 else np.nan
        pr = (np.sum(nn >= obs[m]) + 1) / (len(nn) + 1)
        pl = (np.sum(nn <= obs[m]) + 1) / (len(nn) + 1)
        out[f'{m}_obs'] = round(obs[m], 5)
        out[f'{m}_null'] = round(mu, 5)
        out[f'{m}_z'] = round(float(z), 3) if np.isfinite(z) else np.nan
        out[f'{m}_p'] = round(float(min(1.0, 2 * min(pr, pl))), 6)
    return out


# ------------------------------------------------------- module-level partition
mod = pd.read_csv(f'{ROOT}/data/modules/pruning_axis_modules.csv')
mod['gene'] = mod.gene.str.upper()
rows = []
for m, sub in mod.groupby('module'):
    r = matched_test(sub.gene.unique(), f'module_{m}')
    if r:
        rows.append(r)
res = pd.DataFrame(rows)
res.to_csv(f'{OUT}/genetic_partition.csv', index=False)
print('\n===== module-level autism risk enrichment (length/constraint/expression matched) =====')
cols = ['gene_set', 'n_genes', 'sfari_any_obs', 'sfari_any_null', 'sfari_any_z', 'sfari_any_p',
        'ot_asd_obs', 'ot_asd_null', 'ot_asd_z', 'ot_asd_p',
        'ot_scz_obs', 'ot_scz_null', 'ot_scz_z', 'ot_scz_p']
print(res[cols].to_string(index=False))

# -------------------------------------- data-driven cell-type gene sets (no hand curation)
frac = pd.read_csv(f'{OUT}/celltype_specificity.csv', index_col=0)
frac.index = frac.index.str.upper()
frac = frac[~frac.index.duplicated()]
ct_rows = []
for cell in ['Microglia', 'Neuron', 'Astrocyte', 'Oligo/OPC']:
    if cell not in frac.columns:
        continue
    s = frac[cell].dropna().sort_values(ascending=False)
    s = s[s.index.isin(uni.index)]
    # require non-trivial cortical expression: extreme specificity fractions are
    # otherwise dominated by genes near the detection floor
    expressed = uni.mean_expr[uni.mean_expr > uni.mean_expr.quantile(0.25)].index
    s = s[s.index.isin(expressed)]
    for topn in [250, 500, 1000]:
        r = matched_test(list(s.index[:topn]), f'{cell}_top{topn}')
        if r:
            ct_rows.append(r)
ct = pd.DataFrame(ct_rows)
ct.to_csv(f'{OUT}/genetic_partition_celltype.csv', index=False)
print('\n===== cell-type-specific gene sets (data-driven, Allen human cortex) =====')
print(ct[cols].to_string(index=False))

json.dump({'n_universe': int(len(uni)), 'n_perm': N_PERM,
           'strata': int(uni.stratum.nunique()),
           'matching': ['log10 cds_length tertile', 'LOEUF tertile',
                        'log10 mean cortical expression tertile']},
          open(f'{OUT}/genetic_qc.json', 'w'), indent=1)
print('\nDONE_10')
