"""Assemble manuscript tables as CSV and Markdown."""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json
import numpy as np, pandas as pd

OUT = f'{ROOT}/out'
TAB = f'{ROOT}/tables'
import os
os.makedirs(TAB, exist_ok=True)


def emit(df, name, caption, index=False):
    df.to_csv(f'{TAB}/{name}.csv', index=index)
    with open(f'{TAB}/{name}.md', 'w') as f:
        f.write(f'**{caption}**\n\n')
        f.write(df.to_markdown(index=index))
        f.write('\n')
    print(f'  {name}: {df.shape}')


qc = json.load(open(f'{OUT}/module_qc.json'))
ctm = pd.read_csv(f'{OUT}/celltype_by_module.csv', index_col=0)
part = pd.read_csv(f'{OUT}/partial_correlations.csv')
loo = pd.read_csv(f'{OUT}/module_loo_stability.csv')
mod = pd.read_csv(f'{ROOT}/data/modules/pruning_axis_modules.csv')

# ---- Table 1: module definition, cellular ownership, reliability, gradient
NAMES = {'O': 'Opsonin tag', 'K': 'Checkpoint', 'E': 'Microglial effector',
         'S': 'Synaptic substrate'}
rows = []
for m in ['O', 'K', 'E', 'S']:
    rel = qc['reliability'][m]
    ext = part[(part.module == m) & (part.specification == 'extensive (unadjusted)')].iloc[0]
    inte = part[(part.module == m) & (part.specification.str.startswith('intensive'))].iloc[0]
    l = loo[loo.module == m].rho_vs_axis
    rows.append({
        'Module': f'{m} — {NAMES[m]}',
        'Genes defined': int(mod[mod.module == m].gene.nunique()),
        'Genes in AHBA': len(qc['module_genes_present'][m]),
        'Neuron': ctm.loc[m, 'Neuron'], 'Microglia': ctm.loc[m, 'Microglia'],
        'Astrocyte': ctm.loc[m, 'Astrocyte'],
        'Inter-donor ρ': round(rel['mean_interdonor_spearman'], 3),
        'Spearman–Brown (k=6)': round(rel['spearman_brown_k_donors'], 3),
        'ρ vs axis (extensive)': round(ext.rho, 3),
        'P (extensive)': f'{ext.p:.1e}',
        'ρ vs axis (per-cell)': round(inte.rho, 3),
        'P (per-cell)': f'{inte.p:.1e}',
        'Leave-one-out ρ (SD)': f'{l.mean():.3f} ({l.std():.3f})',
    })
emit(pd.DataFrame(rows), 'Table1_module_architecture',
     'Table 1. Composition, cellular ownership, reliability and cortical gradient of the '
     'four layers of the synaptic pruning axis. Cellular ownership is the mean fraction of '
     'expression attributable to each class in Allen human cortical single-nucleus data. '
     'The axis is the first principal component of regional cortical expression.')

# ---- Table 2: genetic partition
gp = pd.read_csv(f'{OUT}/genetic_partition.csv')
gp['Module'] = gp.gene_set.str.replace('module_', '', regex=False).map(
    lambda m: f'{m} — {NAMES[m]}')
t2 = gp[['Module', 'n_genes',
         'sfari_any_obs', 'sfari_any_null', 'sfari_any_z', 'sfari_any_p',
         'ot_asd_obs', 'ot_asd_null', 'ot_asd_z', 'ot_asd_p',
         'ot_scz_obs', 'ot_scz_null', 'ot_scz_z', 'ot_scz_p']].copy()
t2.columns = ['Module', 'n genes',
              'SFARI obs.', 'SFARI null', 'SFARI z', 'SFARI P',
              'OT autism obs.', 'OT autism null', 'OT autism z', 'OT autism P',
              'OT schizophrenia obs.', 'OT schizophrenia null',
              'OT schizophrenia z', 'OT schizophrenia P']
t2 = t2.sort_values('Module')
emit(t2.round(5), 'Table2_genetic_partition',
     'Table 2. Partition of autism and schizophrenia genetic risk across the pruning axis. '
     'Enrichment is relative to background gene sets matched on coding length, '
     'loss-of-function constraint and mean cortical expression (20,000 stratified '
     'resamples). OT, Open Targets genetic-association score.')

# ---- Table 3: developmental timing
fam = pd.read_csv(f'{OUT}/robust_devel_fdr.csv')
LBL = {'O_peak_log_pcd': 'Opsonin, age of peak (log₁₀ post-conceptional days)',
       'K_peak_log_pcd': 'Checkpoint, age of peak (log₁₀ days)',
       'E_peak_log_pcd': 'Effector, age of peak (log₁₀ days)',
       'O_t90_years': 'Opsonin, age at 90% of maximum (years)',
       'K_t90_years': 'Checkpoint, age at 90% of maximum (years)',
       'E_t90_years': 'Effector, age at 90% of maximum (years)'}
t3 = fam.copy()
t3['Feature'] = t3.feature.map(LBL)
t3 = t3[['Feature', 'association_mean', 'primary_mean', 'difference',
         'p_exact', 'p_fdr_family']]
t3.columns = ['Feature', 'Association cortex', 'Primary cortex',
              'Difference', 'P (exact)', 'q (FDR)']
emit(t3.round(4), 'Table3_developmental_timing',
     'Table 3. Developmental timing of pruning-axis engagement in association versus '
     'primary cortex (BrainSpan, 11 neocortical regions, 42 donors). P values are exact '
     'permutation over the 330 possible assignments of region labels; q is '
     'Benjamini–Hochberg within the pre-specified six-test timing family.')

# ---- Table 4: spatial validation
val = pd.read_csv(f'{OUT}/validation_enigma.csv')
pw = pd.read_csv(f'{OUT}/robust_power.csv')
t4 = val.merge(pw[['predictor', 'target', 'detectable_abs_rho_95']],
               on=['predictor', 'target'], how='left')
TLB = {'ASD_mega_d': 'Autism (mega-analysis)', 'ASD_meta_d': 'Autism (meta-analysis)',
       'SCZ_d': 'Schizophrenia'}
t4['Target'] = t4.target.map(TLB)
t4 = t4[t4.predictor.isin(['OCB', 'OCB_percell', 'O', 'K', 'E', 'S',
                           'A_frac_loss', 'B_excess_flux', 'PC1'])]
t4 = t4[['predictor', 'Target', 'n', 'rho', 'p_parametric', 'p_spatial',
         'p_fdr', 'detectable_abs_rho_95']]
t4.columns = ['Predictor', 'Target', 'n parcels', 'ρ', 'P (parametric)',
              'P (spatial null)', 'q (FDR)', '|ρ| detectable at 95%']
emit(t4.sort_values(['Target', 'P (spatial null)']).round(4),
     'Table4_spatial_validation',
     'Table 4. Spatial association between model-derived regional predictions and ENIGMA '
     'case–control cortical-thickness effect sizes. P values are computed against 10,000 '
     'variogram-matched surrogate maps preserving the empirical spatial autocorrelation of '
     'each target. The final column is the correlation magnitude that would have reached '
     'significance, given that null.')

# ---- Table 5: regional metrics
vm = pd.read_csv(f'{OUT}/vulnerability_metrics.csv', index_col=0)
ock = pd.read_csv(f'{OUT}/ock_index.csv', index_col=0)
ENI = f'{ROOT}/data/enigma/enigmatoolbox/datasets/summary_statistics'
asd = pd.read_csv(f'{ENI}/asd_mega-analysis_case-controls_CortThick.csv')
asd = asd[asd.Structure.str.startswith('L_')].copy(); asd['region'] = asd.Structure.str[2:]
t5 = pd.DataFrame({
    'Parcel': ock.index,
    'PC1 (hierarchy)': ock.PC1.round(3).values,
    'O': ock.O.round(3).values, 'K': ock.K.round(3).values,
    'E': ock.E.round(3).values, 'S': ock.S.round(3).values,
    'Balance O−K': ock.OCB.round(3).values,
    'Balance, per cell': ock.OCB_percell.round(3).values,
    'Φ baseline': vm.Phi_base.reindex(ock.index).round(3).values,
    'Baseline flux J': vm.flux_base.reindex(ock.index).round(3).values,
    'Metric A (fractional loss)': vm.A_frac_loss.reindex(ock.index).round(3).values,
    'Metric B (excess flux)': vm.B_excess_flux.reindex(ock.index).round(3).values,
}).sort_values('PC1 (hierarchy)')
t5['Autism Cohen d'] = t5.Parcel.map(asd.set_index('region').d_icv)
emit(t5, 'Table5_regional_values',
     'Table 5. Regional layer scores, model quantities and autism case–control effect '
     'sizes for the 34 left cortical parcels of the Desikan–Killiany atlas.')

# ---- Table 6: data sources
src = pd.DataFrame([
    ['Allen Human Brain Atlas', 'Adult cortical microarray, 6 donors',
     'human.brain-map.org', 'Hawrylycz et al. 2012, Nature',
     'processed with abagen 0.1.3 (Markello et al. 2021)'],
    ['BrainSpan', 'Developmental RNA-seq, 8 pcw–40 y',
     'brainspan.org', 'Kang et al. 2011, Nature', '352 neocortical samples, 42 donors'],
    ['Allen cortical snRNA-seq', 'SMART-seq cell-type medians, 121 types',
     'portal.brain-map.org', 'Hodge et al. 2019, Nature', 'cell-type attribution'],
    ['ENIGMA Toolbox', 'Case–control cortical thickness, Desikan–Killiany',
     'github.com/MICA-MNI/ENIGMA', 'Lariviere et al. 2021, Nat Methods; van Rooij et al. 2018',
     'autism mega (n=1,650/1,569) and meta (n=1,060/976); schizophrenia (n=4,343/5,002)'],
    ['SFARI Gene', 'Curated autism risk genes with confidence scores',
     'gene.sfari.org', 'Abrahams et al. 2013, Mol Autism', '1,289 genes'],
    ['Open Targets Platform', 'Target–disease genetic association scores',
     'platform.opentargets.org', 'Ochoa et al. 2023, Nucleic Acids Res',
     'genetic_association datatype only'],
    ['gnomAD v2.1.1', 'Loss-of-function constraint, coding length',
     'gnomad.broadinstitute.org', 'Karczewski et al. 2020, Nature',
     'covariate matching'],
], columns=['Resource', 'Content', 'Access point', 'Primary citation', 'Use here'])
emit(src, 'Table6_data_sources',
     'Table 6. Public data resources used, all openly accessible without restricted-access '
     'agreements.')
print('\nDONE_14')
