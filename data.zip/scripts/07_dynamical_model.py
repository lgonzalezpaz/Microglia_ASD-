"""Biophysical model of complement-dependent synapse elimination with an activity-gated checkpoint.

State variable
  S(tau)   normalised density of functional synapses, S in (0, 1]

Dynamics
  dS/dtau = sigma_r*(1 - S)  -  E_r * S * Phi_r(S)                               (1)
  Phi_r(S) = (m*T_r)^n / [ (m*T_r)^n + ( K_r*(1 + lambda*S) )^n ]                (2)

  sigma_r  region-specific homeostatic synaptogenic replacement rate
  E_r      microglial effector capacity (engulfment throughput)
  T_r      opsonin / 'eat-me' tag load
  K_r      checkpoint ('don't-eat-me') reserve
  lambda   activity-dependent potentiation of checkpoint protection. Network activity
           scales with surviving synapse density, so protection is self-reinforcing and
           equation (1) can admit bistability
  m        multiplicative immune perturbation of opsonin load (m = 1 at baseline)
  n        Hill cooperativity of opsonin-dependent engulfment

HOMEOSTATIC MATCHING. The synaptic-substrate module is spatially flat across the cortex
(step 06), so baseline synaptic density is treated as regionally invariant. For each region
sigma_r is set analytically so that the unperturbed steady state equals S* for every region:

  sigma_r = E_r * S* * Phi_r(S*) / (1 - S*)                                      (3)

Baseline elimination flux is then J_r = E_r*S**Phi_r(S*) = sigma_r*(1 - S*), so regions
differ not in baseline density but in the turnover flux required to sustain it. Regional
vulnerability is the fold-increase in opsonin load that halves synaptic density:

  m50_r : S*_r(m50) = 0.5 * S*,     RPVI_r = -log2(m50_r)                        (4)

Regional parameters are mapped log-linearly from AHBA module z-scores:
  T_r = T0*exp(g*z_O),  K_r = K0*exp(g*z_K),  E_r = E0*exp(g*z_E)                (5)

Outputs: out/model_regional.csv, out/model_bifurcation.csv, out/model_sensitivity.csv,
         out/model_calibration.json
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, itertools
import numpy as np, pandas as pd
from scipy.optimize import brentq
from scipy import stats

OUT = f'{ROOT}/out'

# Human cortex loses roughly 40% of peak synaptic density between early childhood and
# adulthood (Huttenlocher & Dabholkar 1997, J Comp Neurol; Petanjek et al. 2011, PNAS),
# so the mature steady state is anchored at S* = 0.60 of peak.
S_STAR = 0.60
DEFAULTS = dict(n=2.0, lam=1.5, g=0.5, T0=1.0, K0=1.0, E0=1.0)


def phi(S, T, K, n, lam, m):
    a = (m * T) ** n
    b = (K * (1.0 + lam * S)) ** n
    return a / (a + b)


def sigma_matched(T, K, E, n, lam, Sstar=S_STAR):
    """Equation (3): synaptogenic rate enforcing a common baseline density."""
    return E * Sstar * phi(Sstar, T, K, n, lam, 1.0) / (1.0 - Sstar)


def f(S, T, K, E, sig, n, lam, m):
    return sig * (1.0 - S) - E * S * phi(S, T, K, n, lam, m)


def equilibria(T, K, E, sig, n, lam, m, grid=6001):
    S = np.linspace(1e-7, 1.0, grid)
    v = f(S, T, K, E, sig, n, lam, m)
    roots = []
    idx = np.where(np.diff(np.sign(v)) != 0)[0]
    for i in idx:
        try:
            roots.append(brentq(f, S[i], S[i + 1], args=(T, K, E, sig, n, lam, m), xtol=1e-13))
        except ValueError:
            pass
    return np.array(sorted(set(np.round(roots, 11))))


def stable_upper(T, K, E, sig, n, lam, m):
    r = equilibria(T, K, E, sig, n, lam, m)
    if r.size == 0:
        return np.nan
    h = 1e-6
    for s in r[::-1]:
        d = (f(min(s + h, 1.0), T, K, E, sig, n, lam, m)
             - f(max(s - h, 1e-9), T, K, E, sig, n, lam, m))
        if d < 0:
            return s
    return r[-1]


def m_half(T, K, E, sig, n, lam, frac=0.5, mmax=1e4):
    """Equation (4): fold opsonin increase halving synaptic density."""
    thr = frac * S_STAR

    def g_(m):
        s = stable_upper(T, K, E, sig, n, lam, m)
        return (s if np.isfinite(s) else 0.0) - thr
    if g_(1.0) <= 0:
        return 1.0
    if g_(mmax) > 0:
        return np.nan
    return brentq(g_, 1.0, mmax, xtol=1e-9)


def n_eq_profile(T, K, E, sig, n, lam, mmax=50.0, pts=240):
    """Smallest m at which an existing upper branch is annihilated (saddle-node)."""
    ms = np.geomspace(1.0, mmax, pts)
    seen_multi = False
    for m in ms:
        k = equilibria(T, K, E, sig, n, lam, m).size
        if k >= 3:
            seen_multi = True
        elif seen_multi and k < 3:
            return m, True
    return np.nan, seen_multi


# ------------------------------------------------------------------ regional model
ock = pd.read_csv(f'{OUT}/ock_index.csv', index_col=0)
P = DEFAULTS.copy()
T = P['T0'] * np.exp(P['g'] * ock['O'].values)
K = P['K0'] * np.exp(P['g'] * ock['K'].values)
E = P['E0'] * np.exp(P['g'] * ock['E'].values)
sig = sigma_matched(T, K, E, P['n'], P['lam'])

rows = []
for i, r_ in enumerate(ock.index):
    s0 = stable_upper(T[i], K[i], E[i], sig[i], P['n'], P['lam'], 1.0)
    m50 = m_half(T[i], K[i], E[i], sig[i], P['n'], P['lam'])
    msn, bist = n_eq_profile(T[i], K[i], E[i], sig[i], P['n'], P['lam'])
    rows.append(dict(region=r_, T_par=T[i], K_par=K[i], E_par=E[i], sigma=sig[i],
                     S_baseline=s0, Phi_baseline=phi(S_STAR, T[i], K[i], P['n'], P['lam'], 1.0),
                     flux_baseline=sig[i] * (1 - S_STAR), m50=m50,
                     m_saddle=msn, bistable=bool(bist)))
reg = pd.DataFrame(rows).set_index('region')
reg['RPVI'] = -np.log2(reg.m50)
reg = reg.join(ock[['O', 'K', 'E', 'S', 'OCB', 'OCB_percell', 'PC1']])
reg.to_csv(f'{OUT}/model_regional.csv')

print(f"baseline S* recovered: mean {reg.S_baseline.mean():.4f} "
      f"[{reg.S_baseline.min():.4f}-{reg.S_baseline.max():.4f}]  (target {S_STAR})")
print(f"baseline engulfment probability Phi: mean {reg.Phi_baseline.mean():.3f} "
      f"[{reg.Phi_baseline.min():.3f}-{reg.Phi_baseline.max():.3f}]")
print(f"baseline flux J: {reg.flux_baseline.min():.3f}-{reg.flux_baseline.max():.3f} "
      f"({reg.flux_baseline.max()/reg.flux_baseline.min():.2f}-fold range)")
print(f"m50: mean {reg.m50.mean():.3f} [{reg.m50.min():.3f}-{reg.m50.max():.3f}]  "
      f"n missing={int(reg.m50.isna().sum())}")
print(f"bistable regimes encountered: {int(reg.bistable.sum())}/{len(reg)}; "
      f"saddle-node located in {int(reg.m_saddle.notna().sum())}")

print("\nmost vulnerable (lowest tolerated opsonin fold-increase):")
print(reg[['m50', 'RPVI']].nsmallest(8, 'm50').round(3).to_string())
print("\nmost resilient:")
print(reg[['m50', 'RPVI']].nlargest(8, 'm50').round(3).to_string())

print()
for v in ['PC1', 'O', 'K', 'E', 'OCB', 'Phi_baseline', 'flux_baseline']:
    r, p = stats.spearmanr(reg.RPVI, reg[v], nan_policy='omit')
    print(f"  RPVI vs {v:14s}: rho={r:+.3f} p={p:.2g}")

# --------------------------------------------------------- layer flattening
attrib = {}
for hold in ['O', 'K', 'E']:
    Tt, Kk, Ee = T.copy(), K.copy(), E.copy()
    if hold == 'O':
        Tt = np.full_like(T, T.mean())
    if hold == 'K':
        Kk = np.full_like(K, K.mean())
    if hold == 'E':
        Ee = np.full_like(E, E.mean())
    sg = sigma_matched(Tt, Kk, Ee, P['n'], P['lam'])
    v = np.array([-np.log2(m_half(Tt[i], Kk[i], Ee[i], sg[i], P['n'], P['lam']))
                  for i in range(len(ock))])
    good = np.isfinite(v) & np.isfinite(reg.RPVI.values)
    attrib[hold] = dict(retained_rho=float(stats.spearmanr(v[good], reg.RPVI.values[good]).statistic),
                        sd_ratio=float(np.nanstd(v) / np.nanstd(reg.RPVI.values)))
print("\n--- layer flattening (set one layer spatially uniform) ---")
for k, v in attrib.items():
    print(f"  flatten {k}: rho with full model={v['retained_rho']:+.3f}  "
          f"SD retained={v['sd_ratio']:.3f}")

# ------------------------------------------------------------- bifurcation curve
ref = dict(T=float(T.mean()), K=float(K.mean()), E=float(E.mean()))
ref['sigma'] = float(sigma_matched(ref['T'], ref['K'], ref['E'], P['n'], P['lam']))
bif = []
for m in np.geomspace(1.0, 30.0, 300):
    r_ = equilibria(ref['T'], ref['K'], ref['E'], ref['sigma'], P['n'], P['lam'], m)
    bif.append(dict(m=m, n_eq=int(r_.size),
                    S_min=(float(r_.min()) if r_.size else np.nan),
                    S_max=(float(r_.max()) if r_.size else np.nan),
                    S_stable_upper=stable_upper(ref['T'], ref['K'], ref['E'], ref['sigma'],
                                                P['n'], P['lam'], m)))
pd.DataFrame(bif).to_csv(f'{OUT}/model_bifurcation.csv', index=False)

# ------------------------------------------------------------- sensitivity sweep
sens = []
for n_, lam_, g_ in itertools.product([1.0, 2.0, 3.0, 4.0], [0.0, 0.75, 1.5, 3.0], [0.25, 0.5, 1.0]):
    Tp = P['T0'] * np.exp(g_ * ock['O'].values)
    Kp = P['K0'] * np.exp(g_ * ock['K'].values)
    Ep = P['E0'] * np.exp(g_ * ock['E'].values)
    sp = sigma_matched(Tp, Kp, Ep, n_, lam_)
    v = np.array([-np.log2(m_half(Tp[i], Kp[i], Ep[i], sp[i], n_, lam_))
                  for i in range(len(ock))])
    good = np.isfinite(v)
    if good.sum() < 25:
        continue
    sens.append(dict(n=n_, lam=lam_, g=g_, n_valid=int(good.sum()),
                     rho_vs_PC1=round(float(stats.spearmanr(v[good], ock['PC1'].values[good]).statistic), 4),
                     rho_vs_default=round(float(stats.spearmanr(v[good], reg.RPVI.values[good],
                                                                nan_policy='omit').statistic), 4)))
sens = pd.DataFrame(sens)
sens.to_csv(f'{OUT}/model_sensitivity.csv', index=False)
print(f"\n--- sensitivity across {len(sens)} parameter sets ---")
print(f"RPVI vs PC1 axis : median rho={sens.rho_vs_PC1.median():+.3f} "
      f"[{sens.rho_vs_PC1.min():+.3f}, {sens.rho_vs_PC1.max():+.3f}]")
print(f"RPVI vs default  : median rho={sens.rho_vs_default.median():+.3f} "
      f"[{sens.rho_vs_default.min():+.3f}, {sens.rho_vs_default.max():+.3f}]")

json.dump({'defaults': P, 'S_star': S_STAR, 'reference_params': ref,
           'layer_flattening': attrib,
           'homeostatic_matching': 'sigma_r set analytically per equation (3)'},
          open(f'{OUT}/model_calibration.json', 'w'), indent=1)
print('\nDONE_07')
