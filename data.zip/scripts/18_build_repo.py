"""Assemble the GitHub/Zenodo reproducibility package."""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import hashlib, json, os, shutil, subprocess

W = f'{ROOT}'
R = f'{W}/release/pruning-axis-autism'
for sub in ['scripts', 'data/modules', 'results', 'figures', 'tables', 'manuscript']:
    os.makedirs(f'{R}/{sub}', exist_ok=True)

# ---- code
for f in sorted(os.listdir(f'{W}/scripts')):
    if f.endswith(('.py', '.js')):
        shutil.copy(f'{W}/scripts/{f}', f'{R}/scripts/{f}')

# ---- make released scripts path-independent ------------------------------------
# Scripts are authored with absolute working paths; rewrite them so a cloned repo
# resolves everything relative to the repository root (overridable via $PRUNING_AXIS_ROOT).
import re as _re
PY_HEADER = (
    "import os as _os\n"
    "from pathlib import Path as _Path\n"
    "ROOT = _os.environ.get('PRUNING_AXIS_ROOT',\n"
    "                       str(_Path(__file__).resolve().parents[1]))\n"
)
_pat = _re.compile(r"(?<![A-Za-z0-9_])(f?)(['\"])/home/claude/work(/[^'\"]*)?\2")


def _relativise_py(text):
    def rep(m):
        q = m.group(2)
        tail = m.group(3) or ''
        return f"f{q}{{ROOT}}{tail}{q}"
    new, n = _pat.subn(rep, text)
    if n == 0:
        return text, 0
    lines = new.split('\n')
    # insert the header after the module docstring and any __future__ import
    ins = 0
    if lines and lines[0].startswith(('\"\"\"', "'''")):
        q = lines[0][:3]
        if lines[0].count(q) >= 2 and len(lines[0]) > 3:
            ins = 1
        else:
            for k in range(1, len(lines)):
                if q in lines[k]:
                    ins = k + 1
                    break
    lines.insert(ins, PY_HEADER.rstrip('\n'))
    return '\n'.join(lines), n


for f in sorted(os.listdir(f'{R}/scripts')):
    q = f'{R}/scripts/{f}'
    txt = open(q).read()
    if f.endswith('.py'):
        txt, n = _relativise_py(txt)
        if n:
            open(q, 'w').write(txt)
            print(f'  path-rewrote {f} ({n} literals)')
    elif f.endswith('.js'):
        if f'{ROOT}' in txt:
            txt = txt.replace(
                "const MS = f'{ROOT}/manuscript';",
                "const path = require('path');\n"
                "const ROOT = process.env.PRUNING_AXIS_ROOT || path.resolve(__dirname, '..');\n"
                "const MS = path.join(ROOT, 'manuscript');")
            txt = txt.replace("'/home/claude/work/", "ROOT + '/")
            open(q, 'w').write(txt)
            print(f'  path-rewrote {f}')

# ---- inputs that are ours (small, curated)
shutil.copy(f'{W}/data/modules/pruning_axis_modules.csv', f'{R}/data/modules/')
shutil.copy(f'{W}/data/modules/doi_final.txt', f'{R}/data/modules/')

# ---- derived results (exclude large intermediate matrices)
SKIP_PREFIX = ('ahba_donor_', 'ahba_dk_group', 'ahba_donors')
for f in sorted(os.listdir(f'{W}/out')):
    if f.startswith(SKIP_PREFIX):
        continue
    if f.endswith(('.csv', '.json', '.txt')):
        shutil.copy(f'{W}/out/{f}', f'{R}/results/{f}')

for f in sorted(os.listdir(f'{W}/figures')):
    shutil.copy(f'{W}/figures/{f}', f'{R}/figures/{f}')
for f in sorted(os.listdir(f'{W}/tables')):
    shutil.copy(f'{W}/tables/{f}', f'{R}/tables/{f}')
for f in ['manuscript_source.md', 'manuscript.md', 'manuscript.docx',
          'manuscript_ast.json', 'references_map.json']:
    if os.path.exists(f'{W}/manuscript/{f}'):
        shutil.copy(f'{W}/manuscript/{f}', f'{R}/manuscript/{f}')

# ---- environments
open(f'{R}/requirements.txt', 'w').write("""# Main analysis environment (Python 3.13)
numpy>=2.0
pandas>=2.2
scipy>=1.14
scikit-learn>=1.5
statsmodels>=0.14
sympy>=1.13
matplotlib>=3.9
brainsmash==0.11.0
nibabel>=5.2
tabulate>=0.9
""")
open(f'{R}/requirements-abagen.txt', 'w').write("""# AHBA processing environment (Python 3.11 ONLY).
# abagen 0.1.3 predates pandas 2.x removals (groupby(axis=1), set_axis(inplace=)),
# so this step requires a pinned, separate interpreter.
numpy==1.24.4
pandas==1.5.3
scipy==1.10.1
nibabel==5.1.0
nilearn==0.10.1
abagen==0.1.3
setuptools==69.5.1
brainsmash==0.11.0
""")

open(f'{R}/environment.yml', 'w').write("""name: pruning-axis
channels: [conda-forge]
dependencies:
  - python=3.13
  - numpy>=2.0
  - pandas>=2.2
  - scipy>=1.14
  - scikit-learn>=1.5
  - statsmodels>=0.14
  - sympy>=1.13
  - matplotlib>=3.9
  - nibabel>=5.2
  - pandoc
  - nodejs
  - pip
  - pip:
      - brainsmash==0.11.0
      - tabulate>=0.9
""")

# ---- orchestration
open(f'{R}/run_all.sh', 'w').write("""#!/usr/bin/env bash
# Reproduce every number, table and figure from raw public data.
# Requires: python3.13 (main env), python3.11 (abagen env), node, pandoc, ~6 GB disk.
set -euo pipefail
cd "$(dirname "$0")"

PY_MAIN=${PY_MAIN:-python3}
PY_ABAGEN=${PY_ABAGEN:-./.venv_abagen/bin/python}

echo "== 0. environments =="
$PY_MAIN -m pip install -q -r requirements.txt
if [ ! -x "$PY_ABAGEN" ]; then
  python3.11 -m venv .venv_abagen
  ./.venv_abagen/bin/pip install -q --upgrade pip
  ./.venv_abagen/bin/pip install -q -r requirements-abagen.txt
fi

echo "== 1. fetch public data (~4 GB; Allen Human Brain Atlas) =="
$PY_ABAGEN scripts/00_fetch_ahba.py
bash scripts/00b_fetch_other_data.sh

echo "== 2. regional expression (Python 3.11 / abagen) =="
$PY_ABAGEN scripts/01_ahba_expression.py

echo "== 3. external gene-level resources =="
$PY_MAIN scripts/02_opentargets.py

echo "== 4. bibliography verification =="
$PY_MAIN scripts/03_verify_refs.py data/modules/doi_final.txt

echo "== 5. analyses =="
$PY_MAIN scripts/05_regional_modules.py
$PY_MAIN scripts/06_composition_control.py
$PY_MAIN scripts/07_dynamical_model.py
$PY_MAIN scripts/08_vulnerability_metrics.py
$PY_ABAGEN scripts/09_validate_enigma.py
$PY_MAIN scripts/10_genetic_partition.py
$PY_MAIN scripts/11_brainspan_development.py
$PY_MAIN scripts/12_robustness.py

echo "== 6. outputs =="
$PY_MAIN scripts/13_figures.py
$PY_MAIN scripts/14_tables.py
$PY_MAIN scripts/15_build_manuscript.py
$PY_MAIN scripts/16_md_to_ast.py
node scripts/17_build_docx.js

echo "== done: see figures/, tables/, results/, manuscript/ =="
""")
os.chmod(f'{R}/run_all.sh', 0o755)

# data fetch helper
open(f'{R}/scripts/00b_fetch_other_data.sh', 'w').write("""#!/usr/bin/env bash
# Download the public datasets other than the Allen Human Brain Atlas.
set -euo pipefail
mkdir -p data/brainspan data/celltype data/genesets data/enigma

echo "-- BrainSpan developmental RNA-seq (gene-level RPKM)"
curl -sSL -o data/brainspan_rnaseq_gene.zip \\
  "https://www.brainspan.org/api/v2/well_known_file_download/267666525"
unzip -o -q data/brainspan_rnaseq_gene.zip -d data/brainspan

echo "-- Allen human cortex SMART-seq cell-type medians"
curl -sSL -o data/celltype/allen_ctx_smartseq_medians.csv \\
  "https://idk-etl-prod-download-bucket.s3.amazonaws.com/aibs_human_ctx_smart-seq/medians.csv"

echo "-- SFARI Gene"
curl -sSL -o data/genesets/sfari_genes.csv \\
  "https://gene.sfari.org/wp-content/themes/sfari-gene/utilities/download-csv.php?api-endpoint=genes"

echo "-- gnomAD v2.1.1 constraint"
curl -sSL -o data/genesets/gnomad_constraint.txt.bgz \\
  "https://storage.googleapis.com/gcp-public-data--gnomad/release/2.1.1/constraint/gnomad.v2.1.1.lof_metrics.by_gene.txt.bgz"

echo "-- ENIGMA Toolbox (case-control summary statistics)"
[ -d data/enigma ] && rm -rf data/enigma
git clone --depth 1 -q https://github.com/MICA-MNI/ENIGMA.git data/enigma

echo "done"
""")
os.chmod(f'{R}/scripts/00b_fetch_other_data.sh', 0o755)

# ---- licences
open(f'{R}/LICENSE', 'w').write("""MIT License

Copyright (c) 2026 [AUTHOR]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
""")
open(f'{R}/LICENSE-DATA', 'w').write("""Derived data files in results/, tables/ and figures/ are released under
Creative Commons Attribution 4.0 International (CC BY 4.0).
https://creativecommons.org/licenses/by/4.0/

Upstream datasets remain under their own terms:
  Allen Human Brain Atlas / BrainSpan / Allen cell types  - Allen Institute Terms of Use
  ENIGMA Toolbox summary statistics                        - see MICA-MNI/ENIGMA
  SFARI Gene                                               - SFARI terms
  Open Targets Platform                                    - CC0 1.0
  gnomAD                                                   - ODbL / see gnomad.broadinstitute.org
No raw upstream data are redistributed here; scripts download them from source.
""")

json.dump({
    "title": "Microglia execute but do not specify: target-encoded autism risk and the "
             "developmental timing of complement-dependent synaptic pruning in human cortex",
    "upload_type": "software",
    "license": "MIT",
    "description": "Analysis code, derived results, figures and tables for a study "
                   "partitioning the synaptic pruning axis into opsonin, checkpoint, "
                   "microglial effector and synaptic substrate layers, and testing the "
                   "causal attribution and regional specificity of microglial pruning in "
                   "idiopathic autism using openly available human data.",
    "keywords": ["autism", "synaptic pruning", "complement", "microglia",
                 "imaging transcriptomics", "cortical hierarchy", "neurodevelopment"],
    "creators": [{"name": "[AUTHOR]", "affiliation": "[AFFILIATION]"}],
}, open(f'{R}/.zenodo.json', 'w'), indent=2)

open(f'{R}/CITATION.cff', 'w').write("""cff-version: 1.2.0
message: "If you use this software, please cite both the software and the article."
title: "Pruning axis analysis: target-encoded autism risk and developmental timing"
version: "1.0.0"
license: MIT
authors:
  - family-names: "[SURNAME]"
    given-names: "[GIVEN NAMES]"
""")

open(f'{R}/.gitignore', 'w').write(""".venv_abagen/
data/ahba/
data/brainspan/
data/celltype/
data/enigma/
data/genesets/
data/*.zip
__pycache__/
*.pyc
""")

# ---- checksums of released derived files
lines = []
for root, _, files in os.walk(R):
    for f in sorted(files):
        p = os.path.join(root, f)
        rel = os.path.relpath(p, R)
        if rel == 'CHECKSUMS.sha256':
            continue
        h = hashlib.sha256(open(p, 'rb').read()).hexdigest()
        lines.append(f'{h}  {rel}')
open(f'{R}/CHECKSUMS.sha256', 'w').write('\n'.join(sorted(lines)) + '\n')
print(f'{len(lines)} files checksummed')
print('repo at', R)
