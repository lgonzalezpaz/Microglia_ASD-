"""Fetch Open Targets Platform target-disease associations; retain the genetic-evidence component.

The overall Open Targets association score aggregates literature text-mining, which would
circularly reward well-studied microglial genes. We therefore retain only the
`genetic_association` datatype score for all downstream inference.
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, subprocess, time, pandas as pd

URL = "https://api.platform.opentargets.org/api/v4/graphql"
Q = """{disease(efoId:"%s"){id name associatedTargets(page:{index:%d,size:%d}){
 count rows{score target{approvedSymbol id} datatypeScores{id score}}}}}"""


def fetch(efo, size=500, maxpages=25):
    rows, total = [], None
    for i in range(maxpages):
        q = Q % (efo, i, size)
        p = subprocess.run(
            ['curl', '-sS', '--max-time', '150', '-X', 'POST', URL,
             '-H', 'Content-Type: application/json',
             '-d', json.dumps({"query": q})],
            capture_output=True, text=True, timeout=180)
        try:
            j = json.loads(p.stdout)
        except Exception:
            print("PARSE FAIL page", i, p.stdout[:300]); break
        d = (j.get('data') or {}).get('disease')
        if not d:
            print("NO DATA", str(j)[:300]); break
        at = d['associatedTargets']; total = at['count']
        if not at['rows']:
            break
        for r in at['rows']:
            dts = {x['id']: x['score'] for x in (r.get('datatypeScores') or [])}
            rows.append({'symbol': r['target']['approvedSymbol'],
                         'ensembl': r['target']['id'],
                         'overall_score': r['score'],
                         'genetic_association': dts.get('genetic_association', 0.0),
                         'literature': dts.get('literature', 0.0),
                         'rna_expression': dts.get('rna_expression', 0.0)})
        print(f"  page {i}: cum {len(rows)} / {total}", flush=True)
        if len(rows) >= total:
            break
        time.sleep(0.4)
    return pd.DataFrame(rows), total


if __name__ == "__main__":
    for name, efo in [('asd', 'MONDO_0005260'), ('scz', 'MONDO_0005090')]:
        df, tot = fetch(efo)
        if len(df) == 0:
            print(name, "EMPTY"); continue
        df = df.drop_duplicates('symbol')
        out = f'{ROOT}/data/genesets/opentargets_{name}_genetic.csv'
        df.to_csv(out, index=False)
        print(name, 'genes', len(df), 'reported total', tot,
              'genetic>0:', int((df.genetic_association > 0).sum()))
    print("OT_DONE")
