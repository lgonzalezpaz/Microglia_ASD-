"""Verify bibliographic references against Crossref and PubMed.

For each DOI: retrieve authoritative metadata (title, authors, journal, year, volume,
pages/article-number) and emit a Vancouver-style reference string. Any DOI that fails
to resolve is reported so it can be removed or corrected; nothing is written from memory.
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, subprocess, sys, time, csv, os

MAIL = "lgonzalezpaz@gmail.com"
OUT = f"{ROOT}/out"


def curl(url, timeout=90):
    p = subprocess.run(['curl', '-sS', '--max-time', str(timeout), '-A',
                        f'ref-verify/1.0 (mailto:{MAIL})', url],
                       capture_output=True, text=True, timeout=timeout + 30)
    return p.stdout


def crossref(doi):
    raw = curl(f"https://api.crossref.org/works/{doi}?mailto={MAIL}")
    try:
        m = json.loads(raw)['message']
    except Exception:
        return None
    auth = []
    for a in m.get('author', []) or []:
        fam = a.get('family')
        giv = a.get('given', '') or ''
        if not fam:
            continue
        inits = ''.join(x[0] for x in giv.replace('-', ' ').split() if x and x[0].isalpha())
        auth.append(f"{fam} {inits}".strip())
    date = (m.get('published-print') or m.get('published-online')
            or m.get('published') or m.get('issued') or {})
    parts = (date.get('date-parts') or [[None]])[0]
    year = parts[0] if parts else None
    return {
        'doi': doi,
        'title': (m.get('title') or [''])[0].strip(),
        'journal': (m.get('short-container-title') or m.get('container-title') or [''])[0],
        'journal_full': (m.get('container-title') or [''])[0],
        'year': year,
        'volume': m.get('volume'),
        'pages': m.get('page'),
        'article_number': m.get('article-number'),
        'authors': auth,
        'n_authors': len(auth),
        'type': m.get('type'),
    }


def pubmed(doi):
    raw = curl("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
               f"?db=pubmed&term={doi}[DOI]&retmode=json&email={MAIL}")
    try:
        ids = json.loads(raw)['esearchresult']['idlist']
    except Exception:
        return None
    if not ids:
        return None
    pmid = ids[0]
    raw2 = curl("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
                f"?db=pubmed&id={pmid}&retmode=json&email={MAIL}")
    try:
        r = json.loads(raw2)['result'][pmid]
    except Exception:
        return {'pmid': pmid}
    return {'pmid': pmid, 'source': r.get('source'), 'pubdate': r.get('pubdate'),
            'volume': r.get('volume'), 'pages': r.get('pages'),
            'title': r.get('title', '').rstrip('.'),
            'authors': [a['name'] for a in r.get('authors', []) if a.get('authtype') == 'Author']}


def vancouver(c, p=None):
    """Nature/Vancouver: up to 6 authors then et al."""
    auth = c['authors'] or (p or {}).get('authors') or []
    if len(auth) > 6:
        astr = ', '.join(auth[:6]) + ', et al.'
    else:
        astr = ', '.join(auth)
    title = c['title'].rstrip('.')
    jour = c['journal'] or c['journal_full']
    vol = c['volume'] or (p or {}).get('volume') or ''
    pg = c['pages'] or c['article_number'] or (p or {}).get('pages') or ''
    yr = c['year'] or ''
    loc = f"{vol}, {pg}" if vol and pg else (str(vol) or str(pg))
    return f"{astr}. {title}. {jour}. {yr};{loc}. doi:{c['doi']}"


def main(dois):
    rows = []
    for doi in dois:
        doi = doi.strip()
        if not doi or doi.startswith('#'):
            continue
        c = crossref(doi)
        if c is None:
            print(f"UNRESOLVED\t{doi}")
            rows.append({'doi': doi, 'status': 'UNRESOLVED'})
            time.sleep(0.3)
            continue
        p = pubmed(doi)
        ok_title = True
        if p and p.get('title'):
            a = ''.join(ch.lower() for ch in c['title'] if ch.isalnum())
            b = ''.join(ch.lower() for ch in p['title'] if ch.isalnum())
            ok_title = (a[:60] == b[:60])
        rows.append({
            'doi': doi, 'status': 'OK', 'title': c['title'],
            'journal': c['journal'], 'journal_full': c['journal_full'],
            'year': c['year'], 'volume': c['volume'],
            'pages': c['pages'], 'article_number': c['article_number'],
            'first_author': c['authors'][0] if c['authors'] else '',
            'n_authors': c['n_authors'], 'type': c['type'],
            'pmid': (p or {}).get('pmid', ''),
            'pubmed_journal': (p or {}).get('source', ''),
            'pubmed_pubdate': (p or {}).get('pubdate', ''),
            'title_match_pubmed': ok_title,
            'vancouver': vancouver(c, p),
        })
        print(f"OK\t{doi}\t{c['year']}\t{c['journal']}\t{c['title'][:70]}")
        time.sleep(0.3)
    os.makedirs(OUT, exist_ok=True)
    keys = sorted({k for r in rows for k in r})
    with open(f"{OUT}/references_verified.csv", 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    nbad = sum(1 for r in rows if r.get('status') != 'OK')
    print(f"\nTOTAL {len(rows)}  UNRESOLVED {nbad}")
    return rows


if __name__ == "__main__":
    src = sys.argv[1]
    with open(src) as f:
        main([l for l in f.read().splitlines()])
