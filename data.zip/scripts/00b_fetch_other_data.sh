#!/usr/bin/env bash
# Download the public datasets other than the Allen Human Brain Atlas.
set -euo pipefail
mkdir -p data/brainspan data/celltype data/genesets data/enigma

echo "-- BrainSpan developmental RNA-seq (gene-level RPKM)"
curl -sSL -o data/brainspan_rnaseq_gene.zip \
  "https://www.brainspan.org/api/v2/well_known_file_download/267666525"
unzip -o -q data/brainspan_rnaseq_gene.zip -d data/brainspan

echo "-- Allen human cortex SMART-seq cell-type medians"
curl -sSL -o data/celltype/allen_ctx_smartseq_medians.csv \
  "https://idk-etl-prod-download-bucket.s3.amazonaws.com/aibs_human_ctx_smart-seq/medians.csv"

echo "-- SFARI Gene"
curl -sSL -o data/genesets/sfari_genes.csv \
  "https://gene.sfari.org/wp-content/themes/sfari-gene/utilities/download-csv.php?api-endpoint=genes"

echo "-- gnomAD v2.1.1 constraint"
curl -sSL -o data/genesets/gnomad_constraint.txt.bgz \
  "https://storage.googleapis.com/gcp-public-data--gnomad/release/2.1.1/constraint/gnomad.v2.1.1.lof_metrics.by_gene.txt.bgz"

echo "-- ENIGMA Toolbox (case-control summary statistics)"
[ -d data/enigma ] && rm -rf data/enigma
git clone --depth 1 -q https://github.com/MICA-MNI/ENIGMA.git data/enigma

echo "done"
