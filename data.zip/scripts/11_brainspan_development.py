"""Developmental timing of the pruning axis across human cortical regions.

Data: BrainSpan developmental transcriptome, gene-level RNA-seq RPKM (Kang et al. 2011,
Nature), 8 post-conception weeks to 40 years, 11 neocortical regions, 42 donors.

Scope and caveat. Transcript abundance of synaptic structural genes rises monotonically into
adulthood and therefore does NOT index synapse density, which declines after early childhood.
We consequently do not treat the synaptic-substrate module (S) as a density proxy; it is
reported descriptively only. The regulatory layers (opsonin O, checkpoint K, effector E)
are interpreted as pathway engagement, which is what the model's parameters represent.

Question: is the pruning machinery engaged over a longer, later-closing developmental window
in association cortex than in primary sensory/motor cortex? Classical histology reports a
protracted synaptogenic and pruning window in prefrontal relative to sensory cortex
(Huttenlocher & Dabholkar 1997, J Comp Neurol; Petanjek et al. 2011, PNAS).

Statistics. With 11 regions and 4 primary / 7 association, the label assignment admits
C(11,4) = 330 arrangements, so the primary-vs-association contrast is tested by EXACT
permutation over region labels. Trajectory features are bootstrapped over donors.

Outputs: out/brainspan_trajectories.csv, out/brainspan_window.csv,
         out/brainspan_contrasts.csv, out/brainspan_qc.json
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, re
from itertools import combinations
import numpy as np, pandas as pd
from scipy import stats
from scipy.interpolate import UnivariateSpline

BS = f'{ROOT}/data/brainspan'
OUT = f'{ROOT}/out'
rng = np.random.default_rng(20261025)

PRIMARY = ['V1C', 'M1C', 'S1C', 'A1C']
ASSOCIATION = ['DFC', 'VFC', 'OFC', 'MFC', 'STC', 'ITC', 'IPC']
NEOCORTEX = PRIMARY + ASSOCIATION
GEST = 280.0
AGE_RE = re.compile(r'^([\d.]+)\s*(pcw|mos|yrs)$')


def age_to_pcd(a):
    m = AGE_RE.match(a.strip())
    v, u = float(m.group(1)), m.group(2)
    return v * 7.0 if u == 'pcw' else (GEST + v * 30.44 if u == 'mos' else GEST + v * 365.25)


cols = pd.read_csv(f'{BS}/columns_metadata.csv')
rows = pd.read_csv(f'{BS}/rows_metadata.csv')
cols['pcd'] = cols.age.map(age_to_pcd)
cols['log_pcd'] = np.log10(cols.pcd)
keep = cols[cols.structure_acronym.isin(NEOCORTEX)].copy()

mod = pd.read_csv(f'{ROOT}/data/modules/pruning_axis_modules.csv')
mod['gene'] = mod.gene.str.upper()
rows['gene_symbol'] = rows.gene_symbol.str.upper()
sel = rows[rows.gene_symbol.isin(set(mod.gene))]
need = set(sel.row_num.values)
vals = {}
with open(f'{BS}/expression_matrix.csv') as f:
    for line in f:
        i = line.index(',')
        rn = int(line[:i])
        if rn in need:
            vals[rn] = np.array(line[i + 1:].split(','), dtype=float)
X = pd.DataFrame(vals).T
X.columns = cols.column_num.values
X = X.join(sel.set_index('row_num')['gene_symbol']).groupby('gene_symbol').mean()
print(f'neocortical samples {len(keep)}; module genes in BrainSpan '
      f'{sel.gene_symbol.nunique()}/{mod.gene.nunique()}')

L = np.log2(X[keep.column_num.values] + 1.0)
Z = L.sub(L.mean(axis=1), axis=0).div(L.std(axis=1, ddof=1).replace(0, np.nan), axis=0).dropna(how='all')
S = pd.DataFrame({m: Z.loc[[x for x in sub.gene.unique() if x in Z.index]].mean(axis=0)
                  for m, sub in mod.groupby('module')})
S.index = keep.column_num.values
traj = pd.concat([keep.set_index('column_num')[['structure_acronym', 'age', 'pcd',
                                                'log_pcd', 'donor_id', 'gender']], S], axis=1)
traj['hierarchy'] = np.where(traj.structure_acronym.isin(PRIMARY), 'primary', 'association')
traj['OCB'] = traj['O'] - traj['K']
traj.to_csv(f'{OUT}/brainspan_trajectories.csv')

GRID = np.linspace(np.log10(56), np.log10(GEST + 40 * 365.25), 500)
POSTNATAL = GRID > np.log10(GEST)


def features(sub, m, s_factor=0.35):
    """Spline-smoothed trajectory features for one region and one module."""
    x, y = sub.log_pcd.values, sub[m].values
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if len(x) < 8:
        return None
    xu, idx = np.unique(x, return_inverse=True)
    yu = np.array([y[idx == i].mean() for i in range(len(xu))])
    if len(xu) < 6:
        return None
    sp = UnivariateSpline(xu, yu, s=len(xu) * s_factor, k=3)
    f = sp(GRID)
    rngv = f.max() - f.min()
    if rngv <= 0:
        return None
    nrm = (f - f.min()) / rngv
    ap = int(np.argmax(f))
    # age at which the trajectory first reaches 90% of its maximum
    i90 = int(np.argmax(nrm >= 0.90))
    # fraction of the postnatal interval spent above 75% of maximum = window openness
    openness = float(np.mean(nrm[POSTNATAL] >= 0.75))
    return dict(peak_log_pcd=float(GRID[ap]),
                peak_years=float((10 ** GRID[ap] - GEST) / 365.25),
                t90_years=float((10 ** GRID[i90] - GEST) / 365.25),
                window_openness=openness,
                amplitude=float(rngv))


feat = []
for reg, sub in traj.groupby('structure_acronym'):
    row = dict(region=reg, n=len(sub),
               hierarchy='primary' if reg in PRIMARY else 'association')
    for m in ['O', 'K', 'E', 'S', 'OCB']:
        f = features(sub.sort_values('log_pcd'), m)
        if f:
            row.update({f'{m}_{k}': v for k, v in f.items()})
    feat.append(row)
fe = pd.DataFrame(feat).set_index('region')
fe.to_csv(f'{OUT}/brainspan_window.csv')

print('\n--- developmental timing of the opsonin and effector layers ---')
print(fe[['hierarchy', 'O_peak_years', 'O_t90_years', 'E_peak_years', 'E_t90_years',
          'K_peak_years', 'O_window_openness']].sort_values('O_peak_years').round(2).to_string())


def exact_perm(values, is_primary):
    """Exact permutation test of the association-minus-primary mean difference."""
    v = np.asarray(values, float)
    ok = np.isfinite(v)
    v, isp = v[ok], np.asarray(is_primary)[ok]
    n, k = len(v), int(isp.sum())
    if k < 2 or n - k < 2:
        return np.nan, np.nan, np.nan
    obs = v[~isp].mean() - v[isp].mean()
    idx = np.arange(n)
    diffs = []
    for c in combinations(idx, k):
        mask = np.zeros(n, bool); mask[list(c)] = True
        diffs.append(v[~mask].mean() - v[mask].mean())
    diffs = np.array(diffs)
    p = (np.sum(np.abs(diffs) >= abs(obs) - 1e-12)) / len(diffs)
    return float(obs), float(p), len(diffs)


isp = fe.hierarchy.eq('primary').values
crows = []
print('\n--- primary vs association, exact permutation over region labels ---')
for v in [c for c in fe.columns if any(c.startswith(m + '_') for m in ['O', 'K', 'E', 'S', 'OCB'])]:
    obs, p, nperm = exact_perm(fe[v].values, isp)
    if not np.isfinite(p):
        continue
    a = fe.loc[~isp, v].mean(); b = fe.loc[isp, v].mean()
    crows.append(dict(feature=v, association_mean=round(a, 4), primary_mean=round(b, 4),
                      difference=round(obs, 4), p_exact=round(p, 5), n_arrangements=nperm))
con = pd.DataFrame(crows).sort_values('p_exact')
# Benjamini-Hochberg across features
p = con.p_exact.values
o = np.argsort(p); q = p[o] * len(p) / (np.arange(len(p)) + 1)
q = np.minimum.accumulate(q[::-1])[::-1]
fdr = np.empty_like(q); fdr[o] = np.clip(q, 0, 1)
con['p_fdr'] = np.round(fdr, 4)
con.to_csv(f'{OUT}/brainspan_contrasts.csv', index=False)
print(con.to_string(index=False))

# ------------------------------------------- donor bootstrap on the key contrast
print('\n--- donor bootstrap (2000 resamples) on O and E peak timing difference ---')
donors = traj.donor_id.unique()
boot = {'O': [], 'E': []}
for _ in range(2000):
    d = rng.choice(donors, size=len(donors), replace=True)
    sub = pd.concat([traj[traj.donor_id == x] for x in d])
    vals_ = {}
    for reg, g in sub.groupby('structure_acronym'):
        for m in ['O', 'E']:
            f = features(g.sort_values('log_pcd'), m)
            if f:
                vals_.setdefault(m, {})[reg] = f['peak_years']
    for m in ['O', 'E']:
        v = vals_.get(m, {})
        a = [v[r] for r in ASSOCIATION if r in v]
        b = [v[r] for r in PRIMARY if r in v]
        if len(a) >= 4 and len(b) >= 2:
            boot[m].append(np.mean(a) - np.mean(b))
for m in ['O', 'E']:
    arr = np.array(boot[m])
    if arr.size:
        lo, hi = np.percentile(arr, [2.5, 97.5])
        print(f'  {m} peak-age difference (assoc - primary): {arr.mean():+.2f} years '
              f'[95% CI {lo:+.2f}, {hi:+.2f}]  P(>0)={np.mean(arr>0):.3f}  n={arr.size}')

# ------------------------------------------- postnatal layer levels
post = traj[traj.pcd > GEST]
print(f'\n--- postnatal samples ({len(post)}): layer levels by hierarchy ---')
for m in ['O', 'K', 'E', 'S', 'OCB']:
    a = post.loc[post.hierarchy == 'association', m]
    b = post.loc[post.hierarchy == 'primary', m]
    U, p = stats.mannwhitneyu(a, b, alternative='two-sided')
    print(f'  {m:4s} association={a.mean():+.3f} primary={b.mean():+.3f} '
          f'p={p:.3g} CL={U/(len(a)*len(b)):.2f}')

json.dump({'n_samples': int(len(keep)), 'n_donors': int(traj.donor_id.nunique()),
           'primary': PRIMARY, 'association': ASSOCIATION, 'gestation_days': GEST,
           'module_genes_in_brainspan': int(sel.gene_symbol.nunique()),
           'caveat': 'synaptic transcript abundance is not a synapse-density proxy; '
                     'module S reported descriptively only'},
          open(f'{OUT}/brainspan_qc.json', 'w'), indent=1)
print('\nDONE_11')
