"""Resolve citation keys to Vancouver-numbered references and emit Markdown + DOCX."""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, re, subprocess, os

MS = f'{ROOT}/manuscript'
src = open(f'{MS}/manuscript_source.md').read()
refs = json.load(open(f'{MS}/references_map.json'))

# ---- assign numbers in order of first appearance
order, seen = [], set()
for m in re.finditer(r'\{\{([a-z0-9]+)\}\}', src):
    k = m.group(1)
    if k == 'REFERENCES':
        continue
    if k not in refs:
        raise SystemExit(f'UNKNOWN CITATION KEY: {k}')
    if k not in seen:
        seen.add(k); order.append(k)
num = {k: i + 1 for i, k in enumerate(order)}
print(f'{len(order)} references cited, of {len(refs)} verified')
unused = [k for k in refs if k not in seen]
if unused:
    print('verified but not cited (dropped from list):', unused)


def sub_run(text):
    """Collapse consecutive citation markers into a single superscript run."""
    def rep(m):
        ks = re.findall(r'\{\{([a-z0-9]+)\}\}', m.group(0))
        ns = sorted({num[k] for k in ks})
        # contract runs of consecutive numbers
        out, i = [], 0
        while i < len(ns):
            j = i
            while j + 1 < len(ns) and ns[j + 1] == ns[j] + 1:
                j += 1
            out.append(str(ns[i]) if j == i else
                       (f'{ns[i]},{ns[j]}' if j == i + 1 else f'{ns[i]}–{ns[j]}'))
            i = j + 1
        return '^' + ','.join(out) + '^'
    return re.sub(r'(\{\{[a-z0-9]+\}\})+', rep, text)


body = sub_run(src)
reflist = '\n'.join(f'{num[k]}. {refs[k]}' for k in order)
body = body.replace('^{{REFERENCES}}^', reflist).replace('{{REFERENCES}}', reflist)

open(f'{MS}/manuscript.md', 'w').write(body)
print('wrote manuscript.md')

# ---- DOCX via pandoc with a reference style
ref_docx = f'{MS}/_style_reference.docx'
if not os.path.exists(ref_docx):
    subprocess.run(['pandoc', '-o', ref_docx, '--print-default-data-file', 'reference.docx'],
                   capture_output=True)
    with open(ref_docx, 'wb') as f:
        f.write(subprocess.run(['pandoc', '--print-default-data-file', 'reference.docx'],
                               capture_output=True).stdout)

cmd = ['pandoc', f'{MS}/manuscript.md', '-o', f'{MS}/manuscript.docx',
       '--from', 'markdown+superscript+subscript+tex_math_dollars',
       '--reference-doc', ref_docx, '--standalone']
r = subprocess.run(cmd, capture_output=True, text=True)
print('pandoc docx:', r.returncode, r.stderr[:400])

# word count of the body (excluding references)
txt = body.split('## References')[0]
words = len(re.findall(r'\b\w+\b', txt))
abstract = re.search(r'## Abstract\n\n(.+?)\n\n', body, re.S)
print(f'manuscript body words: {words}')
if abstract:
    print(f'abstract words: {len(re.findall(r"\\b\\w+\\b", abstract.group(1)))}')
print('DONE_15')
