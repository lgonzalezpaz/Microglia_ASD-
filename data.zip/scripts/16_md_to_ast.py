"""Parse the manuscript Markdown into a JSON AST for the DOCX builder."""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, re, csv, os

MS = f'{ROOT}/manuscript'
TAB = f'{ROOT}/tables'

INLINE_TABLES = [
    ('Table1_module_architecture', 'after', 'The low substrate reliability is itself informative'),
    ('Table2_genetic_partition', 'after', 'and none showed Open Targets genetic enrichment'),
    ('Table3_developmental_timing', 'after', 'with the balance O − K showing a consistent trend'),
    ('Table4_spatial_validation', 'after', 'do not by themselves support the common inference'),
]


def runs(text):
    """Split inline markdown into formatted runs."""
    out = []
    pattern = re.compile(r'(\*\*.+?\*\*|\*[^*]+?\*|\^[^^]+?\^|~[^~]+?~|`[^`]+?`)')
    for part in pattern.split(text):
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            out.append({'t': part[2:-2], 'b': True})
        elif part.startswith('^') and part.endswith('^'):
            out.append({'t': part[1:-1], 'sup': True})
        elif part.startswith('~') and part.endswith('~'):
            out.append({'t': part[1:-1], 'sub': True})
        elif part.startswith('`') and part.endswith('`'):
            out.append({'t': part[1:-1], 'mono': True})
        elif part.startswith('*') and part.endswith('*') and len(part) > 2:
            out.append({'t': part[1:-1], 'i': True})
        else:
            out.append({'t': part})
    return out


def load_table(name):
    path = f'{TAB}/{name}.csv'
    with open(path) as f:
        rows = list(csv.reader(f))
    cap = open(f'{TAB}/{name}.md').read().split('\n')[0].strip('*')
    return {'type': 'table', 'name': name, 'header': rows[0], 'rows': rows[1:],
            'caption': cap}


src = open(f'{MS}/manuscript.md').read()
lines = src.split('\n')
blocks, i = [], 0
eqnum = 0
while i < len(lines):
    ln = lines[i]
    s = ln.strip()
    if not s:
        i += 1; continue
    if s == '---':
        i += 1; continue
    if s.startswith('# '):
        blocks.append({'type': 'title', 'runs': runs(s[2:])})
    elif s.startswith('## '):
        blocks.append({'type': 'h1', 'runs': runs(s[3:])})
    elif s.startswith('### '):
        blocks.append({'type': 'h2', 'runs': runs(s[4:])})
    elif s.startswith('EQ: '):
        body = s[4:].strip()
        m = re.search(r'\((\d+)\)\s*$', body)
        num = m.group(1) if m else None
        if m:
            body = body[:m.start()].strip()
        blocks.append({'type': 'equation', 'runs': runs(body), 'num': num})
    elif re.match(r'^\[(Figure|Table) .+ near here\]$', s):
        blocks.append({'type': 'placement', 'runs': runs(s)})
    elif s.startswith('- '):
        items = []
        while i < len(lines) and lines[i].strip().startswith('- '):
            items.append(runs(lines[i].strip()[2:]))
            i += 1
        blocks.append({'type': 'bullets', 'items': items})
        continue
    elif re.match(r'^\d+\.\s', s) and blocks and blocks[-1].get('ref_mode'):
        blocks.append({'type': 'reference', 'runs': runs(re.sub(r'^\d+\.\s*', '', s)),
                       'num': s.split('.')[0]})
    else:
        blocks.append({'type': 'p', 'runs': runs(s)})
    # mark that we are inside the reference list
    if s.startswith('## References'):
        for b in blocks:
            pass
        blocks[-1]['ref_mode'] = True
    i += 1

# the three paragraphs between the title and the Abstract form the title block
ti = next((k for k, b in enumerate(blocks) if b['type'] == 'title'), None)
if ti is not None:
    for b in blocks[ti + 1:]:
        if b['type'] == 'h1':
            break
        if b['type'] == 'p':
            b['type'] = 'titleblock'

# convert numbered paragraphs after "## References" into reference entries
ref_start = next((k for k, b in enumerate(blocks)
                  if b['type'] == 'h1' and b['runs'][0]['t'].startswith('References')), None)
if ref_start is not None:
    for b in blocks[ref_start + 1:]:
        if b['type'] == 'p':
            b['type'] = 'reference'

# place each inline table immediately after its [Table N near here] marker
for name, _, _anchor in INLINE_TABLES:
    tb = load_table(name)
    tnum = name[5]
    marker = f'[Table {tnum} near here]'
    for k, b in enumerate(blocks):
        if b['type'] == 'placement' and marker in ''.join(r['t'] for r in b['runs']):
            blocks.insert(k + 1, tb)
            break
    else:
        print(f'  WARNING: placement marker not found for {name}')

# figure captions appended before back matter
CAPS = [
 ('Figure 1', 'Architecture of the pruning axis and the structural behaviour of the model. '
  '(a) The three regulatory layers and the synaptic substrate, with representative genes. '
  '(b) Engulfment probability as a Hill function of the opsonin-to-checkpoint ratio, for '
  'cooperativity n = 1, 2 and 4. (c) Steady-state synaptic density under increasing opsonin '
  'perturbation m for a low-ratio (primary-like) and a high-ratio (association-like) parcel. '
  '(d) Response curves for three values of microglial effector capacity E under homeostatic '
  'matching; the curves coincide exactly, illustrating the cancellation proved in equation (8). '
  '(e) Absolute excess elimination flux, by contrast, scales linearly with E.'),
 ('Figure 2', 'Regional architecture of the pruning axis across 34 left cortical parcels. '
  '(a) Layer scores ordered along the sensorimotor-to-association axis (PC1). '
  '(b) Cellular ownership of each module measured in Allen human cortical single-nucleus data. '
  '(c) Opsonin and checkpoint scores are correlated across parcels; the dotted line is identity '
  'and colour denotes position on the hierarchy. (d) Module-hierarchy correlations under three '
  'specifications: unadjusted, residualised on the abundance of the expressing cell types, and '
  'fully adjusted on all five composition panels. (e) Extensive opsonin-checkpoint balance by '
  'parcel.'),
 ('Figure 3', 'Spatial validation against ENIGMA case-control cortical thickness. '
  '(a) Per-cell opsonin-checkpoint balance versus autism Cohen’s d (mega-analysis). '
  '(b) Null distribution of the correlation under 10,000 variogram-matched surrogate maps; the '
  'vertical line marks the observed value and dotted lines the 95% interval. (c) Observed |rho| '
  'against the magnitude that would have been detectable at 95% under the same nulls. '
  '(d) Per-donor replication of the association for each target. (e) All predictor-target '
  'correlations; asterisks mark uncorrected spatial P < 0.05.'),
 ('Figure 4', 'Partition of genetic risk across the pruning axis. (a) Enrichment z relative to '
  'background gene sets matched on coding length, loss-of-function constraint and cortical '
  'expression; asterisks mark P < 0.05. (b) Observed versus matched-null fraction of SFARI '
  'autism genes. (c) Circularity control: the substrate module retested after removing '
  'well-established autism genes. (d) Hypothesis-free cell-type marker sets. (e) Observed '
  'fractions with bootstrap 95% confidence intervals against the matched null.'),
 ('Figure 5', 'Developmental timing of pruning-axis engagement (BrainSpan, 352 neocortical '
  'samples, 42 donors). (a-c) Smoothed trajectories of the opsonin, checkpoint and effector '
  'modules in primary versus association cortex; points are individual samples. (d) Age of peak '
  'engagement for each region, labelled primary (P) or association (A). Checkpoint peaks at the '
  'upper bound of the sampled range in several association regions. (e) Exact-permutation '
  'significance for the pre-specified timing family.'),
 ('Figure 6', 'Parameter sensitivity. Correlation between each vulnerability metric and the '
  'cortical hierarchy across combinations of Hill cooperativity n and checkpoint potentiation '
  'lambda, averaged over the gain and perturbation grids. Metric C is undefined wherever the '
  'opsonin increase needed to exhaust synaptogenic reserve exceeds the saturation ceiling of '
  'the engulfment probability; panel c therefore summarises only parameter sets in which it is '
  'defined for at least 21 parcels, and it is shown for completeness rather than used for '
  'inference.'),
]
blocks_out, inserted = [], False
for b in blocks:
    if not inserted and b['type'] == 'h1' and b['runs'][0]['t'].startswith('CRediT'):
        blocks_out.append({'type': 'h1', 'runs': runs('Figure Legends')})
        for lab, cap in CAPS:
            blocks_out.append({'type': 'caption', 'runs':
                               [{'t': lab + '. ', 'b': True}] + runs(cap)})
        inserted = True
    blocks_out.append(b)

# supplementary tables
blocks_out.append({'type': 'h1', 'runs': runs('Supplementary Tables')})
for name in ['Table5_regional_values', 'Table6_data_sources']:
    blocks_out.append(load_table(name))

json.dump(blocks_out, open(f'{MS}/manuscript_ast.json', 'w'), ensure_ascii=False)
from collections import Counter
print(Counter(b['type'] for b in blocks_out))
print(f'wrote AST with {len(blocks_out)} blocks')
