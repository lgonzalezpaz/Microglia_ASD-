"""Robustness and falsification checks.

(1) Symbolic verification that microglial effector capacity E cancels exactly from the
    homeostatically matched steady state, so fractional synaptic loss cannot depend on it.
(2) Circularity control on the genetic partition: many canonical synaptic genes are also
    well-known autism genes, so the synaptic module is re-tested after removing SFARI
    category-1 genes, and with the purely genetic Open Targets score.
(3) Detectability (power) of the spatial validation: the surrogate null gives the
    correlation magnitude that WOULD have been detectable, which bounds interpretation of
    the negative result.
(4) Bilateral (68-parcel) sensitivity analysis of the spatial validation.
(5) Family-wise FDR for the pre-specified developmental timing hypothesis.

Outputs: out/robust_symbolic.txt, out/robust_genetic_control.csv,
         out/robust_power.csv, out/robust_bilateral.csv, out/robust_devel_fdr.csv
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json
import numpy as np, pandas as pd
import sympy as sp
from scipy import stats

OUT = f'{ROOT}/out'
rng = np.random.default_rng(20261025)

# ------------------------------------------------- (1) symbolic E-cancellation
S, Sst, T, K, E, n, lam, m = sp.symbols('S S_star T K E n lamda m', positive=True)
Phi = lambda s, mm: (mm * T) ** n / ((mm * T) ** n + (K * (1 + lam * s)) ** n)
sigma = E * Sst * Phi(Sst, 1) / (1 - Sst)
balance = sp.Eq(sigma * (1 - S), E * S * Phi(S, m))
reduced = sp.simplify(sp.Eq(balance.lhs / E, balance.rhs / E))
lines = [
    'Homeostatically matched steady state',
    '  sigma_r (1 - S) = E_r S Phi_r(S, m),  sigma_r = E_r S* Phi_r(S*,1)/(1 - S*)',
    '',
    f'balance equation : {sp.simplify(balance.lhs - balance.rhs)}',
    f'after dividing by E : {sp.simplify(reduced.lhs - reduced.rhs)}',
    f'contains E after reduction : {E in sp.simplify(reduced.lhs - reduced.rhs).free_symbols}',
    '',
    'Therefore the equilibrium S(m) and hence the fractional loss (S* - S(m))/S*',
    'are independent of E: microglial effector capacity cannot, on its own, set',
    'regional vulnerability once baseline synaptic density is homeostatically matched.',
    'Absolute excess elimination flux dJ = E S* [Phi(m) - Phi(1)] does scale with E.',
]
open(f'{OUT}/robust_symbolic.txt', 'w').write('\n'.join(lines))
print('\n'.join(lines))

# ------------------------------------------------- (2) genetic circularity control
exec(open(f'{ROOT}/scripts/10_genetic_partition.py').read().split(
    '# ------------------------------------------------------- module-level partition')[0]
     .replace("N_PERM = 20000", "N_PERM = 20000"))

mod = pd.read_csv(f'{ROOT}/data/modules/pruning_axis_modules.csv')
mod['gene'] = mod.gene.str.upper()
Sgenes = set(mod.loc[mod.module == 'S', 'gene'])
Egenes = set(mod.loc[mod.module == 'E', 'gene'])
sf1 = set(sf.loc[sf['gene-score'] == 1, 'gene'])
sf12 = set(sf.loc[sf['gene-score'] <= 2, 'gene'])

sets = {
    'S_full': Sgenes,
    'S_minus_SFARI_score1': Sgenes - sf1,
    'S_minus_SFARI_score1_2': Sgenes - sf12,
    'E_full': Egenes,
}
rows = []
for name, g in sets.items():
    r = matched_test(sorted(g), name)
    if r:
        rows.append(r)
ctl = pd.DataFrame(rows)
ctl.to_csv(f'{OUT}/robust_genetic_control.csv', index=False)
print('\n===== (2) circularity control: synaptic module after removing known autism genes =====')
print(ctl[['gene_set', 'n_genes', 'sfari_any_obs', 'sfari_any_null', 'sfari_any_z', 'sfari_any_p',
           'ot_asd_obs', 'ot_asd_null', 'ot_asd_z', 'ot_asd_p']].to_string(index=False))

# bootstrap CI on observed proportions / means, to bound the null result for module E
print('\n--- bootstrap 95% CI on observed values (10000 resamples of genes) ---')
brows = []
for name, g in sets.items():
    gg = [x for x in g if x in uni.index]
    sub = uni.loc[gg]
    for meas in ['sfari_any', 'ot_asd']:
        v = sub[meas].values
        bs = np.array([v[rng.integers(0, len(v), len(v))].mean() for _ in range(10000)])
        lo, hi = np.percentile(bs, [2.5, 97.5])
        brows.append(dict(gene_set=name, measure=meas, n=len(v),
                          observed=round(float(v.mean()), 5),
                          ci_lo=round(float(lo), 5), ci_hi=round(float(hi), 5)))
        print(f'  {name:24s} {meas:9s} obs={v.mean():.4f} [95% CI {lo:.4f}, {hi:.4f}]')
pd.DataFrame(brows).to_csv(f'{OUT}/robust_power_genetic.csv', index=False)

# ------------------------------------------------- (3) spatial detectability
val = pd.read_csv(f'{OUT}/validation_enigma.csv')
prows = []
for _, r in val.iterrows():
    # the surrogate null is approximately symmetric around null_mean with sd null_sd;
    # the two-sided 95% detectability threshold is |rho| at the 97.5th percentile
    thr = abs(r.null_mean) + 1.96 * r.null_sd
    prows.append(dict(predictor=r.predictor, target=r.target, rho=r.rho,
                      p_spatial=r.p_spatial, null_sd=r.null_sd,
                      detectable_abs_rho_95=round(float(thr), 3),
                      observed_over_threshold=round(float(abs(r.rho) / thr), 3)))
pw = pd.DataFrame(prows)
pw.to_csv(f'{OUT}/robust_power.csv', index=False)
print('\n===== (3) spatial-null detectability =====')
print(pw[pw.target.str.startswith('ASD')].sort_values(['target', 'p_spatial'])
      .head(12).to_string(index=False))
print(f"\nmedian |rho| needed for significance under spatial nulls: "
      f"{pw.detectable_abs_rho_95.median():.3f}; "
      f"largest observed |rho| among ASD targets: "
      f"{pw[pw.target.str.startswith('ASD')].rho.abs().max():.3f}")

# ------------------------------------------------- (5) developmental family FDR
con = pd.read_csv(f'{OUT}/brainspan_contrasts.csv')
fam = con[con.feature.str.match(r'^(O|K|E)_(peak_log_pcd|t90_years)$')].copy()
p = fam.p_exact.values
o = np.argsort(p); q = p[o] * len(p) / (np.arange(len(p)) + 1)
q = np.minimum.accumulate(q[::-1])[::-1]
fdr = np.empty_like(q); fdr[o] = np.clip(q, 0, 1)
fam['p_fdr_family'] = np.round(fdr, 4)
fam = fam.sort_values('p_exact')
fam.to_csv(f'{OUT}/robust_devel_fdr.csv', index=False)
print('\n===== (5) pre-specified developmental timing family (6 tests) =====')
print(fam[['feature', 'association_mean', 'primary_mean', 'difference',
           'p_exact', 'p_fdr_family']].to_string(index=False))
print(f"features with family FDR q<0.05: {int((fam.p_fdr_family < 0.05).sum())}/{len(fam)}")
print('\nDONE_12')
