"""Separate extensive (tissue-level capacity) from intensive (per-cell set-point) gradients.

Regional module scores conflate two distinct quantities:
  (i)  EXTENSIVE  - how much pruning machinery the tissue contains, which legitimately
                    includes regional glial abundance (more microglia = more effector
                    capacity per unit tissue);
  (ii) INTENSIVE  - the per-cell regulatory set-point, i.e. how much opsonin a neuron
                    displays relative to how much checkpoint protection it carries.

Only (ii) speaks to an intrinsic regional set-point. We therefore residualise each module
on the abundance of the cell type(s) that actually express it (measured empirically from
Allen human cortical snRNA-seq in step 05), rather than on all composition panels at once,
which would remove the hierarchy itself.

Outputs: out/composition_scores.csv, out/partial_correlations.csv, out/ock_index.csv,
         out/module_loo_stability.csv
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json
import numpy as np, pandas as pd
from scipy import stats

OUT = f'{ROOT}/out'
rng = np.random.default_rng(20261025)

PANELS = {
    'microglia_abundance': ['GPR34', 'SALL1', 'OLFML3', 'P2RY13', 'MS4A6A', 'MS4A7',
                            'CD53', 'LAPTM5', 'FCER1G', 'SIGLEC11', 'CD33'],
    'astrocyte_abundance': ['AQP4', 'GJA1', 'SLC1A2', 'SLC1A3', 'ALDH1L1', 'GFAP',
                            'SLC4A4', 'MLC1'],
    'neuron_abundance': ['RBFOX3', 'NEFL', 'NEFM', 'MAP2', 'TUBB3', 'ENO2', 'STMN2'],
    'oligo_abundance': ['MBP', 'PLP1', 'MOG', 'MAG', 'CNP', 'MOBP'],
    'endothelial_abundance': ['CLDN5', 'FLT1', 'PECAM1', 'VWF'],
}
# Expressing cell types per module, from measured Allen specificity (step 05).
EXPRESSORS = {
    'O': ['neuron_abundance', 'microglia_abundance'],
    'K': ['neuron_abundance'],
    'E': ['microglia_abundance'],
    'S': ['neuron_abundance'],
}

mod = pd.read_csv(f'{ROOT}/data/modules/pruning_axis_modules.csv')
mod['gene'] = mod.gene.str.upper()
module_genes = set(mod.gene)

info = pd.read_csv(f'{OUT}/dk_info.csv')
ctxL = info[(info.structure == 'cortex') & (info.hemisphere == 'L')].sort_values('id')
grp = pd.read_csv(f'{OUT}/ahba_dk_group.csv', index_col=0)
grp.index = grp.index.astype(int)
expr = grp.loc[ctxL.id.values]
expr.index = ctxL.label.values
expr = expr.dropna(axis=1, how='any')
Z = (expr - expr.mean(axis=0)) / expr.std(axis=0, ddof=1)

comp, used = {}, {}
for name, genes in PANELS.items():
    g = [x for x in genes if x in Z.columns and x not in module_genes]
    comp[name] = Z[g].mean(axis=1); used[name] = g
    print(f'{name}: {len(g)} genes -> {g}')
comp = pd.DataFrame(comp)
comp.to_csv(f'{OUT}/composition_scores.csv')

sc = pd.read_csv(f'{OUT}/module_scores_group.csv', index_col=0).loc[comp.index]
axis = pd.read_csv(f'{OUT}/axis_pc1.csv', index_col=0).loc[comp.index]
qc = json.load(open(f'{OUT}/module_qc.json'))
present = qc['module_genes_present']


def residualise(v, C):
    X = np.column_stack([np.ones(len(v))] + [C[:, j] for j in range(C.shape[1])])
    b = np.linalg.lstsq(X, v, rcond=None)[0]
    return v - X @ b


def partial_spearman(x, y, C):
    xr, yr = stats.rankdata(x), stats.rankdata(y)
    if C.size == 0:
        r, p = stats.spearmanr(x, y); return r, p, len(x) - 2
    Cr = np.column_stack([np.ones(len(xr))] + [stats.rankdata(C[:, j]) for j in range(C.shape[1])])
    ex = xr - Cr @ np.linalg.lstsq(Cr, xr, rcond=None)[0]
    ey = yr - Cr @ np.linalg.lstsq(Cr, yr, rcond=None)[0]
    k = Cr.shape[1] - 1; dof = len(xr) - 2 - k
    r = np.corrcoef(ex, ey)[0, 1]
    t = r * np.sqrt(dof / max(1e-12, 1 - r ** 2))
    return r, 2 * stats.t.sf(abs(t), dof), dof


# ------------------------------------------------- gradient specifications
rows = []
specs = {
    'extensive (unadjusted)': lambda m: np.empty((len(sc), 0)),
    'intensive (own expressing cell types)': lambda m: comp[EXPRESSORS[m]].values,
    'fully adjusted (all composition panels)': lambda m: comp[list(PANELS)].values,
}
for m in ['O', 'K', 'E', 'S']:
    for sname, f in specs.items():
        r, p, dof = partial_spearman(sc[m].values, axis.PC1.values, f(m))
        rows.append(dict(module=m, specification=sname, rho=round(r, 4), p=p, dof=dof))
res = pd.DataFrame(rows)
print('\n--- module gradient along sensorimotor-association axis ---')
print(res.to_string(index=False))

# ------------------------------------------------- indices
adj = pd.DataFrame(
    {m: residualise(sc[m].values, comp[EXPRESSORS[m]].values) for m in ['O', 'K', 'E', 'S']},
    index=sc.index)
adj = (adj - adj.mean(axis=0)) / adj.std(axis=0, ddof=1)
adj.columns = [c + '_percell' for c in adj.columns]

ock = pd.concat([sc, adj, comp, axis], axis=1)
ock['OCB'] = sc['O'] - sc['K']                               # extensive balance
ock['OCB_percell'] = adj['O_percell'] - adj['K_percell']     # intensive set-point
ock.to_csv(f'{OUT}/ock_index.csv')

print('\n--- opsonin-to-checkpoint balance ---')
for v in ['OCB', 'OCB_percell']:
    r, p = stats.spearmanr(ock[v], ock['PC1'])
    print(f'{v} vs PC1: rho={r:+.3f} p={p:.2g}')
    print('   highest:', list(ock[v].nlargest(6).index))
    print('   lowest :', list(ock[v].nsmallest(6).index))

# ------------------------------------------------- leave-one-gene-out stability
loo = []
for m, genes in present.items():
    base = ock['OCB'] if m in ('O', 'K') else sc[m]
    for g in genes:
        keep = [x for x in genes if x != g]
        Zi = Z[keep].mean(axis=1)
        r, _ = stats.spearmanr(Zi, axis.PC1)
        loo.append(dict(module=m, dropped_gene=g, rho_vs_axis=round(r, 4)))
loo = pd.DataFrame(loo)
loo.to_csv(f'{OUT}/module_loo_stability.csv', index=False)
print('\n--- leave-one-gene-out stability of module-axis correlation ---')
print(loo.groupby('module').rho_vs_axis.agg(['mean', 'std', 'min', 'max']).round(3).to_string())

res.to_csv(f'{OUT}/partial_correlations.csv', index=False)
json.dump({'panels_used': used, 'expressors': EXPRESSORS},
          open(f'{OUT}/composition_qc.json', 'w'), indent=1)
print('\nDONE_06')
