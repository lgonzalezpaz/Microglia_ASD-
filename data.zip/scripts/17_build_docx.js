// Build the Nature-style manuscript DOCX from the parsed AST.
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  PageNumber, Header, Footer, LineNumberRestartFormat, TabStopType, TabStopPosition,
} = require('docx');

const path = require('path');
const ROOT = process.env.PRUNING_AXIS_ROOT || path.resolve(__dirname, '..');
const MS = path.join(ROOT, 'manuscript');
const ast = JSON.parse(fs.readFileSync(`${MS}/manuscript_ast.json`, 'utf8'));

const SERIF = 'Times New Roman';
const DOUBLE = { line: 480, lineRule: 'auto' };     // 240 = single
const SINGLE = { line: 240, lineRule: 'auto' };
const GAP = { before: 0, after: 200 };

function mkRuns(rs, opts = {}) {
  return rs.map(r => new TextRun({
    text: r.t,
    bold: !!r.b || !!opts.bold,
    italics: !!r.i || !!opts.italics,
    superScript: !!r.sup,
    subScript: !!r.sub,
    font: r.mono ? 'Consolas' : SERIF,
    size: opts.size || 24,                            // half-points: 24 = 12pt
    color: '000000',
  }));
}

const TABLE_W = 9360; // DXA, fits A4 with 2.54 cm margins

function mkTable(b) {
  const nCols = b.header.length;
  const colW = Math.floor(TABLE_W / nCols);
  const widths = Array(nCols).fill(colW);
  const cell = (txt, bold, shade) => new TableCell({
    width: { size: colW, type: WidthType.DXA },
    shading: shade ? { type: ShadingType.CLEAR, fill: 'EFEFEF' } : undefined,
    margins: { top: 40, bottom: 40, left: 80, right: 80 },
    children: [new Paragraph({
      spacing: SINGLE,
      children: [new TextRun({ text: String(txt), bold: !!bold, font: SERIF, size: 16, color: '000000' })],
    })],
  });
  return new Table({
    columnWidths: widths,
    width: { size: TABLE_W, type: WidthType.DXA },
    rows: [
      new TableRow({ tableHeader: true, children: b.header.map(h => cell(h, true, true)) }),
      ...b.rows.map(r => new TableRow({ children: r.map(c => cell(c, false, false)) })),
    ],
  });
}

const children = [];
for (const b of ast) {
  switch (b.type) {
    case 'title':
      children.push(new Paragraph({
        spacing: { line: 320, lineRule: 'auto', after: 240 },
        children: mkRuns(b.runs, { bold: true, size: 32 }),   // 16 pt
      }));
      break;
    case 'h1':
      children.push(new Paragraph({
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 320, after: 160, line: 240, lineRule: 'auto' },
        children: mkRuns(b.runs, { bold: true, size: 28 }),   // 14 pt
      }));
      break;
    case 'h2':
      children.push(new Paragraph({
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 240, after: 120, line: 240, lineRule: 'auto' },
        children: mkRuns(b.runs, { bold: true, size: 24 }),   // 12 pt
      }));
      break;
    case 'equation':
      children.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 120, after: 120, line: 240, lineRule: 'auto' },
        tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
        children: [
          ...mkRuns(b.runs),
          ...(b.num ? [new TextRun({ text: `\t(${b.num})`, font: SERIF, size: 24, color: '000000' })] : []),
        ],
      }));
      break;
    case 'placement':
      children.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 120, after: 120, line: 240, lineRule: 'auto' },
        children: mkRuns(b.runs, { italics: true }),
      }));
      break;
    case 'titleblock':
      children.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 100, line: 240, lineRule: 'auto' },
        children: mkRuns(b.runs, { size: 20 }),
      }));
      break;
    case 'caption':
      children.push(new Paragraph({
        spacing: { before: 100, after: 160, line: 240, lineRule: 'auto' },
        children: mkRuns(b.runs, { size: 20 }),               // 10 pt
      }));
      break;
    case 'reference':
      children.push(new Paragraph({
        numbering: undefined,
        spacing: { before: 0, after: 60, line: 240, lineRule: 'auto' },
        indent: { left: 360, hanging: 360 },
        children: [
          new TextRun({ text: `${b.num}. `, font: SERIF, size: 20, color: '000000' }),
          ...mkRuns(b.runs, { size: 20 }),
        ],
      }));
      break;
    case 'bullets':
      for (const it of b.items) {
        children.push(new Paragraph({
          bullet: { level: 0 },
          spacing: { before: 0, after: 100, line: 240, lineRule: 'auto' },
          children: mkRuns(it),
        }));
      }
      break;
    case 'table':
      children.push(new Paragraph({
        spacing: { before: 200, after: 100, line: 240, lineRule: 'auto' },
        children: [new TextRun({ text: b.caption, font: SERIF, size: 20, color: '000000' })],
      }));
      children.push(mkTable(b));
      children.push(new Paragraph({ spacing: { after: 200 }, children: [] }));
      break;
    default:
      children.push(new Paragraph({
        spacing: { ...GAP, ...DOUBLE },
        children: mkRuns(b.runs),
      }));
  }
}

const doc = new Document({
  creator: 'manuscript build pipeline',
  title: 'Microglia execute but do not specify',
  styles: {
    default: {
      document: { run: { font: SERIF, size: 24, color: '000000' } },
      heading1: { run: { font: SERIF, size: 28, bold: true, color: '000000' } },
      heading2: { run: { font: SERIF, size: 24, bold: true, color: '000000' } },
    },
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },          // A4 in DXA
        margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 },  // 2.54 cm
      },
      lineNumbers: { countBy: 1, restart: LineNumberRestartFormat.CONTINUOUS, distance: 360 },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ children: [PageNumber.CURRENT], font: SERIF, size: 20, color: '000000' })],
        })],
      }),
    },
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(`${MS}/manuscript.docx`, buf);
  console.log('wrote manuscript.docx', buf.length, 'bytes');
});
