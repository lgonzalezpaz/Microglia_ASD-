"""Validate model-derived regional predictions against independent case-control neuroimaging.

Target maps: ENIGMA cortical-thickness Cohen's d in the Desikan-Killiany parcellation
(van Rooij et al. 2018, Am J Psychiatry, autism mega- and meta-analysis; Schizophrenia
Working Group mega-analysis as a disorder contrast), distributed with the ENIGMA Toolbox
(Lariviere et al. 2021, Nat Methods).

Inference. Cortical maps are spatially smooth, so naive permutation is anticonservative.
Significance is therefore assessed against surrogate maps that preserve the empirical
spatial autocorrelation (variogram matching; Burt et al. 2020, NeuroImage), built on
Euclidean distances between parcel centroids in MNI152 space. Regions missing from a given
target map are dropped BEFORE surrogate construction, and surrogates are asserted
NaN-free, because missing values silently deflate surrogate-based p-values.

Two tests per predictor-target pair:
  (1) continuous Spearman correlation across parcels;
  (2) a pre-specified tertile contrast - mean Cohen's d in the top versus bottom third of
      the predictor - which is better powered for the directional clinical hypothesis that
      autism-related cortical change concentrates in high-pruning-pressure cortex.

Outputs: out/validation_enigma.csv, out/validation_tertile.csv, out/dk_centroids.csv,
         out/validation_donorwise.csv
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, os
import numpy as np, pandas as pd
from scipy import stats
import nibabel as nib
import abagen
from brainsmash.mapgen.base import Base

OUT = f'{ROOT}/out'
ENI = f'{ROOT}/data/enigma/enigmatoolbox/datasets/summary_statistics'
N_SURR = 10000
rng = np.random.default_rng(20261025)

# ------------------------------------------------------- parcel centroids
info = pd.read_csv(f'{OUT}/dk_info.csv')
ctxL = info[(info.structure == 'cortex') & (info.hemisphere == 'L')].sort_values('id')
atlas = abagen.fetch_desikan_killiany(surface=False)
img = nib.load(atlas['image'])
lab = np.asarray(img.dataobj)
aff = img.affine
cent = {}
for _, row in ctxL.iterrows():
    idx = np.argwhere(lab == row.id)
    if idx.size:
        cent[row.label] = (aff @ np.append(idx.mean(axis=0), 1.0))[:3]
cen = pd.DataFrame(cent, index=['x', 'y', 'z']).T
cen.to_csv(f'{OUT}/dk_centroids.csv')
regions = list(cen.index)
print(f'centroids for {len(regions)} left cortical parcels')

# ------------------------------------------------------- predictors / targets
vm = pd.read_csv(f'{OUT}/vulnerability_metrics.csv', index_col=0)
ock = pd.read_csv(f'{OUT}/ock_index.csv', index_col=0)
pred = pd.DataFrame(index=regions)
for c in ['O', 'K', 'E', 'S', 'OCB', 'OCB_percell', 'PC1']:
    pred[c] = ock[c].reindex(regions)
for c in ['A_frac_loss', 'B_excess_flux', 'flux_base', 'Phi_base']:
    pred[c] = vm[c].reindex(regions)

targets = {}
for f, lab_ in [('asd_mega-analysis_case-controls_CortThick.csv', 'ASD_mega_d'),
                ('asd_meta-analysis_case-controls_CortThick.csv', 'ASD_meta_d'),
                ('scz_case-controls_CortThick.csv', 'SCZ_d')]:
    d = pd.read_csv(f'{ENI}/{f}')
    d = d[d.Structure.str.startswith('L_')].copy()
    d['region'] = d.Structure.str[2:]
    targets[lab_] = d.set_index('region').d_icv.reindex(regions)
tg = pd.DataFrame(targets)

# ------------------------------------- per-target surrogates on complete parcels only
surr, valid = {}, {}
for name in tg.columns:
    y = tg[name].astype(float)
    ok = y.notna().values
    valid[name] = ok
    sub_regions = [r for r, k in zip(regions, ok) if k]
    C = cen.loc[sub_regions].values
    D = np.linalg.norm(C[:, None, :] - C[None, :, :], axis=-1)
    base = Base(x=y.values[ok], D=D, resample=True, seed=int(rng.integers(1e6)))
    S = base(n=N_SURR)
    assert np.isfinite(S).all(), f'non-finite surrogates for {name}'
    surr[name] = S
    print(f'  {name}: {ok.sum()} parcels used, surrogates {S.shape}, '
          f'dropped={[r for r,k in zip(regions,ok) if not k]}')


def rankmat(M):
    return np.apply_along_axis(stats.rankdata, 1, M)


def fast_spearman_null(x, S):
    """Spearman correlations between a fixed vector and every surrogate row."""
    xr = stats.rankdata(x)
    xr = (xr - xr.mean()) / xr.std()
    Sr = rankmat(S)
    Sr = (Sr - Sr.mean(axis=1, keepdims=True)) / Sr.std(axis=1, keepdims=True)
    return (Sr @ xr) / len(xr)


def spatial_test(x_full, tname):
    ok = valid[tname] & np.isfinite(x_full)
    if ok.sum() < 20:
        return None
    # surrogates were built on the target's complete parcels; align indices
    sel = np.flatnonzero(ok[valid[tname]])
    x = x_full[ok]
    y = tg[tname].values[ok]
    r_obs = stats.spearmanr(x, y).statistic
    null = fast_spearman_null(x, surr[tname][:, sel])
    p = (np.sum(np.abs(null) >= abs(r_obs)) + 1) / (len(null) + 1)
    return dict(n=int(ok.sum()), rho=float(r_obs), p_spatial=float(p),
                p_parametric=float(stats.spearmanr(x, y).pvalue),
                null_mean=float(null.mean()), null_sd=float(null.std()))


rows = []
for pname in pred.columns:
    xv = pred[pname].values.astype(float)
    for tname in tg.columns:
        r = spatial_test(xv, tname)
        if r:
            rows.append(dict(predictor=pname, target=tname, **r))
val = pd.DataFrame(rows)


def bh(p):
    p = np.asarray(p, float)
    o = np.argsort(p)
    q = p[o] * len(p) / (np.arange(len(p)) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty_like(q); out[o] = np.clip(q, 0, 1)
    return out


val['p_fdr'] = np.nan
for t in val.target.unique():
    m = val.target == t
    val.loc[m, 'p_fdr'] = bh(val.loc[m, 'p_spatial'].values)
val = val.sort_values(['target', 'p_spatial'])
val.to_csv(f'{OUT}/validation_enigma.csv', index=False)
for t in tg.columns:
    print(f'\n===== continuous spatial correlation: {t} =====')
    print(val[val.target == t][['predictor', 'n', 'rho', 'p_spatial',
                                'p_parametric', 'p_fdr']].round(4).to_string(index=False))

# ------------------------------------------------- pre-specified tertile contrast
trows = []
for pname in ['OCB', 'OCB_percell', 'B_excess_flux', 'A_frac_loss', 'O', 'E', 'PC1']:
    xv = pred[pname].values.astype(float)
    for tname in tg.columns:
        ok = valid[tname] & np.isfinite(xv)
        sel = np.flatnonzero(ok[valid[tname]])
        x, y = xv[ok], tg[tname].values[ok]
        q1, q2 = np.quantile(x, [1 / 3, 2 / 3])
        hi, lo = x >= q2, x <= q1
        obs = y[hi].mean() - y[lo].mean()
        S = surr[tname][:, sel]
        null = S[:, hi].mean(axis=1) - S[:, lo].mean(axis=1)
        p = (np.sum(np.abs(null) >= abs(obs)) + 1) / (len(null) + 1)
        trows.append(dict(predictor=pname, target=tname, n_hi=int(hi.sum()), n_lo=int(lo.sum()),
                          d_high=round(float(y[hi].mean()), 4), d_low=round(float(y[lo].mean()), 4),
                          difference=round(float(obs), 4), p_spatial=float(p)))
ter = pd.DataFrame(trows)
for t in ter.target.unique():
    m = ter.target == t
    ter.loc[m, 'p_fdr'] = bh(ter.loc[m, 'p_spatial'].values)
ter.to_csv(f'{OUT}/validation_tertile.csv', index=False)
print('\n===== pre-specified tertile contrast (high minus low predictor third) =====')
print(ter.sort_values(['target', 'p_spatial']).round(4).to_string(index=False))

# ------------------------------------------------------- donor-wise robustness
qc = json.load(open(f'{OUT}/module_qc.json'))
present = qc['module_genes_present']
drows = []
for f in sorted(os.listdir(OUT)):
    if not f.startswith('ahba_donor_'):
        continue
    d = f.split('_')[-1].split('.')[0]
    X = pd.read_csv(f'{OUT}/{f}', index_col=0)
    X.index = X.index.astype(int)
    X = X.reindex(ctxL.id.values); X.index = ctxL.label.values
    Z = (X - X.mean(axis=0)) / X.std(axis=0, ddof=1)
    sO = Z[[g for g in present['O'] if g in Z.columns]].mean(axis=1)
    sK = Z[[g for g in present['K'] if g in Z.columns]].mean(axis=1)
    ocb = (sO - sK).reindex(regions).values
    for tname in tg.columns:
        r = spatial_test(ocb, tname)
        if r:
            drows.append(dict(donor=d, target=tname, **r))
dw = pd.DataFrame(drows)
dw.to_csv(f'{OUT}/validation_donorwise.csv', index=False)
print('\n--- donor-wise opsonin-checkpoint balance vs each target (rho) ---')
print(dw.pivot(index='donor', columns='target', values='rho').round(3).to_string())
print('\n--- across-donor summary ---')
print(dw.groupby('target').rho.agg(['mean', 'std', 'min', 'max']).round(3).to_string())
print('\nDONE_09')
