import json, subprocess, sys, urllib.parse
MAIL="lgonzalezpaz@gmail.com"
def search(title, n=3):
    q=urllib.parse.quote(title)
    u=f"https://api.crossref.org/works?query.bibliographic={q}&rows={n}&mailto={MAIL}"
    p=subprocess.run(['curl','-sS','--max-time','90',u],capture_output=True,text=True,timeout=120)
    try: items=json.loads(p.stdout)['message']['items']
    except Exception as e: print("FAIL",e, p.stdout[:200]); return
    for it in items:
        t=(it.get('title') or [''])[0]
        j=(it.get('short-container-title') or it.get('container-title') or [''])[0]
        d=(it.get('published-print') or it.get('published') or it.get('issued') or {}).get('date-parts',[[None]])[0][0]
        a=(it.get('author') or [{}])[0].get('family','?')
        print(f"  {it['DOI']:<48} {str(d):<6} {j[:20]:<21} {a:<14} {t[:85]}")
for t in sys.argv[1:]:
    print(f"### {t}")
    search(t)
