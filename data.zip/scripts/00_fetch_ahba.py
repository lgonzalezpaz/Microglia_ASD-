import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import abagen, os, sys
os.makedirs(f'{ROOT}/data/ahba', exist_ok=True)
files = abagen.fetch_microarray(data_dir=f'{ROOT}/data/ahba', donors='all', verbose=2)
print("DONORS:", list(files.keys()))
for d, f in files.items():
    print(d, {k: (os.path.basename(v) if isinstance(v,str) else v) for k,v in f.items()})
print("FETCH_OK")
