"""Regional module scores across the human cortex, with cell-type validation.

Inputs : out/ahba_dk_group.csv, out/ahba_donor_*.csv, out/dk_info.csv,
         data/modules/pruning_axis_modules.csv,
         data/celltype/allen_ctx_smartseq_medians.csv
Outputs: out/module_scores_group.csv, out/module_scores_donor.csv,
         out/celltype_specificity.csv, out/axis_pc1.csv, out/module_qc.json
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, os, re
import numpy as np, pandas as pd
from scipy import stats

OUT = f'{ROOT}/out'
MOD = f'{ROOT}/data/modules/pruning_axis_modules.csv'
ALLEN = f'{ROOT}/data/celltype/allen_ctx_smartseq_medians.csv'
rng = np.random.default_rng(1234)

# ---------------------------------------------------------------- regions
info = pd.read_csv(f'{OUT}/dk_info.csv')
ctxL = info[(info.structure == 'cortex') & (info.hemisphere == 'L')].copy()
ctxL = ctxL.sort_values('id')
print(f'left cortical regions: {len(ctxL)}')

grp = pd.read_csv(f'{OUT}/ahba_dk_group.csv', index_col=0)
grp.index = grp.index.astype(int)
expr = grp.loc[ctxL.id.values]
expr.index = ctxL.label.values
expr = expr.dropna(axis=1, how='any')
print(f'expression matrix (regions x genes): {expr.shape}')

# ---------------------------------------------------------------- modules
mod = pd.read_csv(MOD)
mod['gene'] = mod.gene.str.upper()
present, missing = {}, {}
for m, sub in mod.groupby('module'):
    g = [x for x in sub.gene.unique() if x in expr.columns]
    present[m] = g
    missing[m] = sorted(set(sub.gene.unique()) - set(g))
    print(f'  module {m}: {len(g)}/{sub.gene.nunique()} genes in AHBA; missing={missing[m]}')


def module_scores(X, present):
    """z-score each gene across regions, then average within module."""
    Z = (X - X.mean(0)) / X.std(0, ddof=1)
    return pd.DataFrame({m: Z[g].mean(axis=1) for m, g in present.items()})


sc = module_scores(expr, present)
sc.to_csv(f'{OUT}/module_scores_group.csv')
print('\ngroup module scores:\n', sc.describe().round(3).to_string())

# ---------------------------------------------------- per-donor reliability
donor_files = sorted([f for f in os.listdir(OUT) if re.match(r'ahba_donor_\d+\.csv$', f)])
dsc = {}
for f in donor_files:
    d = f.split('_')[-1].split('.')[0]
    X = pd.read_csv(f'{OUT}/{f}', index_col=0)
    X.index = X.index.astype(int)
    X = X.reindex(ctxL.id.values)
    X.index = ctxL.label.values
    X = X[[c for c in expr.columns if c in X.columns]]
    ok = X.notna().all(axis=1)
    if ok.sum() < 20:
        print(f'  donor {d}: only {int(ok.sum())} complete regions, skipped')
        continue
    s = module_scores(X[ok], {m: [g for g in gl if g in X.columns] for m, gl in present.items()})
    dsc[d] = s
    print(f'  donor {d}: {int(ok.sum())} regions scored')

long = pd.concat({k: v for k, v in dsc.items()}, names=['donor', 'region']).reset_index()
long.to_csv(f'{OUT}/module_scores_donor.csv', index=False)

rel = {}
for m in present:
    W = pd.DataFrame({d: v[m] for d, v in dsc.items()})
    C = W.corr(method='spearman').values
    iu = np.triu_indices_from(C, 1)
    rel[m] = {'mean_interdonor_spearman': float(np.nanmean(C[iu])),
              'min': float(np.nanmin(C[iu])), 'n_donors': int(W.shape[1])}
    # Spearman-Brown reliability of the k-donor average
    rbar = np.nanmean(C[iu]); k = W.shape[1]
    rel[m]['spearman_brown_k_donors'] = float(k * rbar / (1 + (k - 1) * rbar))
print('\ninter-donor reliability of module scores:')
for m, v in rel.items():
    print(f"  {m}: mean rho={v['mean_interdonor_spearman']:.3f} "
          f"min={v['min']:.3f} SB(k={v['n_donors']})={v['spearman_brown_k_donors']:.3f}")

# ------------------------------------------------- cell-type specificity
print('\ncell-type specificity (Allen human cortex SMART-seq)')
allen = pd.read_csv(ALLEN, index_col=0)
allen = allen.loc[:, [c for c in allen.columns if not str(c).startswith('Unnamed')]]


def cls(c):
    p = str(c).split()[0]
    if p in ('Exc', 'Inh'):
        return 'Neuron'
    if p == 'Astro':
        return 'Astrocyte'
    if p == 'Micro':
        return 'Microglia'
    if p in ('Oligo', 'OPC'):
        return 'Oligo/OPC'
    return 'Vascular'


groups = {}
for c in allen.columns:
    groups.setdefault(cls(c), []).append(c)
cm = pd.DataFrame({k: allen[v].mean(axis=1) for k, v in groups.items()})
cm.index = cm.index.str.upper()
cm = cm[~cm.index.duplicated()]
# proportion of total expression attributable to each class
frac = cm.div(cm.sum(axis=1).replace(0, np.nan), axis=0)
frac.to_csv(f'{OUT}/celltype_specificity.csv')

rows = []
for m, g in present.items():
    gg = [x for x in g if x in frac.index]
    f = frac.loc[gg]
    rows.append(dict(module=m, n=len(gg), **{k: round(float(f[k].mean()), 3) for k in frac.columns}))
ct = pd.DataFrame(rows).set_index('module')
print(ct.to_string())
ct.to_csv(f'{OUT}/celltype_by_module.csv')

# ------------------------------------------------- dominant expression axis
Z = ((expr - expr.mean(0)) / expr.std(0, ddof=1)).values
Z = Z[:, ~np.isnan(Z).any(0)]
Zc = Z - Z.mean(0)
U, Sv, Vt = np.linalg.svd(Zc, full_matrices=False)
pc = U[:, 0] * Sv[0]
var = (Sv ** 2 / np.sum(Sv ** 2))[:5]
# orient PC1 so that higher = association cortex (lower in primary sensory/motor)
anchors_prim = ['precentral', 'postcentral', 'pericalcarine', 'cuneus',
                'lingual', 'paracentral', 'transversetemporal']
idx = [i for i, r in enumerate(expr.index) if r in anchors_prim]
if np.mean(pc[idx]) > np.mean(pc):
    pc = -pc
axis = pd.DataFrame({'region': expr.index, 'PC1': pc}).set_index('region')
axis.to_csv(f'{OUT}/axis_pc1.csv')
print(f'\nPC1 variance explained: {var[0]*100:.1f}% (PC2 {var[1]*100:.1f}%)')
print('PC1 extremes  low:', list(axis.PC1.nsmallest(5).index))
print('             high:', list(axis.PC1.nlargest(5).index))

for m in sc.columns:
    r, p = stats.spearmanr(sc[m], axis.PC1)
    print(f'  {m} vs PC1: rho={r:+.3f} p={p:.2g}')

json.dump({'regions': list(expr.index), 'n_genes': int(expr.shape[1]),
           'module_genes_present': {k: v for k, v in present.items()},
           'module_genes_missing': missing, 'reliability': rel,
           'pc1_variance_explained': [float(x) for x in var]},
          open(f'{OUT}/module_qc.json', 'w'), indent=1)
print('\nDONE_05')
