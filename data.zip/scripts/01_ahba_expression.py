"""Process AHBA microarray into Desikan-Killiany regional expression (abagen pipeline)."""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import os, pickle, numpy as np, pandas as pd, abagen

DATA=f'{ROOT}/data/ahba'; OUT=f'{ROOT}/out'
os.makedirs(OUT, exist_ok=True)
atlas = abagen.fetch_desikan_killiany(surface=False)
print('atlas:', atlas['image'])
info = pd.read_csv(atlas['info']); print(info.head()); print('n regions', len(info))
info.to_csv(f'{OUT}/dk_info.csv', index=False)

common = dict(atlas=atlas['image'], atlas_info=atlas['info'], data_dir=DATA,
              ibf_threshold=0.5, probe_selection='diff_stability',
              norm_matched=True, gene_norm='srs', sample_norm='srs',
              missing='centroids', verbose=1, n_proc=4)

# Primary: per-donor matrices (enables donor-level stability statistics)
exp_donors = abagen.get_expression_data(return_donors=True, **common)
with open(f'{OUT}/ahba_donors.pkl','wb') as f: pickle.dump(exp_donors, f)
for d, df in exp_donors.items():
    df.to_csv(f'{OUT}/ahba_donor_{d}.csv')
    print('donor', d, df.shape)

# Group-level consensus (mean across donors)
keys = list(exp_donors)
stack = np.stack([exp_donors[k].values for k in keys])
grp = pd.DataFrame(np.nanmean(stack, axis=0), index=exp_donors[keys[0]].index,
                   columns=exp_donors[keys[0]].columns)
grp.to_csv(f'{OUT}/ahba_dk_group.csv')
print('group', grp.shape)
print('DONE_AHBA')
