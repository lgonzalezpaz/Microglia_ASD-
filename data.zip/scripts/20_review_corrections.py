"""Corrections arising from independent verification.

Each edit is traceable to a specific finding and to the output file that adjudicates it.
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, re
import pandas as pd

MS = f'{ROOT}/manuscript'
p_ms = f'{MS}/manuscript_source.md'

# ---- add the two missing citations -------------------------------------------
refs = json.load(open(f'{MS}/references_map.json'))
new = pd.read_csv(f'{ROOT}/out/references_verified.csv')
new = new[new.status == 'OK'].set_index('doi')


def clean(s):
    s = re.sub(r'\s+', ' ', str(s)).strip()
    s = s.replace('et al..', 'et al.')
    s = re.sub(r'(\d{4});([^,;:]+), ', r'\1;\2:', s)
    return s


refs['trubetskoy2022'] = clean(new.loc['10.1038/s41586-022-04434-5', 'vancouver'])
refs['vanerp2018'] = clean(new.loc['10.1016/j.biopsych.2018.04.023', 'vancouver'])
# drop the meeting-abstract citation; the full paper (cong2020) carries the claim
refs.pop('cong2018', None)
json.dump(refs, open(f'{MS}/references_map.json', 'w'), indent=1, ensure_ascii=False)
print('added:', refs['trubetskoy2022'][:70], '...')
print('added:', refs['vanerp2018'][:70], '...')
print('removed meeting-abstract citation cong2018')

s = open(p_ms).read()
EDITS = [
# ---- finding 1 + 2: correct the cell-type marker numbers and the OT claim -----
("A hypothesis-free instrument gave the same answer. Data-driven marker sets showed only "
 "weak enrichment that was not microglia-specific: microglial (*z* = 6.1), oligodendrocyte "
 "(*z* = 5.1) and astrocyte (*z* = 4.0) marker sets were similarly and modestly "
 "SFARI-enriched at 1,000 genes, with effect ratios of ~1.4-fold against null, compared "
 "with ~4-fold for the 35-gene substrate module, and none showed Open Targets genetic "
 "enrichment (Fig. 4d).",
 "A hypothesis-free instrument qualified rather than overturned this. Data-driven marker "
 "sets were SFARI-enriched across every glial class at 1,000 genes — microglial "
 "*z* = 8.07, oligodendrocyte *z* = 5.87, astrocyte *z* = 2.95 — with the microglial set "
 "the strongest of the three, while the neuronal marker set was depleted (*z* = −3.69), "
 "reflecting that extreme cell-type specificity selects against the broadly expressed "
 "chromatin and synaptic regulators that carry autism risk. Two features nonetheless "
 "separate this from the substrate result. The magnitude is far smaller: the microglial "
 "set is enriched 1.5-fold over its matched null (0.238 versus 0.158) against 4.0-fold for "
 "the 35-gene substrate module (0.771 versus 0.191). And the enrichment does not appear on "
 "the purely genetic measure: no microglial marker set reached Open Targets genetic "
 "enrichment (*z* = −1.03, −0.02 and +1.08 at 250, 500 and 1,000 genes), the only nominal "
 "signal among all twelve marker sets being the 250-gene astrocyte set (*z* = 2.51, "
 "*P* = 0.038), which does not survive correction across sets (Fig. 4d)."),

# ---- finding 3: stop describing a null as evidence of absence ------------------
("The microglial effector module showed no detectable enrichment on either measure (SFARI "
 "13.0% versus 7.9% expected, *z* = 0.95, *P* = 0.53; Open Targets genetic score 0.000 "
 "versus 0.0029 expected, *z* = −0.43, bootstrap 95% CI for the observed value "
 "[0.000, 0.000]).",
 "The microglial effector module was statistically indistinguishable from its matched "
 "null on both measures (SFARI 13.0% versus 7.9% expected, *z* = 0.95, *P* = 0.53; Open "
 "Targets genetic score 0.000 versus 0.0029 expected, *z* = −0.43, *P* = 1.0). This is a "
 "null result, not evidence of absence: with 23 genes and an expected count below one gene "
 "on the genetic measure, the test has little power against a modest effect, and the "
 "informative comparison is with the substrate module, which exceeds its null by nine "
 "standard deviations on the same instrument."),
("Consistent with a target-encoded lesion, autism genetic risk concentrates on the "
 "synaptic substrate and shows no enrichment in microglial effector machinery, whereas "
 "schizophrenia risk implicates complement checkpoints.",
 "Consistent with a target-encoded lesion, autism genetic risk concentrates on the "
 "synaptic substrate while the microglial effector layer is indistinguishable from matched "
 "background; schizophrenia risk additionally reaches complement checkpoints."),
("autism risk concentrated on the synaptic substrate by a factor of roughly four and was "
 "absent from microglial effector machinery on a purely genetic measure, with a bootstrap "
 "confidence interval excluding any effect.",
 "autism risk concentrated on the synaptic substrate by a factor of roughly four, while "
 "the microglial effector layer was indistinguishable from background. The effector result "
 "is a null, and with 23 genes it bounds rather than excludes a modest effect; what it "
 "does establish is an asymmetry, since the same instrument detects the substrate signal "
 "at nine standard deviations."),
("Autism genetic risk concentrates on the neuronal synaptic substrate and shows no "
 "enrichment in microglial effector machinery, placing the primary lesion on the target "
 "rather than the executioner;",
 "Autism genetic risk concentrates on the neuronal synaptic substrate while the microglial "
 "effector layer is indistinguishable from matched background, which locates the detectable "
 "lesion on the target rather than the executioner;"),

# ---- finding 5: the model's two metrics predict opposite directions ------------
("Raw correlations were encouraging. The per-cell opsonin–checkpoint balance correlated "
 "with autism cortical-thickness Cohen's *d* at ρ = −0.31 in the mega-analysis, with the "
 "extensive balance at ρ = −0.32, in the predicted direction (greater pruning pressure, "
 "thinner cortex), and the sign was consistent across all six AHBA donors individually "
 "(ρ = −0.22 to −0.33; mean −0.29) (Fig. 3a,d).",
 "Because metrics A and B order the cortex oppositely, the observed data discriminate "
 "between them even when neither reaches significance. The per-cell opsonin–checkpoint "
 "balance correlated with autism cortical-thickness Cohen's *d* at ρ = −0.31 in the "
 "mega-analysis and the extensive balance at ρ = −0.32, the sign expected if higher "
 "pruning pressure produces thinner cortex, and consistent across all six AHBA donors "
 "individually (ρ = −0.22 to −0.33; mean −0.29) (Fig. 3a,d). Metric B behaved the same way "
 "(ρ = −0.25). Metric A, being a monotone decreasing function of the balance, necessarily "
 "took the opposite sign (ρ = +0.32), so the weak association that is present runs against "
 "the fractional-loss ordering and with the excess-flux ordering (Fig. 3e). We note this "
 "because the model's own structural result makes metric A the quantity governed by the "
 "tag-to-checkpoint ratio; the data, such as they are, do not favour it."),

# ---- finding 6: homeostatic matching is an assumption, not a measurement -------
("Because the synaptic substrate module is spatially flat (Results), baseline synaptic "
 "density was treated as regionally invariant and σ~r~ was set analytically so that every "
 "parcel rests at the same baseline *S*~0~:",
 "Baseline synaptic density was treated as regionally invariant. This is an assumption, "
 "motivated by homeostatic synaptic plasticity, and it is the load-bearing premise of the "
 "cancellation result below; it is consistent with, but not established by, the spatial "
 "flatness of the substrate module, since transcript abundance does not index synaptic "
 "density and that module is in any case the least reliably estimated of the four. Under "
 "this assumption σ~r~ is set analytically so that every parcel rests at the same baseline "
 "*S*~0~:"),
("The low substrate reliability is itself informative: synaptic genes have little reliable "
 "regional variation to detect.",
 "The low substrate reliability bears directly on interpretation: the apparent spatial "
 "flatness of the substrate module is as consistent with an underpowered measurement as "
 "with genuine regional uniformity, and we therefore treat homeostatic matching as a "
 "modelling assumption rather than an empirical finding."),

# ---- finding 7: module E is a glial, not purely microglial, effector module ----
("omits astrocytic contributions to elimination{{chung2013}}{{vainchtein2018}}, "
 "synapse-type selectivity,",
 "does not separate astrocytic from microglial elimination — the effector module contains "
 "MEGF10, MERTK, GAS6 and AXL and is 17.0% astrocytic by expression, so *E* is better read "
 "as glial engulfment capacity than as a microglia-specific "
 "quantity{{chung2013}}{{vainchtein2018}} — omits synapse-type selectivity,"),

# ---- finding 8 + 10: citations that cannot carry their claims ------------------
("consistent with complement-regulatory genes such as *CSMD1* carrying schizophrenia "
 "risk{{kraus2006}}.",
 "consistent with complement-regulatory loci including *CSMD1* carrying schizophrenia "
 "risk in genome-wide association data{{trubetskoy2022}}, *CSMD1* itself being a "
 "membrane complement inhibitor{{kraus2006}}."),
("consistent with structural variation at *C4* and with complement-regulatory "
 "loci{{sekar2016}}{{kraus2006}}.",
 "consistent with structural variation at *C4* and with complement-regulatory loci "
 "implicated by genome-wide association{{sekar2016}}{{trubetskoy2022}}."),
("autism mega-analysis (1,650 cases, 1,569 controls), autism meta-analysis (1,060 cases, "
 "976 controls) and schizophrenia (4,343 cases, 5,002 controls) as a disorder "
 "contrast{{vanrooij2018}}{{lariviere2021}}.",
 "the autism mega- and meta-analyses{{vanrooij2018}} and, as a disorder contrast, the "
 "schizophrenia mega-analysis{{vanerp2018}}, distributed with the ENIGMA "
 "Toolbox{{lariviere2021}}. Parcel-wise sample sizes vary slightly within each map; the "
 "maxima are 1,658 autistic and 1,571 control participants (mega-analysis), 1,060 and 976 "
 "(meta-analysis), and 4,343 and 5,002 (schizophrenia)."),

# ---- finding 12: explain the 36 vs 35 gene difference -------------------------
("using 27 strata (3 × 3 × 3 tertiles) and 20,000 stratified resamples within a universe "
 "of 13,874 cortically expressed protein-coding genes.",
 "using 27 strata (3 × 3 × 3 tertiles) and 20,000 stratified resamples within a universe "
 "of 13,874 cortically expressed protein-coding genes with complete constraint annotation. "
 "One substrate gene (*SYN2*) lacks constraint annotation and is therefore absent from this "
 "universe, so the genetic tests use 35 of the 36 substrate genes."),

# ---- finding 15: checkpoint timing is a boundary artefact ----------------------
("The age at which the checkpoint layer reached 90% of its maximum was 20.9 years later in "
 "association cortex (*P* = 0.012, *q* = 0.036),",
 "The age at which the checkpoint layer reached 90% of its maximum was 20.9 years later in "
 "association cortex (*P* = 0.012, *q* = 0.036), although this comparison should be read "
 "with caution because the checkpoint trajectory peaks at the upper bound of the sampled "
 "age range in ten of eleven regions, so its 90%-of-maximum age is measured against an "
 "edge-censored maximum;"),

# ---- finding 16: do not convert an inconclusive negative into a resolved one ---
("Adult expression gradients do not predict autism cortical-thickness differences once "
 "spatial autocorrelation is respected. Instead, the discriminating regional variable is "
 "temporal: microglial effector programmes peak several years later in association than in "
 "primary cortex. Microglia are competent executioners whose regional deployment is timed, "
 "not tonically graded.",
 "Adult expression gradients do not predict autism cortical-thickness differences once "
 "spatial autocorrelation is respected, although the available parcellation is underpowered "
 "for effects of the size observed. A developmental contrast is sharper: microglial "
 "effector programmes peak several years later in association than in primary cortex, "
 "completely separating the two. We therefore propose, as a hypothesis the present data "
 "motivate rather than establish, that regional deployment of microglial pruning is timed "
 "rather than tonically graded."),
("What did separate vulnerable from spared cortex was timing: microglial effector "
 "programmes remain engaged for years longer in association than in primary cortex. "
 "Microglia execute; they do not specify. Where damage lands is determined by when the "
 "window closes.",
 "What did separate association from primary cortex, cleanly and robustly, was timing: "
 "microglial effector programmes remain engaged for years longer in association cortex. "
 "That contrast is developmental and contains no autism measure, so the link to regional "
 "vulnerability remains a hypothesis rather than a result — but it is a specific and "
 "testable one, and it follows from a model in which microglia execute without specifying. "
 "Where damage lands may be governed less by how strongly the machinery is expressed than "
 "by how long it stays open."),
("Time is where the evidence was strongest.",
 "Time is where the between-region evidence was strongest, though it must be said at once "
 "that this analysis separates association from primary cortex and contains no autism or "
 "vulnerability variable; the bridge to regional susceptibility is an inference from the "
 "model, not a measurement."),

# ---- finding 17: keep the per-cell qualifier in the abstract ------------------
("and that tag and checkpoint layers are co-regulated so their ratio is conserved across "
 "cortex",
 "and that tag and checkpoint layers are co-regulated so their per-cell ratio is conserved "
 "across cortex while their absolute setting rises together"),

# ---- finding 18: name the missing effector genes; correct K residualisation ---
("*C4B* is not represented on the array at all; *C4A*, *SRPX2*, *CD200R1*, *CFI*, *CR1*, "
 "*CSMD2*, *C5AR1* and *IRF8* are present as probes but did not pass intensity-based "
 "filtering,",
 "*C4B* is not represented on the array at all; the remaining absentees — *C4A* and the "
 "checkpoint genes *SRPX2*, *CD200R1*, *CFI*, *CR1* and *CSMD2*, together with the "
 "effector genes *C5AR1* and *IRF8* — are present as probes but did not pass "
 "intensity-based filtering,"),
("Each module was residualised on the abundance of the cell types that empirically express "
 "it, giving per-cell scores.",
 "Each module was residualised on the abundance of the cell types that empirically express "
 "it (opsonin on neurons and microglia; checkpoint on neurons; effector on microglia; "
 "substrate on neurons), giving per-cell scores. The checkpoint module also carries a "
 "substantial vascular component (23.9%) that this specification does not remove, so its "
 "per-cell estimate is the least clean of the four."),

# ---- finding 18: BrainSpan uses the full module; AHBA does not ----------------
("Module scores were computed as above on log₂(RPKM + 1).",
 "Module scores were computed as above on log₂(RPKM + 1). All 91 module genes are present "
 "in BrainSpan, against 82 in the processed AHBA matrix, so the developmental and regional "
 "analyses are not computed on identical gene sets; in particular *SRPX2* contributes to "
 "the developmental checkpoint trajectory but not to the regional one."),

# ---- finding 18: bound the robustness claim ----------------------------------
("Across the 432-point parameter sweep the sign of the remaining metrics' relationship to "
 "the cortical hierarchy was stable (metric A, 100% sign-consistent; metric B, 97%), and "
 "the ranking of parcels under the default parameters agreed closely with alternatives "
 "(Fig. 6).",
 "Across the 432-point parameter sweep, which spans *n* ∈ {1,2,3}, the sign of the "
 "remaining metrics' relationship to the cortical hierarchy was stable (metric A, 100% "
 "sign-consistent; metric B, 97%), and the ranking of parcels under the default parameters "
 "agreed closely with alternatives (Fig. 6). This stability does not extend indefinitely: "
 "in a wider scan including *n* = 4 with strong checkpoint potentiation, parcel ranking "
 "reversed relative to the default, so the robustness claim is bounded to *n* ≤ 3."),

# ---- finding 18: describe the Allen dataset precisely ------------------------
("Cell-type attribution used Allen human cortical SMART-seq median expression across 121 "
 "transcriptomic cell types{{hodge2019}},",
 "Cell-type attribution used the Allen Institute Human Multiple Cortical Areas SMART-seq "
 "release, taking median expression across its 121 transcriptomic cell types; the "
 "underlying taxonomy and methods are those of the Allen human cortical single-nucleus "
 "programme{{hodge2019}},"),
]

n = 0
for a, b in EDITS:
    if a in s:
        s = s.replace(a, b, 1); n += 1
    else:
        print('MISS:', a[:85].replace('\n', ' '))
s = s.replace('{{cong2018}}', '')          # meeting abstract removed
s = re.sub(r'\{\{cong2020\}\}\s*\{\{cong2020\}\}', '{{cong2020}}', s)
open(p_ms, 'w').write(s)
print(f'\n{n}/{len(EDITS)} review corrections applied')
