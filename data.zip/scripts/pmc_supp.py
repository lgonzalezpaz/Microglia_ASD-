import re, subprocess, sys, os
UA='Mozilla/5.0 (academic-research; lgonzalezpaz@gmail.com)'
def sh(cmd, t=300):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=t).stdout
def supp_links(pmcid):
    num = pmcid.replace('PMC','')
    html = sh(f'curl -sSL --max-time 150 -A "{UA}" "https://pmc.ncbi.nlm.nih.gov/articles/{pmcid}/"')
    return sorted(set(re.findall(r'/articles/instance/'+num+r'/bin/([A-Za-z0-9_.\-]+)', html)))
def download(pmcid, fname, outdir):
    num = pmcid.replace('PMC','')
    os.makedirs(outdir, exist_ok=True)
    dest = os.path.join(outdir, f"{pmcid}_{fname}")
    url = f"https://pmc.ncbi.nlm.nih.gov/articles/instance/{num}/bin/{fname}"
    code = sh(f'curl -sSL --max-time 300 -A "{UA}" -w "%{{http_code}}" -o "{dest}" "{url}"', t=330).strip()
    sz = os.path.getsize(dest) if os.path.exists(dest) else 0
    return dest, code, sz
if __name__=="__main__":
    mode=sys.argv[1]
    if mode=="list":
        for p in sys.argv[2:]:
            print(f"### {p}")
            for f in supp_links(p): print("   ", f)
    elif mode=="get":
        pmcid=sys.argv[2]; outdir=sys.argv[3]
        pats=sys.argv[4:]
        for f in supp_links(pmcid):
            if not pats or any(re.search(p,f,re.I) for p in pats):
                d,c,s = download(pmcid,f,outdir)
                print(f"{c}\t{s:>12,}\t{os.path.basename(d)}")
