"""Publication figures. Vector PDF + 600 dpi PNG, colour-blind-safe, grayscale-legible.

Palette: Okabe-Ito categorical order, validated (worst adjacent CVD dE 11.0, all checks pass).
Secondary encoding (marker shape, line style, hatching, direct labels) carries identity
wherever colour alone would, so every panel survives grayscale printing.
"""
import os as _os
from pathlib import Path as _Path
ROOT = _os.environ.get('PRUNING_AXIS_ROOT',
                       str(_Path(__file__).resolve().parents[1]))
import json, os
import numpy as np, pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from scipy import stats
from scipy.optimize import brentq
from scipy.interpolate import UnivariateSpline

OUT = f'{ROOT}/out'
FIG = f'{ROOT}/figures'
os.makedirs(FIG, exist_ok=True)

C = {'O': '#0072B2', 'K': '#009E73', 'E': '#D55E00', 'S': '#CC79A7', 'X': '#E69F00'}
MK = {'O': 'o', 'K': 's', 'E': '^', 'S': 'D'}
LS = {'O': '-', 'K': '--', 'E': '-.', 'S': ':'}
INK, INK2, INK3 = '#1a1a1a', '#4d4d4d', '#8c8c8c'

mpl.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 7,
    'axes.labelsize': 7.5, 'axes.titlesize': 8, 'axes.titleweight': 'bold',
    'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5, 'legend.fontsize': 6.5,
    'axes.linewidth': 0.6, 'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'xtick.major.size': 2.5, 'ytick.major.size': 2.5,
    'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'text.color': INK,
    'xtick.color': INK2, 'ytick.color': INK2,
    'axes.spines.top': False, 'axes.spines.right': False,
    'legend.frameon': False, 'lines.linewidth': 1.4,
    'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02, 'pdf.fonttype': 42,
})
CM = 1 / 2.54


def save(fig, name):
    fig.savefig(f'{FIG}/{name}.pdf')
    fig.savefig(f'{FIG}/{name}.png', dpi=600)
    plt.close(fig)
    print('  wrote', name)


def panel(ax, letter, dx=-0.055, dy=1.06):
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=9, fontweight='bold',
            va='bottom', ha='right', color=INK)


# ---------------------------------------------------------------- data
ock = pd.read_csv(f'{OUT}/ock_index.csv', index_col=0)
vm = pd.read_csv(f'{OUT}/vulnerability_metrics.csv', index_col=0)
ctm = pd.read_csv(f'{OUT}/celltype_by_module.csv', index_col=0)
qc = json.load(open(f'{OUT}/module_qc.json'))
part = pd.read_csv(f'{OUT}/partial_correlations.csv')
val = pd.read_csv(f'{OUT}/validation_enigma.csv')
dw = pd.read_csv(f'{OUT}/validation_donorwise.csv')
gp = pd.read_csv(f'{OUT}/genetic_partition.csv')
gct = pd.read_csv(f'{OUT}/genetic_partition_celltype.csv')
gctl = pd.read_csv(f'{OUT}/robust_genetic_control.csv')
traj = pd.read_csv(f'{OUT}/brainspan_trajectories.csv', index_col=0)
bw = pd.read_csv(f'{OUT}/brainspan_window.csv', index_col=0)
fam = pd.read_csv(f'{OUT}/robust_devel_fdr.csv')
sens = pd.read_csv(f'{OUT}/vulnerability_sensitivity.csv')
pw = pd.read_csv(f'{OUT}/robust_power.csv')
ENI = f'{ROOT}/data/enigma/enigmatoolbox/datasets/summary_statistics'

order = ock.PC1.sort_values().index.tolist()
S_STAR = 0.60


def phi(S, T, K, n, lam, m):
    return (m * T) ** n / ((m * T) ** n + (K * (1 + lam * S)) ** n)


def s_eq(T, K, E, sig, n, lam, m):
    f = lambda s: sig * (1 - s) - E * s * phi(s, T, K, n, lam, m)
    g = np.linspace(1e-7, 1, 4001); v = f(g)
    rts = [brentq(f, g[i], g[i + 1]) for i in np.where(np.diff(np.sign(v)) != 0)[0]]
    return max(rts) if rts else np.nan


# ================================================= FIGURE 1  framework & model
fig = plt.figure(figsize=(18 * CM, 13 * CM))
gs = fig.add_gridspec(2, 3, hspace=0.58, wspace=0.46)

# (a) schematic
ax = fig.add_subplot(gs[0, :2]); panel(ax, 'a', dx=-0.03)
ax.set_xlim(0, 10); ax.set_ylim(0, 5.4); ax.axis('off')
ax.set_title('Three regulatory layers of the pruning axis', loc='left', pad=4)
# neuron / synapse
ax.add_patch(FancyBboxPatch((0.3, 2.0), 2.3, 1.5, boxstyle='round,pad=0.12',
                            fc='#f2f2f2', ec=INK2, lw=0.7))
ax.text(1.45, 3.15, 'Neuron / synapse', ha='center', fontsize=7, fontweight='bold')
ax.text(1.45, 2.62, 'substrate (S)\nSYN1 · DLG4 · SHANK3\nNLGN · GRIN2B',
        ha='center', va='center', fontsize=6, color=INK2)
# opsonin
ax.add_patch(FancyBboxPatch((3.3, 3.5), 2.5, 1.5, boxstyle='round,pad=0.12',
                            fc='#deebf4', ec=C['O'], lw=1.0))
ax.text(4.55, 4.65, 'Opsonin tag (O)', ha='center', fontsize=7, fontweight='bold', color=C['O'])
ax.text(4.55, 4.05, '"eat me"\nC1q · C3 · C4A/B\nNPTX1/2', ha='center', va='center',
        fontsize=6, color=INK2)
# checkpoint
ax.add_patch(FancyBboxPatch((3.3, 0.45), 2.5, 1.5, boxstyle='round,pad=0.12',
                            fc='#ddefe8', ec=C['K'], lw=1.0))
ax.text(4.55, 1.60, 'Checkpoint (K)', ha='center', fontsize=7, fontweight='bold', color=C['K'])
ax.text(4.55, 1.00, '"don\'t eat me"\nCD47–SIRPα · CD200\nSRPX2 · CSMD1', ha='center',
        va='center', fontsize=6, color=INK2)
# microglia
ax.add_patch(FancyBboxPatch((6.9, 2.0), 2.8, 1.5, boxstyle='round,pad=0.12',
                            fc='#f8e2d2', ec=C['E'], lw=1.0))
ax.text(8.3, 3.15, 'Microglial effector (E)', ha='center', fontsize=7,
        fontweight='bold', color=C['E'])
ax.text(8.3, 2.62, 'CR3 (ITGAM/ITGB2)\nTREM2 · MERTK · CD68', ha='center', va='center',
        fontsize=6, color=INK2)
for xy1, xy2, col, st in [((2.6, 3.0), (3.3, 3.9), C['O'], '-'),
                          ((2.6, 2.5), (3.3, 1.5), C['K'], '-'),
                          ((5.8, 3.9), (6.9, 3.1), C['O'], '-'),
                          ((5.8, 1.5), (6.9, 2.4), C['K'], '-')]:
    ax.add_patch(FancyArrowPatch(xy1, xy2, arrowstyle='-|>', mutation_scale=8,
                                 color=col, lw=1.0, linestyle=st,
                                 connectionstyle='arc3,rad=0.12'))
ax.add_patch(FancyArrowPatch((7.9, 2.0), (2.5, 1.9), arrowstyle='-|>', mutation_scale=9,
                             color=INK, lw=1.2, connectionstyle='arc3,rad=0.25'))
ax.text(5.2, 0.12, 'engulfment  ⟶  synapse elimination', ha='center', fontsize=6.3,
        style='italic', color=INK)
ax.text(9.95, 4.9, 'promotes', fontsize=6, color=C['O'], ha='right', fontweight='bold')
ax.text(9.95, 4.55, 'restrains', fontsize=6, color=C['K'], ha='right', fontweight='bold')

# (b) Hill curves
ax = fig.add_subplot(gs[0, 2]); panel(ax, 'b')
ratio = np.logspace(-1.2, 1.2, 300)
for i, n in enumerate([1, 2, 4]):
    y = ratio ** n / (ratio ** n + 1)
    ax.plot(ratio, y, color=[INK3, C['O'], INK][i], ls=['-', '-', '--'][i],
            lw=1.3, label=f'$n$ = {n}')
ax.set_xscale('log'); ax.set_xlabel('opsonin : checkpoint  ($T/K_{\\rm eff}$)')
ax.set_ylabel('engulfment probability  $\\Phi$')
ax.axhline(0.5, color=INK3, lw=0.5, ls=':')
ax.set_title('Cooperative engulfment', loc='left', pad=4)
ax.legend(loc='upper left')

# (c) response curves: low vs high baseline Phi
ax = fig.add_subplot(gs[1, 0]); panel(ax, 'c')
ms = np.geomspace(1, 12, 120)
for lbl, (T, K), col, ls in [('low  $T/K$ (primary)', (0.6, 1.4), C['K'], '--'),
                             ('high $T/K$ (association)', (1.5, 0.9), C['O'], '-')]:
    E = 1.0
    sig = E * S_STAR * phi(S_STAR, T, K, 2, 1.5, 1) / (1 - S_STAR)
    ax.plot(ms, [s_eq(T, K, E, sig, 2, 1.5, m) / S_STAR for m in ms],
            color=col, ls=ls, lw=1.5, label=lbl)
ax.axhline(0.5, color=INK3, lw=0.6, ls=':')
ax.text(11.5, 0.52, '50% loss', fontsize=5.8, ha='right', color=INK2)
ax.set_xscale('log'); ax.set_xlabel('opsonin perturbation  $m$  (fold)')
ax.set_ylabel('synapses, fraction of baseline')
ax.set_title('Fractional loss', loc='left', pad=4); ax.legend(loc='lower left')

# (d) E cancellation
ax = fig.add_subplot(gs[1, 1]); panel(ax, 'd')
T, K = 1.2, 1.0
for i, E in enumerate([0.4, 1.0, 2.5]):
    sig = E * S_STAR * phi(S_STAR, T, K, 2, 1.5, 1) / (1 - S_STAR)
    ax.plot(ms, [s_eq(T, K, E, sig, 2, 1.5, m) / S_STAR for m in ms],
            color=[C['E'], INK, C['X']][i], ls=['-', '--', ':'][i],
            lw=[2.6, 1.6, 1.0][i], alpha=[0.45, 1, 1][i], label=f'$E$ = {E}')
ax.set_xscale('log'); ax.set_xlabel('opsonin perturbation  $m$  (fold)')
ax.set_ylabel('synapses, fraction of baseline')
ax.set_title('Effector capacity cancels', loc='left', pad=4)
ax.legend(loc='lower left', title='curves coincide', title_fontsize=6)

# (e) absolute excess flux does scale with E
ax = fig.add_subplot(gs[1, 2]); panel(ax, 'e')
Es = np.linspace(0.3, 3, 100)
for mm, ls, col in [(1.5, ':', INK3), (2.0, '--', C['E']), (3.0, '-', INK)]:
    dJ = Es * S_STAR * (phi(S_STAR, T, K, 2, 1.5, mm) - phi(S_STAR, T, K, 2, 1.5, 1))
    ax.plot(Es, dJ, color=col, ls=ls, lw=1.4, label=f'$m$ = {mm}')
ax.set_xlabel('effector capacity  $E$'); ax.set_ylabel('excess elimination flux  $\\Delta J$')
ax.set_title('Excess flux scales with $E$', loc='left', pad=4)
ax.legend(loc='upper left')
save(fig, 'Figure1_framework_and_model')

# ================================================= FIGURE 2  regional architecture
fig = plt.figure(figsize=(18 * CM, 17 * CM))
gs = fig.add_gridspec(3, 3, hspace=1.05, wspace=0.50,
                      height_ratios=[1.0, 0.80, 1.0])

# (a) layer scores along the hierarchy
ax = fig.add_subplot(gs[0, :]); panel(ax, 'a', dx=-0.025)
x = np.arange(len(order))
for m in ['O', 'K', 'E', 'S']:
    ax.plot(x, ock.loc[order, m].values, color=C[m], ls=LS[m], marker=MK[m],
            ms=2.8, lw=1.1, label=f'{m}', mec='white', mew=0.3)
ax.set_xticks(x); ax.set_xticklabels(order, rotation=90, fontsize=5.4)
ax.set_ylabel('module score (z)')
ax.axhline(0, color=INK3, lw=0.5)
ax.set_xlim(-0.6, len(order) - 0.4)
ax.set_title('Layer scores along the sensorimotor→association axis', loc='left', pad=4)
ax.legend(ncol=4, loc='upper left', fontsize=6.2)
ax.annotate('', xy=(len(order) - 1, ax.get_ylim()[0] * 0.98), xytext=(0, ax.get_ylim()[0] * 0.98),
            arrowprops=dict(arrowstyle='-|>', color=INK3, lw=0.7))

# (b) cell-type attribution
ax = fig.add_subplot(gs[1, 0]); panel(ax, 'b')
cells = ['Neuron', 'Microglia', 'Astrocyte', 'Oligo/OPC', 'Vascular']
cols = [C['S'], C['E'], C['K'], INK3, C['X']]
htch = ['', '///', '...', 'xxx', '\\\\\\']
mods = ['O', 'K', 'E', 'S']
bot = np.zeros(len(mods))
for cell, col, h in zip(cells, cols, htch):
    v = ctm.loc[mods, cell].values if cell in ctm.columns else np.zeros(len(mods))
    ax.bar(mods, v, bottom=bot, color=col, hatch=h, edgecolor='white',
           linewidth=0.8, label=cell)
    bot += v
ax.set_ylabel('fraction of expression'); ax.set_ylim(0, 1)
ax.set_xlabel('module')
ax.set_title('Cellular ownership', loc='left', pad=4)
ax.legend(fontsize=5.4, loc='upper center', bbox_to_anchor=(0.5, -0.32), ncol=3)

# (c) co-regulation O vs K
ax = fig.add_subplot(gs[1, 1]); panel(ax, 'c')
ax.scatter(ock.O, ock.K, s=18, c=ock.PC1, cmap='cividis', edgecolor='white', lw=0.4)
lim = [min(ock.O.min(), ock.K.min()) - 0.1, max(ock.O.max(), ock.K.max()) + 0.1]
ax.plot(lim, lim, color=INK3, ls=':', lw=0.8)
r, p = stats.spearmanr(ock.O, ock.K)
ax.text(0.04, 0.95, f'$\\rho$ = {r:+.2f}\n$P$ = {p:.1e}', transform=ax.transAxes,
        va='top', fontsize=6.3)
ax.set_xlabel('opsonin  $O$  (z)'); ax.set_ylabel('checkpoint  $K$  (z)')
ax.set_title('O and K co-regulated', loc='left', pad=4)
ax.text(0.97, 0.05, 'colour = hierarchy (PC1)', transform=ax.transAxes,
        ha='right', fontsize=5.4, color=INK2)

# (d) partial correlation specifications
ax = fig.add_subplot(gs[1, 2]); panel(ax, 'd')
specs = ['extensive (unadjusted)', 'intensive (own expressing cell types)',
         'fully adjusted (all composition panels)']
w = 0.26
for i, sp_ in enumerate(specs):
    v = [part[(part.module == m) & (part.specification == sp_)].rho.values[0] for m in mods]
    ax.bar(np.arange(len(mods)) + (i - 1) * w, v, width=w,
           color=[INK3, C['O'], C['K']][i], hatch=['', '///', '...'][i],
           edgecolor='white', lw=0.6,
           label=['extensive', 'per-cell', 'fully adj.'][i])
ax.set_xticks(np.arange(len(mods))); ax.set_xticklabels(mods)
ax.axhline(0, color=INK2, lw=0.6)
ax.set_ylabel('$\\rho$ with PC1'); ax.set_xlabel('module')
ax.set_title('Per-cell adjustment', loc='left', pad=4)
ax.legend(fontsize=5.8, loc='upper right')

# (e) OCB ranking
ax = fig.add_subplot(gs[2, :]); panel(ax, 'e', dx=-0.025)
o2 = ock.OCB.sort_values().index.tolist()
v = ock.loc[o2, 'OCB'].values
ax.bar(np.arange(len(o2)), v, color=[C['O'] if t > 0 else C['K'] for t in v],
       edgecolor='white', lw=0.5, width=0.78)
ax.set_xticks(np.arange(len(o2))); ax.set_xticklabels(o2, rotation=90, fontsize=5.4)
ax.axhline(0, color=INK2, lw=0.6)
ax.set_ylabel('opsonin–checkpoint\nbalance (z)')
ax.set_xlim(-0.6, len(o2) - 0.4)
ax.set_title('Opsonin–checkpoint balance by parcel', loc='left', pad=4)
ax.legend(handles=[Rectangle((0, 0), 1, 1, fc=C['O'], ec='white'),
                   Rectangle((0, 0), 1, 1, fc=C['K'], ec='white')],
          labels=['tag-dominant', 'checkpoint-dominant'], ncol=2,
          loc='upper left', fontsize=6, bbox_to_anchor=(0.0, 1.02))
save(fig, 'Figure2_regional_architecture')

# ================================================= FIGURE 3  validation
asd = pd.read_csv(f'{ENI}/asd_mega-analysis_case-controls_CortThick.csv')
asd = asd[asd.Structure.str.startswith('L_')].copy(); asd['region'] = asd.Structure.str[2:]
asd = asd.set_index('region').d_icv

fig = plt.figure(figsize=(18 * CM, 11 * CM))
gs = fig.add_gridspec(2, 3, hspace=0.62, wspace=0.46)

# (a) scatter
ax = fig.add_subplot(gs[0, 0]); panel(ax, 'a')
common = [r for r in ock.index if r in asd.index and np.isfinite(asd[r])]
xx = ock.loc[common, 'OCB_percell'].values; yy = asd.loc[common].values
ax.scatter(xx, yy, s=16, color=C['O'], edgecolor='white', lw=0.4)
b = np.polyfit(xx, yy, 1)
xs = np.linspace(xx.min(), xx.max(), 50)
ax.plot(xs, np.polyval(b, xs), color=INK, lw=1.0, ls='--')
row = val[(val.predictor == 'OCB_percell') & (val.target == 'ASD_mega_d')].iloc[0]
ax.text(0.96, 0.95, f'$\\rho$ = {row.rho:+.2f}\n$P_{{\\rm spatial}}$ = {row.p_spatial:.3f}',
        transform=ax.transAxes, fontsize=6.3, ha='right', va='top')
for r_ in ['entorhinal', 'temporalpole']:
    if r_ in common:
        ax.annotate(r_, (ock.loc[r_, 'OCB_percell'], asd[r_]), fontsize=5.2,
                    xytext=(5, -7), textcoords='offset points', color=INK2)
ax.axhline(0, color=INK3, lw=0.5)
ax.set_xlabel('per-cell opsonin–checkpoint balance')
ax.set_ylabel("autism cortical thickness\nCohen's $d$")
ax.set_title('Prediction vs observation', loc='left', pad=4)

# (b) spatial null
ax = fig.add_subplot(gs[0, 1]); panel(ax, 'b')
sd = row.null_sd; mu = row.null_mean
g = np.linspace(-1, 1, 400)
ax.fill_between(g, stats.norm.pdf(g, mu, sd), color=INK3, alpha=0.30, lw=0)
ax.plot(g, stats.norm.pdf(g, mu, sd), color=INK2, lw=0.9)
ax.axvline(row.rho, color=C['E'], lw=1.6)
ax.axvline(mu + 1.96 * sd, color=INK, ls=':', lw=0.8)
ax.axvline(mu - 1.96 * sd, color=INK, ls=':', lw=0.8)
ax.text(row.rho, ax.get_ylim()[1] * 0.92, ' observed', color=C['E'], fontsize=6, ha='left')
ax.set_xlabel('$\\rho$ under spatial nulls'); ax.set_ylabel('density')
ax.set_title('Spatial null', loc='left', pad=4)

# (c) detectability
ax = fig.add_subplot(gs[0, 2]); panel(ax, 'c')
sub = pw[pw.target == 'ASD_mega_d'].sort_values('detectable_abs_rho_95')
yv = np.arange(len(sub))
ax.barh(yv, sub.detectable_abs_rho_95, color=INK3, alpha=0.35, height=0.6,
        label='detectable at 95%')
ax.scatter(sub.rho.abs(), yv, color=C['E'], s=14, zorder=3, label='observed $|\\rho|$')
ax.set_yticks(yv); ax.set_yticklabels(sub.predictor, fontsize=5.4)
ax.set_xlabel('|$\\rho$|'); ax.set_title('Detectability', loc='left', pad=4)
ax.legend(fontsize=5.5, loc='upper center', bbox_to_anchor=(0.5, -0.22), ncol=2)

# (d) donor-wise
ax = fig.add_subplot(gs[1, 0]); panel(ax, 'd')
piv = dw.pivot(index='donor', columns='target', values='rho')
tcols = ['ASD_mega_d', 'ASD_meta_d', 'SCZ_d']
for i, t in enumerate(tcols):
    jit = (np.arange(len(piv)) - len(piv) / 2) * 0.035
    ax.scatter(np.full(len(piv), i) + jit, piv[t].values, s=14,
               color=[C['O'], C['K'], C['X']][i], edgecolor='white', lw=0.4)
    ax.plot([i - 0.22, i + 0.22], [piv[t].mean()] * 2, color=INK, lw=1.6)
ax.axhline(0, color=INK3, lw=0.6)
ax.set_xticks(range(3)); ax.set_xticklabels(['ASD\nmega', 'ASD\nmeta', 'SCZ'], fontsize=6)
ax.set_ylabel('$\\rho$ (balance vs $d$)')
ax.set_title('Per-donor consistency', loc='left', pad=4)

# (e) all predictors heat
ax = fig.add_subplot(gs[1, 1:]); panel(ax, 'e', dx=-0.02)
pv = val.pivot(index='predictor', columns='target', values='rho').reindex(
    ['O', 'K', 'E', 'S', 'OCB', 'OCB_percell', 'Phi_base', 'flux_base',
     'A_frac_loss', 'B_excess_flux', 'PC1'])
im = ax.imshow(pv.values, cmap='PuOr_r', vmin=-0.5, vmax=0.5, aspect='auto')
ax.set_xticks(range(pv.shape[1])); ax.set_xticklabels(pv.columns, fontsize=6)
ax.set_yticks(range(pv.shape[0])); ax.set_yticklabels(pv.index, fontsize=6)
for i in range(pv.shape[0]):
    for j in range(pv.shape[1]):
        q = val[(val.predictor == pv.index[i]) & (val.target == pv.columns[j])]
        star = '*' if (len(q) and q.p_spatial.values[0] < 0.05) else ''
        ax.text(j, i, f'{pv.values[i,j]:+.2f}{star}', ha='center', va='center',
                fontsize=5.6, color=INK)
cb = plt.colorbar(im, ax=ax, pad=0.02, fraction=0.03); cb.set_label('$\\rho$', fontsize=6)
cb.ax.tick_params(labelsize=5.5)
ax.set_title('All predictors × targets (*$P_{\\rm spatial}$<0.05)', loc='left', pad=4)
save(fig, 'Figure3_spatial_validation')

# ================================================= FIGURE 4  genetics
fig = plt.figure(figsize=(18 * CM, 12 * CM))
gs = fig.add_gridspec(2, 3, hspace=0.60, wspace=0.52)

# (a) module z-scores
ax = fig.add_subplot(gs[0, :2]); panel(ax, 'a', dx=-0.03)
gp2 = gp.copy(); gp2['mod'] = gp2.gene_set.str.replace('module_', '', regex=False)
gp2 = gp2.set_index('mod').reindex(mods)
meas = [('sfari_any_z', 'SFARI autism genes', C['O'], ''),
        ('ot_asd_z', 'Open Targets genetic, autism', C['E'], '///'),
        ('ot_scz_z', 'Open Targets genetic, schizophrenia', C['K'], '...')]
w = 0.26
for i, (col, lbl, cc, h) in enumerate(meas):
    ax.bar(np.arange(len(mods)) + (i - 1) * w, gp2[col].values, width=w, color=cc,
           hatch=h, edgecolor='white', lw=0.6, label=lbl)
for i, (col, _, _, _) in enumerate(meas):
    for j, m in enumerate(mods):
        p_ = gp2.loc[m, col.replace('_z', '_p')]
        if p_ < 0.05:
            ax.text(j + (i - 1) * w, gp2.loc[m, col] + 0.3, '*', ha='center', fontsize=8)
ax.axhline(0, color=INK2, lw=0.6)
for yv_ in (1.96, -1.96):
    ax.axhline(yv_, color=INK3, ls=':', lw=0.7)
ax.set_xticks(np.arange(len(mods)))
ax.set_xticklabels(['O\nopsonin', 'K\ncheckpoint', 'E\neffector', 'S\nsubstrate'], fontsize=6.3)
ax.set_ylabel('enrichment $z$ vs matched null')
ax.set_title('Risk loads on the synaptic substrate', loc='left', pad=4)
ax.legend(fontsize=5.9, loc='upper left')

# (b) observed vs null proportion
ax = fig.add_subplot(gs[0, 2]); panel(ax, 'b')
xo = np.arange(len(mods))
ax.bar(xo - 0.19, gp2.sfari_any_obs.values, width=0.36, color=C['O'],
       edgecolor='white', lw=0.6, label='observed')
ax.bar(xo + 0.19, gp2.sfari_any_null.values, width=0.36, color=INK3, alpha=0.5,
       hatch='///', edgecolor='white', lw=0.6, label='matched null')
ax.set_xticks(xo); ax.set_xticklabels(mods)
ax.set_ylabel('fraction SFARI')
ax.set_title('Observed vs null', loc='left', pad=4)
ax.legend(fontsize=5.9)

# (c) circularity control
ax = fig.add_subplot(gs[1, 0]); panel(ax, 'c')
lab = {'S_full': 'S, all genes', 'S_minus_SFARI_score1': 'S, minus score-1',
       'S_minus_SFARI_score1_2': 'S, minus score-1/2', 'E_full': 'E, all genes'}
g2 = gctl.set_index('gene_set').reindex(list(lab))
yv = np.arange(len(g2))
ax.barh(yv, g2.sfari_any_z.values, color=[C['S'], C['S'], C['S'], C['E']],
        alpha=0.9, height=0.6, edgecolor='white', lw=0.6)
ax.axvline(1.96, color=INK3, ls=':', lw=0.7)
ax.set_yticks(yv); ax.set_yticklabels([lab[i] for i in g2.index], fontsize=5.8)
ax.set_xlabel('enrichment $z$')
ax.set_title('Circularity control', loc='left', pad=4)

# (d) cell-type marker sets
ax = fig.add_subplot(gs[1, 1]); panel(ax, 'd')
g3 = gct[gct.gene_set.str.endswith('top1000')].copy()
g3['cell'] = g3.gene_set.str.replace('_top1000', '', regex=False)
yv = np.arange(len(g3))
ax.barh(yv, g3.sfari_any_z.values, color=INK3, alpha=0.6, height=0.6,
        edgecolor='white', lw=0.6, label='SFARI')
ax.scatter(g3.ot_asd_z.values, yv, color=C['E'], s=16, zorder=3,
           label='Open Targets genetic')
ax.axvline(1.96, color=INK3, ls=':', lw=0.7); ax.axvline(0, color=INK2, lw=0.6)
ax.set_yticks(yv); ax.set_yticklabels(g3.cell, fontsize=5.8)
ax.set_xlabel('enrichment $z$')
ax.set_title('Cell-type marker sets', loc='left', pad=4)
ax.legend(fontsize=5.4, loc='upper center', bbox_to_anchor=(0.5, -0.30), ncol=2)

# (e) module S vs E effect sizes with CI
ax = fig.add_subplot(gs[1, 2]); panel(ax, 'e')
bci = pd.read_csv(f'{OUT}/robust_power_genetic.csv')
b2 = bci[(bci.measure == 'sfari_any') & (bci.gene_set.isin(['S_full', 'E_full']))]
yv = np.arange(len(b2))
ax.errorbar(b2.observed, yv, xerr=[b2.observed - b2.ci_lo, b2.ci_hi - b2.observed],
            fmt='o', color=INK, ms=4, capsize=2, lw=1.0)
for i, gsn in enumerate(b2.gene_set):
    nullv = gp2.loc['S' if gsn == 'S_full' else 'E', 'sfari_any_null']
    ax.scatter([nullv], [i], marker='|', s=90, color=C['E'], zorder=3)
ax.set_yticks(yv); ax.set_yticklabels(['substrate (S)', 'effector (E)'], fontsize=6)
ax.set_xlabel('fraction SFARI (95% CI)')
ax.set_title('Effect sizes', loc='left', pad=4)
ax.legend(handles=[Line2D([], [], marker='o', color=INK, ls='', ms=4),
                   Line2D([], [], marker='|', color=C['E'], ls='', ms=8)],
          labels=['observed', 'matched null'], fontsize=5.4,
          loc='upper center', bbox_to_anchor=(0.5, -0.30), ncol=2)
save(fig, 'Figure4_genetic_partition')

# ================================================= FIGURE 5  development
fig = plt.figure(figsize=(18 * CM, 10.5 * CM))
gs = fig.add_gridspec(2, 3, hspace=0.62, wspace=0.62)
GEST = 280.0
traj['log_pcd'] = np.log10(traj.pcd)
grid = np.linspace(np.log10(56), np.log10(GEST + 40 * 365.25), 300)

for k, m in enumerate(['O', 'K', 'E']):
    ax = fig.add_subplot(gs[0, k]); panel(ax, 'abc'[k])
    for hier, cc, ls in [('primary', C['K'], '--'), ('association', C['O'], '-')]:
        sub = traj[traj.hierarchy == hier]
        ax.scatter(sub.log_pcd, sub[m], s=3.2, color=cc, alpha=0.30, lw=0)
        xu = np.unique(sub.log_pcd.values)
        yu = np.array([sub.loc[sub.log_pcd == u, m].mean() for u in xu])
        sp_ = UnivariateSpline(xu, yu, s=len(xu) * 0.35, k=3)
        ax.plot(grid, sp_(grid), color=cc, ls=ls, lw=1.6, label=hier)
    ax.axvline(np.log10(GEST), color=INK3, lw=0.6, ls=':')
    ax.text(np.log10(GEST), ax.get_ylim()[1], ' birth', fontsize=5.5, color=INK2, va='top')
    tick_y = [0, 1, 5, 20]
    ax.set_xticks([np.log10(GEST + t * 365.25) for t in tick_y])
    ax.set_xticklabels([str(t) for t in tick_y], fontsize=6)
    ax.set_xlabel('age (years post-natal)')
    ax.set_ylabel(f'module {m} (z)' if k == 0 else '')
    ax.set_title({'O': 'Opsonin', 'K': 'Checkpoint', 'E': 'Effector'}[m], loc='left', pad=4)
    if k == 0:
        ax.legend(fontsize=6, loc='lower right')

# (d) per-region peak timing
ax = fig.add_subplot(gs[1, :2]); panel(ax, 'd', dx=-0.03)
bw2 = bw.sort_values('E_peak_log_pcd')
yv = np.arange(len(bw2))
for m, cc in [('O', C['O']), ('E', C['E']), ('K', C['K'])]:
    col = f'{m}_peak_log_pcd'
    if col in bw2.columns:
        ax.scatter(bw2[col], yv, s=22, color=cc, marker=MK[m], edgecolor='white',
                   lw=0.4, label=f'module {m}')
ax.set_yticks(yv)
ax.set_yticklabels([f'{r} ({"P" if bw2.loc[r,"hierarchy"]=="primary" else "A"})'
                    for r in bw2.index], fontsize=6)
tick_y = [0, 1, 5, 20, 40]
ax.set_xticks([np.log10(GEST + t * 365.25) for t in tick_y])
ax.set_xticklabels([str(t) for t in tick_y])
ax.set_xlabel('age of peak engagement (years post-natal)')
ax.axvline(np.log10(GEST), color=INK3, lw=0.6, ls=':')
ax.set_title('Peak engagement age by region', loc='left', pad=4)
ax.legend(fontsize=6, loc='lower right', bbox_to_anchor=(1.0, 0.02))

# (e) exact permutation family
ax = fig.add_subplot(gs[1, 2]); panel(ax, 'e')
f2 = fam.sort_values('p_exact')
yv = np.arange(len(f2))
ax.barh(yv, -np.log10(f2.p_exact.values), color=C['E'], height=0.6,
        edgecolor='white', lw=0.6)
ax.axvline(-np.log10(0.05), color=INK, ls=':', lw=0.8)
ax.text(-np.log10(0.05), -0.9, ' $P$=0.05', fontsize=5.6, color=INK2)
ax.set_yticks(yv); ax.set_yticklabels([f.replace('_',' ') for f in f2.feature], fontsize=5.6)
ax.yaxis.tick_right(); ax.yaxis.set_label_position('right')
ax.set_xlabel('$-\\log_{10} P$ (exact permutation)')
ax.set_title('Timing hypothesis family', loc='left', pad=4)
save(fig, 'Figure5_development')

# ================================================= FIGURE 6  sensitivity
fig = plt.figure(figsize=(18 * CM, 6.2 * CM))
gs = fig.add_gridspec(1, 3, wspace=0.42)
for k, (col, ttl) in enumerate([('rho_A_frac_loss_PC1', 'Metric A: fractional loss'),
                                ('rho_B_excess_flux_PC1', 'Metric B: excess flux'),
                                ('rho_C_RPVI_PC1', 'Metric C: reserve')]):
    ax = fig.add_subplot(gs[0, k]); panel(ax, 'abc'[k])
    if col not in sens.columns:
        ax.axis('off'); continue
    pt = sens.pivot_table(index='n', columns='lam', values=col, aggfunc='mean')
    im = ax.imshow(pt.values, cmap='PuOr_r', vmin=-1, vmax=1, aspect='auto')
    ax.set_xticks(range(pt.shape[1])); ax.set_xticklabels(pt.columns)
    ax.set_yticks(range(pt.shape[0])); ax.set_yticklabels(pt.index)
    for i in range(pt.shape[0]):
        for j in range(pt.shape[1]):
            if np.isfinite(pt.values[i, j]):
                ax.text(j, i, f'{pt.values[i,j]:+.2f}', ha='center', va='center', fontsize=5.8)
    ax.set_xlabel('checkpoint potentiation  $\\lambda$')
    ax.set_ylabel('Hill coefficient  $n$' if k == 0 else '')
    ax.set_title(ttl, loc='left', pad=4)
    if k == 2:
        cb = plt.colorbar(im, ax=ax, pad=0.03, fraction=0.045)
        cb.set_label('$\\rho$ with hierarchy', fontsize=6); cb.ax.tick_params(labelsize=5.5)
save(fig, 'Figure6_parameter_sensitivity')
print('\nDONE_13')
