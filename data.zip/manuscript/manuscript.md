# Microglia execute but do not specify: target-encoded autism risk and the developmental timing of complement-dependent synaptic pruning in human cortex

[AUTHOR]^1,*^

^1^[AFFILIATION]

^*^Correspondence: lgonzalezpaz@gmail.com ([AUTHOR])

---

## Abstract

Low-grade neuroinflammation and microglia-mediated synaptic over-pruning have converged as a central mechanism in idiopathic autism, yet two questions remain open: whether aberrant microglial activity is a primary immune lesion or a reaction to neurons already mis-specified, and why defective pruning preferentially affects cortex serving language and social cognition while sparing primary sensory and motor areas. We combine a biophysical model of complement-dependent synapse elimination with open human transcriptomic, genetic and neuroimaging data. Partitioning the pruning axis into an opsonin tag layer, a neuronal checkpoint layer, a microglial effector layer and a synaptic substrate, we find that all three regulatory layers rise along the sensorimotor-to-association hierarchy while the substrate is flat, and that tag and checkpoint layers are co-regulated, conserving their per-cell ratio while their absolute setting rises together. The model yields an exact structural result: once baseline synaptic density is homeostatically matched, fractional synapse loss under an immune perturbation is independent of microglial effector capacity, which cancels identically. Consistent with a target-encoded lesion, autism genetic risk concentrates on the synaptic substrate while the effector layer is indistinguishable from matched background; schizophrenia risk additionally reaches complement checkpoints. Adult expression gradients do not predict autism cortical thickness once spatial autocorrelation is respected, though underpowered for effects of this size. A developmental contrast is sharper: microglial effector programmes peak several years later in association than in primary cortex, separating the two completely. We propose, as a hypothesis these data motivate rather than establish, that microglial pruning is regionally timed rather than tonically graded.

**Keywords:** autism spectrum disorder; synaptic pruning; complement; microglia; cortical hierarchy; imaging transcriptomics; neurodevelopment; CD47–SIRPα

---

## Introduction

Microglia sculpt developing circuits by engulfing synapses tagged by the classical complement cascade^1,2^, and in the healthy brain the same contact and signalling repertoire supports synaptic plasticity, learning and memory^3^. Loss of microglial fractalkine signalling delays pruning, weakens functional connectivity and produces reduced sociability and repetitive grooming in mice^4,5^, and complement-dependent elimination has since been implicated across schizophrenia, Alzheimer's disease and Huntington's disease^6–8^. In idiopathic autism, low-grade neuroinflammation together with altered microglial pruning has become a convergent pathophysiological account with clear therapeutic appeal^9,10^.

Two questions, however, remain open, and they are logically prior to any therapeutic inference. The first is causal attribution. Cell-autonomous manipulation of microglial genes is sufficient to produce pathological pruning and behavioural deficits^5,11,12^, which supports an immune-intrinsic lesion. Yet dysfunctional neurons also upregulate "eat-me" signals that actively recruit microglia to the synapses they have marked: patient-derived models of schizophrenia show concurrent abnormalities in neuronal synaptic structures and in the microglial phagocytic phenotype^13^, and in autism models complement C4b induction in prefrontal neurons drives excessive microglial pruning that is rescued by removing microglia or deleting C4b^14^. Both readings are supported, and the field increasingly treats them as bidirectional^15,16^. What is missing is a test that can distinguish where the primary lesion sits rather than confirming that both participate. Large-scale exome and genome-wide studies have shown that autism liability is dominated by genes acting in neurons, particularly chromatin regulators and synaptic components^17,18^, which makes the genetic architecture of each layer an informative discriminator.

The second question is regional specificity. Complement-dependent pruning was characterised in the visual thalamus^1,2^, yet the clinical burden of autism falls on cortex supporting language and social cognition. Partial explanations exist: psychosocial stress elicits regionally restricted C3 activation and an Apoe-high microglial state in medial prefrontal cortex^19^; frontal association cortex prunes dendritic spines into the third decade, far later than sensory cortex^20^; and inhibitory checkpoints such as CD47–SIRPα and the endogenous C1q inhibitor SRPX2 are heterogeneously expressed^11,21,22^. Notably SRPX2, which restrains complement-mediated synapse elimination^22^, is also the human language-associated gene whose disruption alters synapse formation and vocalisation^23^. But no quantitative account explains why a diffuse immune perturbation should produce focal damage, and recent work showing that hippocampal excitatory pruning proceeds independently of C3 in both physiological and neuroinflammatory states^24^ indicates that complement dependence is itself regionally and synapse-type contingent. Post-mortem cortical transcriptomics compounds the difficulty: autistic cortex shows attenuated regional patterning and broad, cell-type-resolved dysregulation affecting both neuronal and glial populations^25–27^, a signature compatible with either a primary immune lesion or a reactive one.

We reasoned that both questions turn on the same underlying structure. Synapse elimination is not a single pathway but a three-layer control system: an opsonin tag layer that marks synapses^1,2,28^; a checkpoint layer that protects them^11,21,22,29,30^; and a microglial effector layer that executes engulfment^31–33^. These act on a synaptic substrate^34^. Causal attribution asks which layer carries the primary lesion; regional specificity asks how the layers are spatially and temporally arranged. Formalising the system makes both questions quantitative and, importantly, falsifiable.

Here we build that formalisation and confront it with openly available human data: adult cortical microarray from the Allen Human Brain Atlas^35^, the BrainSpan developmental transcriptome^36^, cell-type-resolved human cortical single-nucleus data^37^, curated and genome-wide genetic risk^38,39^, and case–control cortical-thickness effect sizes from the ENIGMA consortium^40,41^. All analyses are low-cost, fully reproducible and restricted to data requiring no restricted-access agreement. We report a structural result that constrains what microglial activation can and cannot explain, a genetic partition that localises autism risk to the synaptic target, an informative negative result for adult expression gradients as predictors of regional vulnerability, and a developmental timing difference that survives exact permutation testing.

---

## Methods

### Regional cortical expression

Adult human cortical gene expression was obtained from the Allen Human Brain Atlas (AHBA; six donors, 3,702 tissue samples)^35^ and processed with abagen v0.1.3^42^ following the recommended workflow for imaging transcriptomics^43^: probe reannotation, intensity-based filtering at 0.5, probe selection by differential stability, scaled robust sigmoid normalisation of samples and genes, and assignment of samples to the volumetric Desikan–Killiany atlas^44^. Because only two donors contributed right-hemisphere tissue, analyses used the 34 left cortical parcels, yielding a 34 × 15,633 region-by-gene matrix. Per-donor matrices were retained to quantify reliability.

### Definition of the pruning axis

Four modules were defined *a priori* from functional literature, with one supporting reference per gene (Supplementary Data; `data/modules/pruning_axis_modules.csv`), before any analysis of outcome data:

- **O, opsonin tag** — classical complement components and neuronal pentraxins that mark synapses for removal^1,2,6,28^ (13 genes). Phosphatidylserine externalisation is an additional, well-established eat-me signal^45^ but was excluded because its directionality depends on the balance of scramblases and flippases and cannot be read unambiguously from transcript level.
- **K, checkpoint** — "don't-eat-me" ligands and receptors and endogenous complement inhibitors^11,21–23,29,30,46^ (17 genes).
- **E, microglial effector** — complement and phagocytic receptors, lysosomal machinery and microglial identity factors^2,4,31–33^ (25 genes).
- **S, synaptic substrate** — canonical pre- and postsynaptic components^34^ (36 genes).

Of these, 11/13 O, 12/17 K, 23/25 E and 36/36 S genes survived into the processed expression matrix. *C4B* is not represented on the array at all; the remaining absentees — *C4A* and the checkpoint genes *SRPX2*, *CD200R1*, *CFI*, *CR1* and *CSMD2*, together with the effector genes *C5AR1* and *IRF8* — are present as probes but did not pass intensity-based filtering, meaning they are not reliably detected above background on this platform. These genes therefore inform the conceptual framework but contribute nothing to the regional statistics, and their absence is itself a measurement limitation of bulk microarray rather than evidence of low expression in vivo.

Module scores were computed by z-scoring each gene across parcels and averaging within module. Reliability was quantified as the mean inter-donor Spearman correlation and the corresponding Spearman–Brown coefficient for the six-donor average. Stability was assessed by leave-one-gene-out recomputation.

### Cellular ownership

Cell-type attribution used the Allen Institute Human Multiple Cortical Areas SMART-seq release, taking median expression across its 121 transcriptomic cell types; the underlying taxonomy and methods are those of the Allen human cortical single-nucleus programme^37^, collapsed to neurons (excitatory and inhibitory), astrocytes, microglia, oligodendrocytes/OPCs and vascular cells. For each gene the fraction of total expression attributable to each class was computed, and module ownership is the mean of those fractions. This assignment is consistent with independent transcriptional profiling of purified human brain cell types^47^.

### Cortical hierarchy and composition control

The dominant transcriptional axis was defined as the first principal component of the parcel-by-gene z-scored matrix, oriented so that higher values denote association cortex; this recapitulates the established sensorimotor-to-association hierarchy^48,49^.

Module scores conflate two distinct quantities: an *extensive* term (how much machinery the tissue contains, which legitimately includes regional glial abundance) and an *intensive* term (the per-cell regulatory set-point). Independent cell-abundance panels were built from marker genes sharing no member with any pruning module (microglia, 10 genes; astrocyte, 8; neuron, 7; oligodendrocyte, 6; endothelial, 4). Each module was residualised on the abundance of the cell types that empirically express it (opsonin on neurons and microglia; checkpoint on neurons; effector on microglia; substrate on neurons), giving per-cell scores. The checkpoint module also carries a substantial vascular component (23.9%) that this specification does not remove, so its per-cell estimate is the least clean of the four. Partial Spearman correlations were computed by rank residualisation with degrees of freedom adjusted for the number of covariates. A fully adjusted specification conditioning on all five panels is reported for transparency, though it removes much of the hierarchy itself and is therefore over-adjusted.

### Biophysical model

Let *S*(τ) denote normalised synaptic density in a parcel. Elimination requires both an opsonin tag and an unopposed checkpoint, and engulfment capacity is set by microglia:

EQ: d*S*/dτ = σ~r~ (1 − *S*) − *E*~r~ *S* Φ~r~(*S*)  (1)

EQ: Φ~r~(*S*) = (*m T*~r~)^n^ / [ (*m T*~r~)^n^ + ( *K*~r~ (1 + λ *S*) )^n^ ]  (2)

where *T*~r~ is opsonin tag load, *K*~r~ checkpoint reserve, *E*~r~ effector capacity, σ~r~ the homeostatic synaptogenic replacement rate, *n* the Hill cooperativity of opsonin-dependent engulfment, and *m* a multiplicative immune perturbation of opsonin load (*m* = 1 at baseline). The term λ captures activity-dependent potentiation of checkpoint protection: because network activity scales with surviving synapse density, and CD47 protects active synapses^21^, protection is self-reinforcing.

Baseline synaptic density was treated as regionally invariant. This is an assumption, motivated by homeostatic synaptic plasticity, and it is the load-bearing premise of the cancellation result below; it is consistent with, but not established by, the spatial flatness of the substrate module, since transcript abundance does not index synaptic density and that module is in any case the least reliably estimated of the four. Under this assumption σ~r~ is set analytically so that every parcel rests at the same baseline *S*~0~:

EQ: σ~r~ = *E*~r~ *S*~0~ Φ~r~(*S*~0~, *m*=1) / (1 − *S*~0~)  (3)

*S*~0~ = 0.60 anchors the mature state to histology: human cortex loses roughly 40% of peak synaptic density between the childhood peak and adulthood^20,50^, a decline now also measurable in vivo with synaptic-density imaging^51^. Baseline elimination flux is then *J*~r~ = *E*~r~ *S*~0~ Φ~r~(*S*~0~) = σ~r~ (1 − *S*~0~), so parcels differ not in baseline density but in the turnover flux required to sustain it.

Regional parameters were mapped log-linearly from module z-scores, preserving positivity:

EQ: *T*~r~ = exp(*g* z~O~),   *K*~r~ = exp(*g* z~K~),   *E*~r~ = exp(*g* z~E~)  (4)

with gain *g* = 0.5 by default. Equilibria were located by sign-change bracketing and Brent root-finding on a 6,001-point grid; the largest stable root (d*f*/d*S* < 0) was taken as the operating point.

Three candidate vulnerability metrics were derived and carried forward without pre-selection:

EQ: **A**, fractional loss: Δ*S*~frac~(*m*) = (*S*~0~ − *S*~new~(*m*)) / *S*~0~  (5)

EQ: **B**, absolute excess elimination flux: Δ*J*(*m*) = *E*~r~ *S*~0~ [Φ~r~(*m*) − Φ~r~(1)]  (6)

EQ: **C**, homeostatic reserve: HR~r~ = σ~max~ / σ~r~, with σ~max~ = κ max~r~(σ~r~)  (7)

Default parameters were *n* = 2, λ = 1.5, *g* = 0.5, κ = 1.25 and probe perturbation *m* = 2. Metric C is undefined wherever the required opsonin increase exceeds the saturation ceiling of Φ, and correlations involving it were computed only where at least 21 parcels were defined. Sensitivity was assessed across 432 parameter combinations (*n* ∈ {1,2,3}, λ ∈ {0, 0.75, 1.5, 3}, *g* ∈ {0.25, 0.5, 1}, κ ∈ {1.1, 1.25, 1.5, 2}, *m* ∈ {1.5, 2, 3}). The cancellation of *E* from equation (1) under (3) was verified symbolically with SymPy.

### Genetic partition

Autism risk was indexed by (i) SFARI Gene curated categories^38^ and (ii) the `genetic_association` datatype score of the Open Targets Platform^39^, deliberately excluding the literature text-mining component, which would reward well-studied microglial genes. Schizophrenia scores were obtained identically. Because risk genes are systematically longer, more constrained and more highly brain-expressed, enrichment was evaluated against background sets matched on coding length, loss-of-function constraint (LOEUF) and mean cortical expression^52^, using 27 strata (3 × 3 × 3 tertiles) and 20,000 stratified resamples within a universe of 13,874 cortically expressed protein-coding genes with complete constraint annotation. One substrate gene (*SYN2*) lacks constraint annotation and is therefore absent from this universe, so the genetic tests use 35 of the 36 substrate genes. Two-sided *P* values are resampling tail probabilities; *z* is the standardised deviation from the matched null.

Because several canonical synaptic genes are also well-known autism genes, a circularity control re-tested the substrate module after removing SFARI category-1 genes, and again after removing categories 1 and 2. Data-driven cell-type marker sets (top 250/500/1,000 genes by class specificity, restricted to genes above the 25th expression percentile) were tested as an orthogonal, hypothesis-free instrument.

### Spatial validation

Model predictions were tested against ENIGMA cortical-thickness Cohen's *d* in the Desikan–Killiany parcellation: the autism mega- and meta-analyses^40^ and, as a disorder contrast, the schizophrenia mega-analysis^53^, both distributed with the ENIGMA Toolbox^41^. Parcel-wise sample sizes vary slightly within each map; the maxima are 1,659 autistic and 1,574 control participants (mega-analysis), 1,060 and 977 (meta-analysis), and 4,430 and 5,057 (schizophrenia), which differ marginally from the totals reported in the source publications because each parcel is analysed in the subset with usable data there. Because cortical maps are spatially smooth, naive permutation is anticonservative^54^. Significance was therefore assessed against 10,000 surrogate maps per target that preserve the empirical spatial autocorrelation by variogram matching^55^, computed on Euclidean distances between parcel centroids in MNI152 space. Parcels missing from a target map were removed before surrogate construction and surrogates were asserted to be free of missing values, because missing data silently deflate surrogate-based *P* values. A pre-specified tertile contrast (mean *d* in the top versus bottom third of each predictor) was evaluated against the same surrogates as a better-powered directional test. Detectability was quantified as the correlation magnitude lying at the 97.5th percentile of each null.

### Developmental trajectories

BrainSpan gene-level RNA-seq^36^ provided 352 neocortical samples from 42 donors spanning 8 post-conception weeks to 40 years across 11 regions, grouped a priori as primary (V1C, M1C, S1C, A1C) or association (DFC, VFC, OFC, MFC, STC, ITC, IPC). Age was expressed as log₁₀ post-conceptional days (gestation 280 d). Module scores were computed as above on log₂(RPKM + 1). All 91 module genes are present in BrainSpan, against 82 in the processed AHBA matrix, so the developmental and regional analyses are not computed on identical gene sets; in particular *SRPX2* contributes to the developmental checkpoint trajectory but not to the regional one. Trajectories were smoothed with cubic penalised splines and summarised by age of peak, age at 90% of maximum, and the fraction of the postnatal interval spent above 75% of maximum.

The hypothesis tested was pre-specified from classical histology, which reports that synaptic density peaks within the first postnatal year in human auditory cortex but only in the mid-preschool years in prefrontal cortex^50^, and that prefrontal spine pruning continues into the third decade^20^.

Transcript abundance of synaptic structural genes rises monotonically into adulthood and therefore does **not** index synapse density, which declines after early childhood; the substrate module is consequently reported descriptively only, and all developmental inference concerns the regulatory layers.

With 11 regions split 4/7, the hierarchy contrast admits C(11,4) = 330 label assignments, so primary-versus-association differences were tested by **exact permutation**. The pre-specified primary hypothesis concerned timing, giving a six-test family (peak age and 90%-of-maximum age for O, K and E) corrected by Benjamini–Hochberg; all other trajectory features are exploratory. Trajectory features were additionally bootstrapped over donors (2,000 resamples).

### Statistics, software and reproducibility

Analyses used Python 3.13 (NumPy, SciPy, pandas, scikit-learn, statsmodels, SymPy) except the AHBA workflow, which requires Python 3.11 with pandas 1.5.3 and abagen 0.1.3, provided as a pinned environment. Correlations are Spearman's ρ unless stated. Multiple comparisons use Benjamini–Hochberg within explicitly defined families. Random seeds are fixed (20261025). Per-parcel values for every layer score, model quantity and case-control effect size are given in Supplementary Table 5, and the provenance of every data resource in Supplementary Table 6. All code, environment specifications and derived data are released (Data Availability).

---

## Results

### The pruning axis resolves into layers with distinct cellular ownership

Cell-type attribution in human cortical single-nucleus data^37^ confirmed the intended division of labour (Fig. 1a, Table 1). The effector module was predominantly microglial (47.9% of expression; next largest class neurons, 27.4%), the checkpoint module predominantly neuronal (52.3%) with a vascular contribution (23.9%) and almost no microglial expression (1.2%), and the substrate module overwhelmingly neuronal (82.7%). The opsonin module was shared between neurons (66.7%) and microglia (33.3%), consistent with complement components being produced by both^1,14^. Layer assignment was therefore established empirically in human tissue rather than asserted.

Module scores were reliable across the six AHBA donors for the opsonin layer (mean inter-donor ρ = 0.68; Spearman–Brown for the six-donor average = 0.93) and the effector layer (ρ = 0.34; SB = 0.76), moderate for the checkpoint layer (ρ = 0.20; SB = 0.59) and low for the substrate (ρ = 0.12; SB = 0.46). The low substrate reliability bears directly on interpretation: the apparent spatial flatness of the substrate module is as consistent with an underpowered measurement as with genuine regional uniformity, and we therefore treat homeostatic matching as a modelling assumption rather than an empirical finding.

[Figure 1 near here]

### All three regulatory layers follow the cortical hierarchy while the substrate is flat

The first principal component of regional expression explained 31.9% of variance (PC2, 16.2%) and separated primary sensory cortex (pericalcarine, cuneus, lingual, lateral occipital, postcentral) from limbic and association cortex (entorhinal, temporal pole, anterior cingulate, parahippocampal), recapitulating the canonical sensorimotor-to-association axis^48,49^.

All three regulatory layers increased along this axis, most steeply the opsonin and effector layers (opsonin ρ = 0.88, *P* = 5.5 × 10⁻¹²; effector ρ = 0.83, *P* = 9.0 × 10⁻¹⁰; checkpoint ρ = 0.56, *P* = 5.4 × 10⁻⁴), whereas the synaptic substrate was flat (ρ = 0.009, *P* = 0.96) (Fig. 2a, Table 1). Gradients were not artefacts of regional glial abundance: after residualising each module on the abundance of the cell types that express it, the opsonin (ρ = 0.63, *P* = 1.2 × 10⁻⁴), checkpoint (ρ = 0.53, *P* = 1.6 × 10⁻³) and effector (ρ = 0.49, *P* = 4.1 × 10⁻³) gradients persisted while the substrate remained flat (ρ = 0.07, *P* = 0.69). Leave-one-gene-out recomputation showed the opsonin and effector gradients to be highly stable (ρ = 0.886 ± 0.016 and 0.835 ± 0.018) and the checkpoint gradient more variable (0.535 ± 0.144).

[Figure 2 near here]

### Opsonin and checkpoint layers are co-regulated, conserving their ratio across cortex

Opsonin and checkpoint scores were strongly correlated across parcels (ρ = 0.62, *P* = 9.6 × 10⁻⁵; Fig. 2c). The extensive balance *O* − *K* consequently rose along the hierarchy (ρ = 0.73, *P* = 1.2 × 10⁻⁶), peaking in temporal pole, entorhinal cortex, pars orbitalis and superior, inferior and middle temporal cortex, and reaching its minimum in pericalcarine, cuneus, lingual and lateral occipital cortex (Fig. 2e). This ordering matches the clinical gradient that motivated the question.

Crucially, however, the *per-cell* balance showed no hierarchical gradient (ρ = −0.13, *P* = 0.47). Association cortex does not run a riskier tag-to-brake ratio; it runs the same ratio at a higher absolute setting. The regional architecture is one of homeostatic matching on a steeply graded scale, not of regional imbalance.

### Effector capacity cancels exactly from fractional synaptic loss

This architecture has a strong consequence in the model. Substituting the matched synaptogenic rate (equation 3) into the steady state of equation (1) and cancelling *E*~r~ gives

EQ: *S*~0~ Φ~r~(*S*~0~,1) (1 − *S*) / (1 − *S*~0~) = *S* Φ~r~(*S*, *m*)  (8)

in which effector capacity does not appear. Symbolic reduction confirmed that *E* is absent from the reduced balance equation. Therefore, once baseline synaptic density is homeostatically matched, the *fractional* synapse loss produced by an immune perturbation is governed solely by the opsonin-to-checkpoint ratio and is **independent of microglial effector capacity** (Fig. 1d). Absolute excess elimination flux, by contrast, scales linearly with *E* (equation 6; Fig. 1e).

The two quantities dissociate and predict opposite cortical patterns. Across 432 parameter combinations, metric A (fractional loss) was negatively related to the hierarchy in every case (median ρ = −0.725; range −0.725 to −0.725; 100% sign-consistent), identifying primary visual cortex as most sensitive because it operates on the steep, unsaturated part of the Hill curve (baseline Φ = 0.075–0.549 across parcels). Metric B (absolute excess flux) was positively related to the hierarchy (median ρ = +0.83; range −0.30 to +0.86; 97% sign-consistent), identifying entorhinal cortex, temporal pole, caudal and rostral anterior cingulate, frontal pole and parahippocampal cortex as most affected, because baseline elimination flux spans a 26.6-fold range and is highest in limbic and association cortex. Rather than selecting between these predictions a priori, we took them to independent case–control data.

[Table 1 near here]

### Adult expression gradients do not predict autism cortical thickness once spatial autocorrelation is respected

Because metrics A and B order the cortex oppositely, the observed data discriminate between them even when neither reaches significance. The per-cell opsonin–checkpoint balance correlated with autism cortical-thickness Cohen's *d* at ρ = −0.31 in the mega-analysis and the extensive balance at ρ = −0.32, the sign expected if higher pruning pressure produces thinner cortex, and consistent across all six AHBA donors individually (ρ = −0.22 to −0.33; mean −0.29) (Fig. 3a,d). Metric B behaved the same way (ρ = −0.25). Metric A, being a monotone decreasing function of the balance, necessarily took the opposite sign (ρ = +0.32), so the weak association that is present runs against the fractional-loss ordering and with the excess-flux ordering (Fig. 3e). We note this because the model's own structural result makes metric A the quantity governed by the tag-to-checkpoint ratio; the data, such as they are, do not favour it.

These associations did not survive spatial-autocorrelation-preserving inference. Against 10,000 variogram-matched surrogates, the best autism result was the per-cell balance in the mega-analysis (ρ = −0.31, *P*_spatial = 0.069), with the extensive balance at *P*_spatial = 0.355; no predictor reached significance in the meta-analysis (best ρ = −0.31, *P*_spatial = 0.186), and no result survived FDR correction across predictors (Table 4, Fig. 3e). The pre-specified tertile contrast was likewise null (best *P*_spatial = 0.370). In the schizophrenia contrast only the substrate module was nominally associated (ρ = −0.45, *P*_spatial = 0.010, *q* = 0.113).

An explicit power analysis bounds the interpretation. Given the smoothness of these maps and 33–34 parcels, the median correlation magnitude required to reach significance was |ρ| = 0.585, whereas the largest observed autism association was |ρ| = 0.32 (Fig. 3c). The negative result is therefore inconclusive rather than refuting: effects of the size observed are not detectable at this spatial resolution. What it does establish is that cross-sectional adult expression gradients, analysed with appropriate nulls, do not by themselves support the common inference that regional complement or microglial expression explains regional vulnerability.

[Table 4 near here]

[Figure 3 near here]

### Autism genetic risk loads on the synaptic substrate and is absent from microglial effector machinery

Against backgrounds matched on coding length, constraint and cortical expression, the synaptic substrate module was strongly enriched for autism risk: 77.1% of its genes are SFARI autism genes versus 19.1% expected (*z* = 9.02, *P* = 1.0 × 10⁻⁴), and its mean Open Targets genetic-association score was 0.064 versus 0.0086 expected (*z* = 5.41, *P* = 5.0 × 10⁻⁴) (Fig. 4a,b; Table 2).

The microglial effector module was statistically indistinguishable from its matched null on both measures (SFARI 13.0% versus 7.9% expected, *z* = 0.95, *P* = 0.53; Open Targets genetic score 0.000 versus 0.0029 expected, *z* = −0.43, *P* = 1.0). This is a null result, not evidence of absence: with 23 genes and an expected count below one gene on the genetic measure, the test has little power against a modest effect, and the informative comparison is with the substrate module, which exceeds its null by nine standard deviations on the same instrument. The opsonin module was likewise unenriched for autism risk. Schizophrenia showed a different topology. Its genetic risk was enriched both in the synaptic substrate (*z* = 3.04, *P* = 0.012) and, unlike autism, in the checkpoint layer (*z* = 3.50, *P* = 0.011), which carried no autism enrichment. The dissociation is therefore specific: both disorders implicate the synaptic target, but only schizophrenia implicates the complement checkpoint, consistent with complement-regulatory loci including *CSMD1* carrying schizophrenia risk in genome-wide association data^56^, *CSMD1* itself being a membrane complement inhibitor^30^.

Because canonical synaptic genes include several famous autism genes, we re-tested after removing them. The substrate enrichment persisted after excluding all SFARI category-1 genes (63.6% versus 16.1%, *z* = 6.33, *P* = 1.0 × 10⁻⁴) and remained significant after excluding categories 1 and 2 (38.5% versus 12.8%, *z* = 2.85, *P* = 0.030), so the signal is not carried by a handful of well-known genes; the Open Targets genetic signal, as expected, resides in the genetically implicated genes themselves (Fig. 4c).

A hypothesis-free instrument qualified rather than overturned this. Data-driven marker sets were SFARI-enriched across every glial class at 1,000 genes — microglial *z* = 8.07, oligodendrocyte *z* = 5.87, astrocyte *z* = 2.95 — with the microglial set the strongest of the three, while the neuronal marker set was depleted (*z* = −3.69), reflecting that extreme cell-type specificity selects against the broadly expressed chromatin and synaptic regulators that carry autism risk. Two features nonetheless separate this from the substrate result. The magnitude is far smaller: the microglial set is enriched 1.5-fold over its matched null (0.238 versus 0.158) against 4.0-fold for the 35-gene substrate module (0.771 versus 0.191). And the enrichment does not appear on the purely genetic measure: no microglial marker set reached Open Targets genetic enrichment (*z* = −1.03, −0.02 and +1.08 at 250, 500 and 1,000 genes), the only nominal signal among all twelve marker sets being the 250-gene astrocyte set (*z* = 2.51, *P* = 0.038), which does not survive correction across sets (Fig. 4d).

[Table 2 near here]

[Figure 4 near here]

### The microglial effector programme is engaged years later in association than in primary cortex

If regional selectivity is not written into adult expression ratios, the remaining candidate axis is temporal. In BrainSpan, the age of peak engagement of the microglial effector module separated the two hierarchy levels completely: 0.91, 0.95, 1.22 and 1.56 postnatal years in M1C, A1C, S1C and V1C respectively, versus 2.67–7.46 years across the seven association regions (exact permutation on log age, difference = 0.447 log₁₀ days, *P* = 0.0030; family-wise *q* = 0.018) (Fig. 5c,d; Table 3). Donor bootstrapping gave a difference of +6.1 years with a 95% confidence interval excluding zero ([+1.1, +22.2]; *P*(>0) = 0.989).

Related timing features pointed the same way. The age at which the checkpoint layer reached 90% of its maximum was 20.9 years later in association cortex (*P* = 0.012, *q* = 0.036), although this comparison should be read with caution because the checkpoint trajectory peaks at the upper bound of the sampled age range in ten of eleven regions, so its 90%-of-maximum age is measured against an edge-censored maximum; the effector layer 1.41 years later (*P* = 0.027, *q* = 0.044) and the opsonin layer 0.61 years later (*P* = 0.033, *q* = 0.044); the opsonin peak was also later (*P* = 0.036, *q* = 0.044). Five of the six pre-specified timing features survived family-wise FDR correction. Opsonin peak timing was less robust under donor bootstrapping (+7.0 years, 95% CI [−5.1, +23.6]), so the effector result is the secure one. In postnatal samples, opsonin levels were modestly higher in association cortex (*P* = 0.039), with the balance *O* − *K* showing a consistent trend (*P* = 0.054).

[Table 3 near here]

[Figure 5 near here]

### The model's regional predictions are robust to parameterisation

Metric C proved degenerate and was not carried into inference: because engulfment probability saturates, the opsonin increase required to exhaust synaptogenic reserve is unreachable for most parcels, and the metric was defined for only 3 of 34 parcels under the default parameters and for at least 21 parcels in only 51 of 432 parameter sets. Across the 432-point parameter sweep, which spans *n* ∈ {1,2,3}, the sign of the remaining metrics' relationship to the cortical hierarchy was stable (metric A, 100% sign-consistent; metric B, 97%), and the ranking of parcels under the default parameters agreed closely with alternatives (Fig. 6). This stability does not extend indefinitely: in a wider scan including *n* = 4 with strong checkpoint potentiation, parcel ranking reversed relative to the default, so the robustness claim is bounded to *n* ≤ 3. No parcel exhibited bistability at the calibrated operating point under the default parameters, so regional differences reflect graded sensitivity rather than proximity to a catastrophic transition — a prediction that distinguishes this model from threshold-collapse accounts.

[Figure 6 near here]

---

## Discussion

We set out to adjudicate two open questions about microglial pruning in idiopathic autism. The analyses support a specific resolution: microglia are competent executioners whose regional deployment is timed rather than tonically graded, while the primary genetic lesion sits on the synaptic target.

The causal-attribution question has been difficult because both intrinsic microglial manipulation and neuronal "eat-me" induction produce pruning phenotypes^5,11,13,14^. Sufficiency experiments, however, cannot establish which lesion is primary in idiopathic human disease. Inherited risk can. Partitioned against backgrounds matched on the covariates that otherwise drive spurious enrichment, autism risk concentrated on the synaptic substrate by a factor of roughly four, while the microglial effector layer was indistinguishable from background. The effector result is a null, and with 23 genes it bounds rather than excludes a modest effect; what it does establish is an asymmetry, since the same instrument detects the substrate signal at nine standard deviations. The contrast with schizophrenia is instructive. Schizophrenia risk loaded on the synaptic substrate as well, but it additionally reached the complement checkpoint layer, which autism risk did not, consistent with structural variation at *C4* and with complement-regulatory loci implicated by genome-wide association^6,56^. The two disorders share a target and differ in whether the braking layer is also affected. Disorders that converge on the same effector pathway need not enter it at the same point. This does not exclude microglial contributions to autism — the ADNP screen demonstrates that an autism risk gene can act within microglia^12^, and our effector module is small, so modest enrichment cannot be excluded — but it does argue against a primary, genetically encoded immune lesion as the general mechanism in idiopathic cases. It also fits the post-mortem picture, in which microglial and astrocytic activation signatures are present in autistic cortex alongside, and downstream of, pronounced neuronal and isoform-level dysregulation^26,27,57^: a reactive signature can be prominent without being primary.

The regional question yielded a more surprising result. The intuitive account — that vulnerable cortex carries a worse tag-to-brake ratio — is not what the data show. Opsonin and checkpoint layers are co-regulated, and their per-cell ratio is conserved across the cortical sheet, with the whole system set higher in association cortex. Within the model this matters more than it might appear, because once baseline density is homeostatically matched, effector capacity cancels identically from fractional synapse loss. The cancellation is exact, not approximate, and it is a structural property rather than a parameter choice. It implies that regional differences in microglial abundance or activation state cannot, on their own, explain regional differences in proportional synapse loss. Any account of focal vulnerability must therefore locate the asymmetry elsewhere: in the tag-to-checkpoint ratio, in absolute rather than fractional loss, or in time.

Our spatial test could not confirm the first two routes. The transcriptomic vulnerability map correlated with autism cortical thinning in the predicted direction, consistently across all six donors, yet the association did not survive autocorrelation-preserving nulls. We report this as an informative negative rather than burying it, and we quantify what it does and does not license: with 34 parcels and smooth maps, detecting |ρ| ≈ 0.3 was not possible, so the hypothesis is untested rather than refuted. The broader methodological point stands independently. Correlations of this magnitude between cortical expression maps and case–control effect maps are routinely reported as support for molecular accounts of regional vulnerability; with proper nulls^54,55^, effects of that size are indistinguishable from smooth noise. Adult expression gradients are weaker evidence for regional mechanism than current practice assumes.

Time is where the between-region evidence was strongest, though it must be said at once that this analysis separates association from primary cortex and contains no autism or vulnerability variable; the bridge to regional susceptibility is an inference from the model, not a measurement. Microglial effector programmes peaked between 0.9 and 1.6 postnatal years in primary sensory and motor cortex and between 2.7 and 7.5 years in association cortex, a complete separation across eleven regions, significant under exact permutation and robust to donor resampling. This converges with histological evidence that synaptogenesis peaks far later in prefrontal than in sensory cortex^50^ and that human frontal spine pruning extends into the third decade^20^, and supplies the molecular counterpart: the machinery, not merely the structural outcome, stays engaged longer. A protracted window has a clear consequence under the model. Because it is the duration over which a perturbation acts, rather than the baseline ratio, that accumulates excess elimination, association cortex is exposed to any immune or environmental insult for years after primary cortex has closed its window. Focality need not require a focal insult; a diffuse perturbation suffices if regions differ in how long they remain susceptible. This reframes maternal immune activation, postnatal infection and chronic stress^19,58^ as perturbations whose anatomical consequences are determined largely by *when* they occur.

The framework makes testable predictions. First, the timing of effector-programme closure, not the magnitude of microglial activation, should predict regional vulnerability; comparing age-matched cohorts with insults at different developmental times should shift the affected territory. Second, manipulations of checkpoint tone should have larger effects than manipulations of effector capacity at matched baseline density, which is directly testable in organotypic or iPSC-derived co-culture systems^13^. Third, because SRPX2 is both a complement inhibitor and the human language-associated synapse gene^22,23^, checkpoint tone in language cortex is a specific target; we could not test it here because *SRPX2* does not rise above background in the AHBA microarray, a gap that single-nucleus or spatial transcriptomics could close.

Limitations should be stated plainly. The AHBA provides six adult donors and no autistic tissue, so regional parameters describe neurotypical architecture. *C4A*, *C4B* and *SRPX2* are missing from the processed expression matrix — *C4B* is not on the array, and the others fall below the intensity threshold — removing precisely the genes with the strongest prior links to complement-mediated psychiatric risk and to language. Transcript abundance is an imperfect proxy for pathway activity, and for synaptic structural genes it is not a density proxy at all, which is why we restricted developmental inference to regulatory layers. The model is deliberately minimal: it treats the cortex as a set of independent parcels, does not separate astrocytic from microglial elimination — the effector module contains MEGF10, MERTK, GAS6 and AXL and is 17.0% astrocytic by expression, so *E* is better read as glial engulfment capacity than as a microglia-specific quantity^32,59^ — omits synapse-type selectivity, and the growing evidence that some pruning proceeds independently of complement^24^. The genetic partition relies on curated and aggregated resources whose ascertainment is uneven. Finally, cortical thickness is a coarse readout of synaptic density.

---

## Conclusions

Framing synaptic pruning as a three-layer control system makes two long-standing questions tractable. Autism genetic risk concentrates on the neuronal synaptic substrate while the microglial effector layer is indistinguishable from matched background, which locates the detectable lesion on the target rather than the executioner; schizophrenia risk additionally reaches the complement checkpoint layer, showing that disorders converging on one effector pathway may enter it at different points. Regionally, the cortex maintains a conserved opsonin-to-checkpoint ratio on a steeply graded absolute scale, and the model shows analytically that under such homeostatic matching, microglial effector capacity cancels from fractional synapse loss and therefore cannot by itself specify regional vulnerability. Adult expression gradients did not predict regional autism cortical differences once spatial autocorrelation was respected. What did separate association from primary cortex, cleanly and robustly, was timing: microglial effector programmes remain engaged for years longer in association cortex. That contrast is developmental and contains no autism measure, so the link to regional vulnerability remains a hypothesis rather than a result — but it is a specific and testable one, and it follows from a model in which microglia execute without specifying. Where damage lands may be governed less by how strongly the machinery is expressed than by how long it stays open.

---

## CRediT authorship contribution statement

**[AUTHOR]:** Conceptualization, Methodology, Software, Formal analysis, Investigation, Data curation, Writing – original draft, Writing – review & editing, Visualization, Project administration.

## Ethics Statement

This study used only de-identified, publicly available human data distributed under open-access terms by the Allen Institute for Brain Science (Allen Human Brain Atlas; BrainSpan; Allen human cortical single-nucleus data), the ENIGMA Consortium (aggregate case–control summary statistics), SFARI Gene, the Open Targets Platform and the Genome Aggregation Database. No new human or animal data were collected, no individual-level data were accessed, and no restricted-access data use agreement was required. Ethical approval and participant consent were obtained by the original studies and are documented in their primary publications. Institutional review board approval was therefore not required for this secondary analysis of aggregate and de-identified public resources.

## Funding

This research received no specific grant from any funding agency in the public, commercial or not-for-profit sectors.

## Declaration of Competing Interest

The author declares no competing financial or non-financial interests.

## Data Availability Statement

All data analysed in this study are publicly available and require no restricted-access agreement. Allen Human Brain Atlas microarray data: https://human.brain-map.org (retrieved via abagen v0.1.3). BrainSpan developmental transcriptome (RNA-seq, gene-level RPKM): https://www.brainspan.org. Allen human cortical SMART-seq cell-type medians: https://portal.brain-map.org. ENIGMA case–control summary statistics: https://github.com/MICA-MNI/ENIGMA. SFARI Gene: https://gene.sfari.org. Open Targets Platform: https://platform.opentargets.org. gnomAD v2.1.1 constraint metrics: https://gnomad.broadinstitute.org.

All analysis code, the pinned computational environments, the a priori module definitions with per-gene supporting references, the machine-verified bibliography, and every derived table and figure are openly available at https://github.com/[GITHUB_USER]/[REPO] and archived on Zenodo (DOI to be assigned at release). The repository reproduces every number reported here from raw public data with a single command.

## Declaration of Generative AI and AI-Assisted Technologies in the Writing Process

During the preparation of this work the author used a generative AI assistant (Anthropic Claude) to assist with literature retrieval and verification, analysis code implementation, figure generation and language editing. All study design decisions, analytical choices, interpretations and conclusions were made and verified by the author, who reviewed and edited all content and takes full responsibility for the integrity and accuracy of the published article.

## References

1. Stevens B, Allen NJ, Vazquez LE, Howell GR, Christopherson KS, Nouri N, et al. The Classical Complement Cascade Mediates CNS Synapse Elimination. Cell. 2007;131:1164-1178. doi:10.1016/j.cell.2007.10.036
2. Schafer DP, Lehrman EK, Kautzman AG, Koyama R, Mardinly AR, Yamasaki R, et al. Microglia Sculpt Postnatal Neural Circuits in an Activity and Complement-Dependent Manner. Neuron. 2012;74:691-705. doi:10.1016/j.neuron.2012.03.026
3. Zhou M, Cornell J, Salinas S, Huang HY. Microglia regulation of synaptic plasticity and learning and memory. Neural Regen Res. 2022;17:705. doi:10.4103/1673-5374.322423
4. Paolicelli RC, Bolasco G, Pagani F, Maggi L, Scianni M, Panzanelli P, et al. Synaptic Pruning by Microglia Is Necessary for Normal Brain Development. Science. 2011;333:1456-1458. doi:10.1126/science.1202529
5. Zhan Y, Paolicelli RC, Sforazzini F, Weinhard L, Bolasco G, Pagani F, et al. Deficient neuron-microglia signaling results in impaired functional brain connectivity and social behavior. Nat Neurosci. 2014;17:400-406. doi:10.1038/nn.3641
6. Sekar A, Bialas AR, de Rivera H, Davis A, Hammond TR, Kamitaki N, et al. Schizophrenia risk from complex variation of complement component 4. Nature. 2016;530:177-183. doi:10.1038/nature16549
7. Hong S, Beja-Glasser VF, Nfonoyim BM, Frouin A, Li S, Ramakrishnan S, et al. Complement and microglia mediate early synapse loss in Alzheimer mouse models. Science. 2016;352:712-716. doi:10.1126/science.aad8373
8. Wilton DK, Mastro K, Heller MD, Gergits FW, Willing CR, Fahey JB, et al. Microglia and complement mediate early corticostriatal synapse loss and cognitive dysfunction in Huntington’s disease. Nat Med. 2023;29:2866-2884. doi:10.1038/s41591-023-02566-3
9. Lian A, He M, Zhang H, Yang Y. Microglia in autism spectrum disorder: heterogeneity, immunometabolism, and synapse-related pathways. Front. Immunol. 2026;17:1783755. doi:10.3389/fimmu.2026.1783755
10. Szydlowska K, Tivanello R, Kaminska B. Defining functional states and roles of microglia in neuropsychiatric disorders. Front. Cell. Neurosci. 2026;20:1798151. doi:10.3389/fncel.2026.1798151
11. Ding X, Wang J, Huang M, Chen Z, Liu J, Zhang Q, et al. Loss of microglial SIRPα promotes synaptic pruning in preclinical models of neurodegeneration. Nat Commun. 2021;12:2030. doi:10.1038/s41467-021-22301-1
12. Teter OM, McQuade A, Hagan V, Liang W, Dräger NM, Sattler SM, et al. CRISPRi-based screen of autism spectrum disorder risk genes in microglia uncovers roles of ADNP in microglia endocytosis and synaptic pruning. Mol Psychiatry. 2025;30:4176-4193. doi:10.1038/s41380-025-02997-z
13. Sellgren CM, Gracias J, Watmuff B, Biag JD, Thanos JM, Whittredge PB, et al. Increased synapse elimination by microglia in schizophrenia patient-derived models of synaptic pruning. Nat Neurosci. 2019;22:374-385. doi:10.1038/s41593-018-0334-7
14. Chen S, Zhang B, Qin T, Zhu M, Chen Q, Xia L, et al. Endogenous retrovirus-derived RNA-DNA hybrids induce microglial synaptic pruning in autism models. Neuron. 2026;114:1765-1781.e7. doi:10.1016/j.neuron.2026.01.011
15. Howes OD, McCutcheon R. Inflammation and the neural diathesis-stress hypothesis of schizophrenia: a reconceptualization. Transl Psychiatry. 2017;7:e1024-e1024. doi:10.1038/tp.2016.278
16. de Deus JL, Faborode OS, Nandi S. Synaptic Pruning by Microglia: Lessons from Genetic Studies in Mice. Dev Neurosci. 2024;47:362-382. doi:10.1159/000541379
17. Satterstrom FK, Kosmicki JA, Wang J, Breen MS, De Rubeis S, An JY, et al. Large-Scale Exome Sequencing Study Implicates Both Developmental and Functional Changes in the Neurobiology of Autism. Cell. 2020;180:568-584.e23. doi:10.1016/j.cell.2019.12.036
18. Grove J, Ripke S, Als TD, Mattheisen M, Walters RK, Won H, et al. Identification of common genetic risk variants for autism spectrum disorder. Nat Genet. 2019;51:431-444. doi:10.1038/s41588-019-0344-8
19. Tillmon H, Soteros BM, Shen L, Cong Q, Wollet M, General J, et al. Complement and microglia activation mediate stress-induced synapse loss in layer 2/3 of the medial prefrontal cortex in male mice. Nat Commun. 2024;15:9803. doi:10.1038/s41467-024-54007-5
20. Petanjek Z, Judaš M, Šimić G, Rašin MR, Uylings HBM, Rakic P, et al. Extraordinary neoteny of synaptic spines in the human prefrontal cortex. Proc. Natl. Acad. Sci. U.S.A. 2011;108:13281-13286. doi:10.1073/pnas.1105108108
21. Lehrman EK, Wilton DK, Litvina EY, Welsh CA, Chang ST, Frouin A, et al. CD47 Protects Synapses from Excess Microglia-Mediated Pruning during Development. Neuron. 2018;100:120-134.e6. doi:10.1016/j.neuron.2018.09.017
22. Cong Q, Soteros BM, Wollet M, Kim JH, Sia GM. The endogenous neuronal complement inhibitor SRPX2 protects against complement-mediated synapse elimination during development. Nat Neurosci. 2020;23:1067-1078. doi:10.1038/s41593-020-0672-0
23. Sia GM, Clem RL, Huganir RL. The Human Language–Associated Gene SRPX2 Regulates Synapse Formation and Vocalization in Mice. Science. 2013;342:987-991. doi:10.1126/science.1245079
24. Salter EW, Kadia A, Zhang L, Thacker JS, Choi S, Ralph LT, et al. Microglial Pruning of Excitatory Synapses in the Hippocampus Is Complement C3-Independent in Physiological and Neuroinflammatory States. Glia. 2026;74:e70154. doi:10.1002/glia.70154
25. Parikshak NN, Swarup V, Belgard TG, Irimia M, Ramaswami G, Gandal MJ, et al. Genome-wide changes in lncRNA, splicing, and regional gene expression patterns in autism. Nature. 2016;540:423-427. doi:10.1038/nature20612
26. Velmeshev D, Schirmer L, Jung D, Haeussler M, Perez Y, Mayer S, et al. Single-cell genomics identifies cell type–specific molecular changes in autism. Science. 2019;364:685-689. doi:10.1126/science.aav8130
27. Gandal MJ, Haney JR, Wamsley B, Yap CX, Parhami S, Emani PS, et al. Broad transcriptomic dysregulation occurs across the cerebral cortex in ASD. Nature. 2022;611:532-539. doi:10.1038/s41586-022-05377-7
28. Bjartmar L, Huberman AD, Ullian EM, Renteria RC, Liu X, Xu W, et al. Neuronal Pentraxins Mediate Synaptic Refinement in the Developing Visual System. Journal of Neuroscience. 2006;26:6269-6281. doi:10.1523/jneurosci.4212-05.2006
29. Hoek RM, Ruuls SR, Murphy CA, Wright GJ, Goddard R, Zurawski SM, et al. Down-Regulation of the Macrophage Lineage Through Interaction with OX2 (CD200). Science. 2000;290:1768-1771. doi:10.1126/science.290.5497.1768
30. Kraus DM, Elliott GS, Chute H, Horan T, Pfenninger KH, Sanford SD, et al. CSMD1 Is a Novel Multiple Domain Complement-Regulatory Protein Highly Expressed in the Central Nervous System and Epithelial Tissues. The Journal of Immunology. 2006;176:4419-4430. doi:10.4049/jimmunol.176.7.4419
31. Filipello F, Morini R, Corradini I, Zerbi V, Canzi A, Michalski B, et al. The Microglial Innate Immune Receptor TREM2 Is Required for Synapse Elimination and Normal Brain Connectivity. Immunity. 2018;48:979-991.e8. doi:10.1016/j.immuni.2018.04.016
32. Chung WS, Clarke LE, Wang GX, Stafford BK, Sher A, Chakraborty C, et al. Astrocytes mediate synapse elimination through MEGF10 and MERTK pathways. Nature. 2013;504:394-400. doi:10.1038/nature12776
33. Lui H, Zhang J, Makinson SR, Cahill MK, Kelley KW, Huang HY, et al. Progranulin Deficiency Promotes Circuit-Specific Synaptic Pruning by Microglia via Complement Activation. Cell. 2016;165:921-935. doi:10.1016/j.cell.2016.04.001
34. Koopmans F, van Nierop P, Andres-Alonso M, Byrnes A, Cijsouw T, Coba MP, et al. SynGO: An Evidence-Based, Expert-Curated Knowledge Base for the Synapse. Neuron. 2019;103:217-234.e4. doi:10.1016/j.neuron.2019.05.002
35. Hawrylycz MJ, Lein ES, Guillozet-Bongaarts AL, Shen EH, Ng L, Miller JA, et al. An anatomically comprehensive atlas of the adult human brain transcriptome. Nature. 2012;489:391-399. doi:10.1038/nature11405
36. Kang HJ, Kawasawa YI, Cheng F, Zhu Y, Xu X, Li M, et al. Spatio-temporal transcriptome of the human brain. Nature. 2011;478:483-489. doi:10.1038/nature10523
37. Hodge RD, Bakken TE, Miller JA, Smith KA, Barkan ER, Graybuck LT, et al. Conserved cell types with divergent features in human versus mouse cortex. Nature. 2019;573:61-68. doi:10.1038/s41586-019-1506-7
38. Abrahams BS, Arking DE, Campbell DB, Mefford HC, Morrow EM, Weiss LA, et al. SFARI Gene 2.0: a community-driven knowledgebase for the autism spectrum disorders (ASDs). Molecular Autism. 2013;4:36. doi:10.1186/2040-2392-4-36
39. Ochoa D, Hercules A, Carmona M, Suveges D, Baker J, Malangone C, et al. The next-generation Open Targets Platform: reimagined, redesigned, rebuilt. Nucleic Acids Research. 2023;51:D1353-D1359. doi:10.1093/nar/gkac1046
40. van Rooij D, Anagnostou E, Arango C, Auzias G, Behrmann M, Busatto GF, et al. Cortical and Subcortical Brain Morphometry Differences Between Patients With Autism Spectrum Disorder and Healthy Individuals Across the Lifespan: Results From the ENIGMA ASD Working Group. AJP. 2018;175:359-369. doi:10.1176/appi.ajp.2017.17010100
41. Larivière S, Paquola C, Park By, Royer J, Wang Y, Benkarim O, et al. The ENIGMA Toolbox: multiscale neural contextualization of multisite neuroimaging datasets. Nat Methods. 2021;18:698-700. doi:10.1038/s41592-021-01186-4
42. Markello RD, Arnatkeviciute A, Poline JB, Fulcher BD, Fornito A, Misic B. Standardizing workflows in imaging transcriptomics with the abagen toolbox. eLife. 2021;10:e72129. doi:10.7554/eLife.72129
43. Arnatkevic̆iūtė A, Fulcher BD, Fornito A. A practical guide to linking brain-wide gene expression and neuroimaging data. NeuroImage. 2019;189:353-367. doi:10.1016/j.neuroimage.2019.01.011
44. Desikan RS, Ségonne F, Fischl B, Quinn BT, Dickerson BC, Blacker D, et al. An automated labeling system for subdividing the human cerebral cortex on MRI scans into gyral based regions of interest. NeuroImage. 2006;31:968-980. doi:10.1016/j.neuroimage.2006.01.021
45. Scott-Hewitt N, Perrucci F, Morini R, Erreni M, Mahoney M, Witkowska A, et al. Local externalization of phosphatidylserine mediates developmental synaptic pruning by microglia. EMBO J. 2020;39:EMBJ2020105380. doi:10.15252/embj.2020105380
46. Ricklin D, Hajishengallis G, Yang K, Lambris JD. Complement: a key system for immune surveillance and homeostasis. Nat Immunol. 2010;11:785-797. doi:10.1038/ni.1923
47. Zhang Y, Sloan SA, Clarke LE, Caneda C, Plaza CA, Blumenthal PD, et al. Purification and Characterization of Progenitor and Mature Human Astrocytes Reveals Transcriptional and Functional Differences with Mouse. Neuron. 2016;89:37-53. doi:10.1016/j.neuron.2015.11.013
48. Burt JB, Demirtaş M, Eckner WJ, Navejar NM, Ji JL, Martin WJ, et al. Hierarchy of transcriptomic specialization across human cortex captured by structural neuroimaging topography. Nat Neurosci. 2018;21:1251-1259. doi:10.1038/s41593-018-0195-0
49. Margulies DS, Ghosh SS, Goulas A, Falkiewicz M, Huntenburg JM, Langs G, et al. Situating the default-mode network along a principal gradient of macroscale cortical organization. Proc. Natl. Acad. Sci. U.S.A. 2016;113:12574-12579. doi:10.1073/pnas.1608282113
50. Huttenlocher PR, Dabholkar AS. Regional differences in synaptogenesis in human cerebral cortex. J Comp Neurol. 1997;387:167-178. doi:10.1002/(SICI)1096-9861(19971020)387:2<167::AID-CNE1>3.0.CO;2-Z
51. Finnema SJ, Nabulsi NB, Eid T, Detyniecki K, Lin Sf, Chen MK, et al. Imaging synaptic density in the living human brain. Sci. Transl. Med. 2016;8. doi:10.1126/scitranslmed.aaf6667
52. Karczewski KJ, Francioli LC, Tiao G, Cummings BB, Alföldi J, Wang Q, et al. The mutational constraint spectrum quantified from variation in 141,456 humans. Nature. 2020;581:434-443. doi:10.1038/s41586-020-2308-7
53. van Erp TG, Walton E, Hibar DP, Schmaal L, Jiang W, Glahn DC, et al. Cortical Brain Abnormalities in 4474 Individuals With Schizophrenia and 5098 Control Subjects via the Enhancing Neuro Imaging Genetics Through Meta Analysis (ENIGMA) Consortium. Biological Psychiatry. 2018;84:644-654. doi:10.1016/j.biopsych.2018.04.023
54. Alexander-Bloch AF, Shou H, Liu S, Satterthwaite TD, Glahn DC, Shinohara RT, et al. On testing for spatial correspondence between maps of human brain structure and function. NeuroImage. 2018;178:540-551. doi:10.1016/j.neuroimage.2018.05.070
55. Burt JB, Helmer M, Shinn M, Anticevic A, Murray JD. Generative modeling of brain maps with spatial autocorrelation. NeuroImage. 2020;220:117038. doi:10.1016/j.neuroimage.2020.117038
56. Trubetskoy V, Pardiñas AF, Qi T, Panagiotaropoulou G, Awasthi S, Bigdeli TB, et al. Mapping genomic loci implicates genes and synaptic biology in schizophrenia. Nature. 2022;604:502-508. doi:10.1038/s41586-022-04434-5
57. Gandal MJ, Zhang P, Hadjimichael E, Walker RL, Chen C, Liu S, et al. Transcriptome-wide isoform-level dysregulation in ASD, schizophrenia, and bipolar disorder. Science. 2018;362:eaat8127. doi:10.1126/science.aat8127
58. Wang J, Chen HS, Li HH, Wang HJ, Zou RS, Lu XJ, et al. Microglia-dependent excessive synaptic pruning leads to cortical underconnectivity and behavioral abnormality following chronic social defeat stress in mice. Brain, Behavior, and Immunity. 2023;109:23-36. doi:10.1016/j.bbi.2022.12.019
59. Vainchtein ID, Chin G, Cho FS, Kelley KW, Miller JG, Chien EC, et al. Astrocyte-derived interleukin-33 promotes microglial synapse engulfment and neural circuit development. Science. 2018;359:1269-1273. doi:10.1126/science.aal3589
