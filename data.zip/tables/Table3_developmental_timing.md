**Table 3. Developmental timing of pruning-axis engagement in association versus primary cortex (BrainSpan, 11 neocortical regions, 42 donors). P values are exact permutation over the 330 possible assignments of region labels; q is Benjamini–Hochberg within the pre-specified six-test timing family.**

| Feature                                             |   Association cortex |   Primary cortex |   Difference |   P (exact) |   q (FDR) |
|:----------------------------------------------------|---------------------:|-----------------:|-------------:|------------:|----------:|
| Effector, age of peak (log₁₀ days)                  |               3.2913 |           2.8439 |       0.4474 |      0.003  |    0.0182 |
| Checkpoint, age at 90% of maximum (years)           |              28.5353 |           7.6305 |      20.9048 |      0.0121 |    0.0364 |
| Effector, age at 90% of maximum (years)             |               1.4357 |           0.0236 |       1.4122 |      0.0273 |    0.0436 |
| Opsonin, age at 90% of maximum (years)              |               0.5301 |          -0.0798 |       0.6099 |      0.0333 |    0.0436 |
| Opsonin, age of peak (log₁₀ post-conceptional days) |               3.4336 |           2.7662 |       0.6674 |      0.0364 |    0.0436 |
| Checkpoint, age of peak (log₁₀ days)                |               4.1729 |           3.4829 |       0.69   |      0.1091 |    0.1091 |
