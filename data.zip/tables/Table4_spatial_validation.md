**Table 4. Spatial association between model-derived regional predictions and ENIGMA case–control cortical-thickness effect sizes. P values are computed against 10,000 variogram-matched surrogate maps preserving the empirical spatial autocorrelation of each target. The final column is the correlation magnitude that would have reached significance, given that null.**

| Predictor     | Target                 |   n parcels |       ρ |   P (parametric) |   P (spatial null) |   q (FDR) |   |ρ| detectable at 95% |
|:--------------|:-----------------------|------------:|--------:|-----------------:|-------------------:|----------:|------------------------:|
| OCB_percell   | Autism (mega-analysis) |          33 | -0.31   |           0.0791 |             0.0686 |    0.6478 |                   0.338 |
| OCB           | Autism (mega-analysis) |          33 | -0.3172 |           0.072  |             0.3546 |    0.6478 |                   0.606 |
| A_frac_loss   | Autism (mega-analysis) |          33 |  0.3172 |           0.072  |             0.3546 |    0.6478 |                   0.606 |
| O             | Autism (mega-analysis) |          33 | -0.2792 |           0.1156 |             0.4578 |    0.6478 |                   0.66  |
| S             | Autism (mega-analysis) |          33 |  0.1295 |           0.4727 |             0.4809 |    0.6478 |                   0.353 |
| B_excess_flux | Autism (mega-analysis) |          33 | -0.2532 |           0.155  |             0.4928 |    0.6478 |                   0.639 |
| PC1           | Autism (mega-analysis) |          33 | -0.2082 |           0.245  |             0.5805 |    0.6478 |                   0.653 |
| E             | Autism (mega-analysis) |          33 | -0.1988 |           0.2674 |             0.5889 |    0.6478 |                   0.632 |
| K             | Autism (mega-analysis) |          33 | -0.0687 |           0.7042 |             0.7786 |    0.7786 |                   0.446 |
| K             | Autism (meta-analysis) |          34 | -0.3053 |           0.0791 |             0.186  |    0.8058 |                   0.446 |
| OCB_percell   | Autism (meta-analysis) |          34 | -0.2348 |           0.1814 |             0.1911 |    0.8058 |                   0.346 |
| O             | Autism (meta-analysis) |          34 | -0.3044 |           0.0801 |             0.387  |    0.8058 |                   0.633 |
| S             | Autism (meta-analysis) |          34 | -0.1046 |           0.556  |             0.5842 |    0.8058 |                   0.361 |
| OCB           | Autism (meta-analysis) |          34 | -0.1764 |           0.3184 |             0.5966 |    0.8058 |                   0.586 |
| A_frac_loss   | Autism (meta-analysis) |          34 |  0.1764 |           0.3184 |             0.5966 |    0.8058 |                   0.586 |
| PC1           | Autism (meta-analysis) |          34 | -0.1297 |           0.4647 |             0.7132 |    0.8058 |                   0.626 |
| B_excess_flux | Autism (meta-analysis) |          34 | -0.119  |           0.5027 |             0.7325 |    0.8058 |                   0.619 |
| E             | Autism (meta-analysis) |          34 | -0.0723 |           0.6843 |             0.8309 |    0.8309 |                   0.612 |
| S             | Schizophrenia          |          34 | -0.4499 |           0.0076 |             0.0103 |    0.1133 |                   0.353 |
| OCB_percell   | Schizophrenia          |          34 | -0.1842 |           0.2971 |             0.2957 |    0.8826 |                   0.34  |
| O             | Schizophrenia          |          34 | -0.213  |           0.2264 |             0.5043 |    0.8826 |                   0.585 |
| OCB           | Schizophrenia          |          34 | -0.1831 |           0.3    |             0.5512 |    0.8826 |                   0.549 |
| A_frac_loss   | Schizophrenia          |          34 |  0.1831 |           0.3    |             0.5512 |    0.8826 |                   0.549 |
| K             | Schizophrenia          |          34 | -0.1299 |           0.464  |             0.5616 |    0.8826 |                   0.417 |
| PC1           | Schizophrenia          |          34 | -0.1111 |           0.5316 |             0.7361 |    0.9744 |                   0.577 |
| E             | Schizophrenia          |          34 |  0.0457 |           0.7975 |             0.8874 |    0.9744 |                   0.568 |
| B_excess_flux | Schizophrenia          |          34 |  0.0098 |           0.9562 |             0.9744 |    0.9744 |                   0.576 |
